import { expect, test } from '@playwright/test';

/**
 * Parcours fonctionnel complet :
 * demande -> approbation -> preparation -> sortie -> bon -> location -> retour partiel
 * -> ecart -> mise a jour du tableau de bord.
 */
test.describe('Parcours de demonstration ALFA Flow', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/administration');
    await page.getByRole('button', { name: /Reinitialiser les donnees/ }).click();
    await page.getByRole('button', { name: 'Reinitialiser' }).click();
  });

  test('le tableau de bord affiche des indicateurs calcules', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Tableau de bord' })).toBeVisible();
    await expect(page.getByText('Retours en retard')).toBeVisible();
  });

  test('le catalogue filtre et ouvre une fiche article', async ({ page }) => {
    await page.goto('/catalogue');
    await page.getByLabel('Rechercher').fill('barre horizontale');
    await expect(page.getByRole('status')).toContainText('article');
    await page.getByRole('link', { name: /Barre horizontale/ }).first().click();
    await expect(page.getByText('Stock physique')).toBeVisible();
  });

  test('le controle final refuse une preparation incomplete', async ({ page }) => {
    await page.goto('/preparations');
    await page.getByRole('link', { name: /PREP-/ }).first().click();
    await page.getByRole('button', { name: 'Controle final' }).click();
    await expect(page.getByRole('alert')).toContainText('non traitee');
  });

  test('le lien client permet de verifier et signer', async ({ page }) => {
    await page.goto('/livraisons');
    await page.getByRole('link', { name: /L-\d+/ }).first().click();
    await page.getByRole('button', { name: 'Copier le lien' }).click();
    await expect(page.getByText('Simulation de demonstration')).toBeVisible();
  });

  test('un retour partiel calcule l ecart avant decision', async ({ page }) => {
    await page.goto('/locations');
    await page.getByRole('link', { name: /LOC-/ }).first().click();
    const bouton = page.getByRole('button', { name: 'Demarrer un retour' });
    if (await bouton.isVisible()) {
      await bouton.click();
      await expect(page.getByText('Ecart calcule par le systeme')).toBeVisible();
    }
  });

  test('les donnees persistent apres actualisation', async ({ page }) => {
    await page.goto('/stock');
    const registre = await page.getByRole('heading', { name: /Registre des mouvements/ }).textContent();
    await page.reload();
    await expect(page.getByRole('heading', { name: /Registre des mouvements/ })).toHaveText(
      registre ?? '',
    );
  });
});
