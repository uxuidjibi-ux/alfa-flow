import { useMemo } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { RotateCcw } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  Donnee,
  EtatVide,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutLocationBadge } from '../../components/ui/statuts';
import { demarrerRetour, quantiteRestante } from '../../services/operations';
import { aujourdHui, ecartJours, formatDate, somme } from '../../utils';
import type { Location } from '../../models/types';

function niveauAlerte(location: Location): { ton: 'neutre' | 'info' | 'attention' | 'critique'; texte: string } {
  const reste = somme(location.lignes, quantiteRestante);
  if (location.statut === 'CLOTUREE' || reste === 0) return { ton: 'neutre', texte: 'Soldee' };
  const jours = ecartJours(location.retourAttendu, aujourdHui());
  if (jours < 0) return { ton: 'critique', texte: `${Math.abs(jours)} j de retard` };
  if (jours <= 3) return { ton: 'attention', texte: `Retour dans ${jours} j` };
  return { ton: 'info', texte: `Retour dans ${jours} j` };
}

/** ECRAN 8 — locations en cours. */
export function Locations() {
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();

  const locations = useMemo(
    () =>
      [...donnees.locations].sort((a, b) => {
        const rang = { EN_RETARD: 0, EN_LITIGE: 1, RETOUR_PARTIEL: 2, RETOUR_ATTENDU: 3, ACTIVE: 4, CLOTUREE: 5 };
        return rang[a.statut] - rang[b.statut] || a.retourAttendu.localeCompare(b.retourAttendu);
      }),
    [donnees.locations],
  );

  return (
    <Page
      titre="Locations"
      description="Materiel actuellement chez les clients. Les lignes vendues n'apparaissent pas ici : elles ne reviennent pas."
    >
      <ul className="space-y-2 lg:hidden">
        {locations.map((location) => {
          const niveau = niveauAlerte(location);
          const reste = somme(location.lignes, quantiteRestante);
          return (
            <li key={location.id}>
              <Link
                to={`/locations/${location.id}`}
                className="flex flex-col gap-2 rounded-alfa border border-alfa-line p-3 hover:bg-alfa-surface"
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="min-w-0">
                    <span className="block font-medium text-alfa-ink">{location.numero}</span>
                    <span className="block truncate text-xs text-alfa-muted">
                      {reference.nomClient(location.clientId)}
                    </span>
                  </span>
                  <StatutLocationBadge statut={location.statut} />
                </span>
                <span className="flex items-center justify-between gap-2 text-sm">
                  <Statut ton={niveau.ton}>{niveau.texte}</Statut>
                  <span className="flex-none text-alfa-slate">
                    <strong className="tabular-nums text-alfa-ink">{reste}</strong> u. chez le client
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      <Section className="hidden lg:block">
        {locations.length === 0 ? (
          <EtatVide titre="Aucune location" />
        ) : (
          <Tableau
            legende="Locations en cours et cloturees"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Client' },
              { libelle: 'Chantier', discret: true },
              { libelle: 'Sortie', discret: true },
              { libelle: 'Retour attendu' },
              { libelle: 'Jours', alignement: 'droite', discret: true },
              { libelle: 'Restant', alignement: 'droite' },
              { libelle: 'Statut' },
              { libelle: 'Niveau' },
            ]}
          >
            {locations.map((location) => {
              const niveau = niveauAlerte(location);
              const reste = somme(location.lignes, quantiteRestante);
              return (
                <tr key={location.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link
                      to={`/locations/${location.id}`}
                      className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                    >
                      {location.numero}
                    </Link>
                  </Cellule>
                  <Cellule>{reference.nomClient(location.clientId)}</Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">{reference.nomChantier(location.chantierId)}</span>
                  </Cellule>
                  <Cellule discret>
                    <span className="whitespace-nowrap text-alfa-slate">
                      {formatDate(location.dateSortie)}
                    </span>
                  </Cellule>
                  <Cellule>
                    <span className="whitespace-nowrap text-alfa-slate">
                      {formatDate(location.retourAttendu)}
                    </span>
                  </Cellule>
                  <Cellule alignement="droite" discret>
                    {Math.abs(ecartJours(location.retourAttendu, location.dateSortie))}
                  </Cellule>
                  <Cellule alignement="droite">
                    <strong>{reste}</strong>
                  </Cellule>
                  <Cellule>
                    <StatutLocationBadge statut={location.statut} />
                  </Cellule>
                  <Cellule>
                    <Statut ton={niveau.ton}>{niveau.texte}</Statut>
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        )}
      </Section>
    </Page>
  );
}

/** Fiche location : rapprochement article par article. */
export function FicheLocation() {
  const { locationId } = useParams<{ locationId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutRetourner = useDroit('retour.executer');
  const naviguer = useNavigate();

  const location = donnees.locations.find((l) => l.id === locationId);
  if (!location) {
    return (
      <Page titre="Location introuvable">
        <Section>
          <EtatVide
            titre="Cette location n'existe pas"
            action={
              <Link to="/locations" className="text-alfa-redDark underline">
                Retour aux locations
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const sortie = donnees.sorties.find((s) => s.id === location.sortieId);
  const retours = donnees.retours.filter((r) => r.locationId === location.id);
  const reste = somme(location.lignes, quantiteRestante);
  const niveau = niveauAlerte(location);

  const commencerRetour = () => {
    const resultat = demarrerRetour(donnees, location.id, {
      utilisateurId: utilisateur.id,
      appareil: 'Tablette de cour',
    });
    if (appliquer(resultat, 'Retour ouvert : passez au comptage.')) naviguer('/retours');
  };

  return (
    <Page
      titre={`Location ${location.numero}`}
      fil={[{ libelle: 'Locations', lien: '/locations' }, { libelle: location.numero }]}
      actions={
        peutRetourner &&
        location.statut !== 'CLOTUREE' &&
        reste > 0 && (
          <Bouton
            variante="principal"
            onClick={commencerRetour}
            icone={<RotateCcw aria-hidden="true" className="h-4 w-4" />}
          >
            Demarrer un retour
          </Bouton>
        )
      }
    >
      <div className="grid gap-4 lg:grid-cols-4">
        <Section titre="Dossier">
          <dl className="space-y-3.5 p-4">
            <Donnee terme="Statut" valeur={<StatutLocationBadge statut={location.statut} />} />
            <Donnee terme="Niveau d'alerte" valeur={<Statut ton={niveau.ton}>{niveau.texte}</Statut>} />
            <Donnee
              terme="Client"
              valeur={
                <Link to={`/clients/${location.clientId}`} className="text-alfa-ink hover:underline">
                  {reference.nomClient(location.clientId)}
                </Link>
              }
            />
            <Donnee terme="Chantier" valeur={reference.nomChantier(location.chantierId)} />
            <Donnee terme="Date de sortie" valeur={formatDate(location.dateSortie)} />
            <Donnee terme="Retour attendu" valeur={formatDate(location.retourAttendu)} accent />
            <Donnee
              terme="Duree"
              valeur={`${Math.abs(ecartJours(location.retourAttendu, location.dateSortie))} jours`}
            />
            {sortie && (
              <Donnee
                terme="Bon de livraison"
                valeur={
                  <Link to={`/livraisons/${sortie.id}`} className="text-alfa-ink hover:underline">
                    {sortie.numero}
                  </Link>
                }
              />
            )}
          </dl>
        </Section>

        <Section titre="Rapprochement article par article" className="lg:col-span-3">
          <Tableau
            legende="Etat du rapprochement de cette location"
            entetes={[
              { libelle: 'Article' },
              { libelle: 'Sortie', alignement: 'droite' },
              { libelle: 'Retournee', alignement: 'droite' },
              { libelle: 'Endommagee', alignement: 'droite' },
              { libelle: 'Manquante', alignement: 'droite' },
              { libelle: 'Contestee', alignement: 'droite', discret: true },
              { libelle: 'Reste chez le client', alignement: 'droite' },
            ]}
          >
            {location.lignes.map((ligne) => {
              const restant = quantiteRestante(ligne);
              return (
                <tr key={ligne.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link
                      to={`/catalogue/${ligne.produitId}`}
                      className="text-alfa-ink hover:underline"
                    >
                      {reference.nomProduit(ligne.produitId)}
                    </Link>
                  </Cellule>
                  <Cellule alignement="droite">{ligne.quantiteSortie}</Cellule>
                  <Cellule alignement="droite">{ligne.quantiteRetournee}</Cellule>
                  <Cellule alignement="droite">
                    <span className={ligne.quantiteEndommagee > 0 ? 'text-alfa-redDark' : ''}>
                      {ligne.quantiteEndommagee}
                    </span>
                  </Cellule>
                  <Cellule alignement="droite">
                    <span className={ligne.quantiteManquante > 0 ? 'text-alfa-redDark' : ''}>
                      {ligne.quantiteManquante}
                    </span>
                  </Cellule>
                  <Cellule alignement="droite" discret>
                    {ligne.quantiteContestee}
                  </Cellule>
                  <Cellule alignement="droite">
                    <strong className={restant > 0 ? 'text-alfa-ink' : 'text-alfa-muted'}>
                      {restant}
                    </strong>
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
          <p className="border-t border-alfa-line px-4 py-2.5 text-sm text-alfa-slate">
            Quantite restante = quantite sortie moins les quantites retournees acceptees, endommagees
            et declarees manquantes. Total encore chez le client :{' '}
            <strong className="tabular-nums text-alfa-ink">{reste}</strong> unites.
          </p>
        </Section>
      </div>

      {retours.length > 0 && (
        <Section titre="Retours rattaches" className="mt-4">
          <Tableau
            legende="Retours enregistres pour cette location"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Date' },
              { libelle: 'Acceptees', alignement: 'droite' },
              { libelle: 'Endommagees', alignement: 'droite' },
              { libelle: 'Manquantes', alignement: 'droite' },
              { libelle: 'Statut' },
            ]}
          >
            {retours.map((retour) => (
              <tr key={retour.id} className="hover:bg-alfa-surface">
                <Cellule>
                  <Link to={`/retours/${retour.id}`} className="font-medium text-alfa-ink hover:underline">
                    {retour.numero}
                  </Link>
                </Cellule>
                <Cellule>
                  <span className="whitespace-nowrap text-alfa-slate">{formatDate(retour.date)}</span>
                </Cellule>
                <Cellule alignement="droite">{somme(retour.lignes, (l) => l.quantiteAcceptee)}</Cellule>
                <Cellule alignement="droite">{somme(retour.lignes, (l) => l.quantiteEndommagee)}</Cellule>
                <Cellule alignement="droite">{somme(retour.lignes, (l) => l.quantiteManquante)}</Cellule>
                <Cellule>
                  <Statut ton={retour.statut === 'CLOTURE' ? 'succes' : 'attention'}>
                    {retour.statut}
                  </Statut>
                </Cellule>
              </tr>
            ))}
          </Tableau>
        </Section>
      )}
    </Page>
  );
}
