import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Copy, Download, ExternalLink, Mail, Printer, Truck } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  Donnee,
  EtatVide,
  Message,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutSortieBadge, TypeItemBadge } from '../../components/ui/statuts';
import { changerStatutSortie } from '../../services/operations';
import { apercuBon, imprimerBon, telechargerBon } from '../../services/pdf';
import { TRANSITIONS_SORTIE, LIBELLE_STATUT_SORTIE } from '../../models/referentiel';
import { formatDate, formatDateHeure, somme } from '../../utils';
import type { DonneesBon } from '../../services/pdf';

/** ECRAN 6 — liste des sorties et bons de livraison. */
export function Livraisons() {
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();

  const sorties = useMemo(
    () => [...donnees.sorties].sort((a, b) => b.dateSortie.localeCompare(a.dateSortie)),
    [donnees.sorties],
  );

  return (
    <Page
      titre="Sorties et livraisons"
      description="Les bons poursuivent la numerotation papier existante. Un meme bon peut porter des lignes en location et en achat."
    >
      <Section>
        {sorties.length === 0 ? (
          <EtatVide titre="Aucune sortie enregistree" />
        ) : (
          <Tableau
            legende="Bons de livraison"
            entetes={[
              { libelle: 'Bon' },
              { libelle: 'Client' },
              { libelle: 'Chantier', discret: true },
              { libelle: 'Date' },
              { libelle: 'Expedie', alignement: 'droite' },
              { libelle: 'A venir', alignement: 'droite', discret: true },
              { libelle: 'Statut' },
            ]}
          >
            {sorties.map((sortie) => (
              <tr key={sortie.id} className="hover:bg-alfa-surface">
                <Cellule>
                  <Link
                    to={`/livraisons/${sortie.id}`}
                    className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                  >
                    {sortie.numero}
                  </Link>
                </Cellule>
                <Cellule>{reference.nomClient(sortie.clientId)}</Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">{reference.nomChantier(sortie.chantierId)}</span>
                </Cellule>
                <Cellule>
                  <span className="whitespace-nowrap text-alfa-slate">
                    {formatDate(sortie.dateSortie)}
                  </span>
                </Cellule>
                <Cellule alignement="droite">{somme(sortie.lignes, (l) => l.quantite)}</Cellule>
                <Cellule alignement="droite" discret>
                  {somme(sortie.lignes, (l) => l.quantiteAVenir) || '—'}
                </Cellule>
                <Cellule>
                  <StatutSortieBadge statut={sortie.statut} />
                </Cellule>
              </tr>
            ))}
          </Tableau>
        )}
      </Section>
    </Page>
  );
}

/** Fiche du bon : apercu PDF, changement de statut, lien client simule. */
export function FicheLivraison() {
  const { sortieId } = useParams<{ sortieId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const notifier = useBoutique((e) => e.notifier);
  const modifier = useBoutique((e) => e.modifier);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutGenerer = useDroit('bon.generer');

  const sortie = donnees.sorties.find((s) => s.id === sortieId);
  const [apercu, setApercu] = useState<string | null>(null);

  if (!sortie) {
    return (
      <Page titre="Bon introuvable">
        <Section>
          <EtatVide
            titre="Ce bon de livraison n'existe pas"
            action={
              <Link to="/livraisons" className="text-alfa-redDark underline">
                Retour aux livraisons
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const contexte = { utilisateurId: utilisateur.id, appareil: 'Poste web' };
  const client = reference.client(sortie.clientId);
  const chantier = reference.chantier(sortie.chantierId);
  const demande = reference.demande(sortie.demandeId);
  const location = donnees.locations.find((l) => l.sortieId === sortie.id);

  const donneesBon: DonneesBon = {
    sortie,
    client: client!,
    chantier: chantier!,
    contact: reference.contact(chantier?.contactId ?? null),
    produits: donnees.produits,
    preparateur: reference.utilisateur(sortie.preparateurId),
    referenceDemande: demande?.numero ?? '—',
  };

  const lienClient = `${window.location.origin}/bon/${sortie.jetonPublic}`;
  const transitions = TRANSITIONS_SORTIE[sortie.statut];

  return (
    <Page
      titre={`Bon ${sortie.numero}`}
      fil={[{ libelle: 'Sorties et livraisons', lien: '/livraisons' }, { libelle: sortie.numero }]}
      actions={
        peutGenerer && (
          <>
            <Bouton
              onClick={() => setApercu(apercuBon(donneesBon))}
              icone={<Truck aria-hidden="true" className="h-4 w-4" />}
            >
              Apercu
            </Bouton>
            <Bouton
              onClick={() => telechargerBon(donneesBon)}
              icone={<Download aria-hidden="true" className="h-4 w-4" />}
            >
              Telecharger le PDF
            </Bouton>
            <Bouton
              onClick={() => imprimerBon(donneesBon)}
              icone={<Printer aria-hidden="true" className="h-4 w-4" />}
            >
              Imprimer
            </Bouton>
          </>
        )
      }
    >
      <div className="grid gap-4 lg:grid-cols-3">
        <Section titre="Dossier">
          <dl className="space-y-3.5 p-4">
            <Donnee terme="Statut" valeur={<StatutSortieBadge statut={sortie.statut} />} />
            <Donnee
              terme="Client"
              valeur={
                <Link to={`/clients/${sortie.clientId}`} className="text-alfa-ink hover:underline">
                  {reference.nomClient(sortie.clientId)}
                </Link>
              }
            />
            <Donnee terme="Chantier" valeur={reference.nomChantier(sortie.chantierId)} />
            <Donnee terme="Date de sortie" valeur={formatDateHeure(sortie.dateSortie)} accent />
            <Donnee terme="Livreur" valeur={sortie.livreur || '—'} />
            <Donnee terme="Representant" valeur={sortie.representant || '—'} />
            <Donnee terme="Termes" valeur={sortie.termes} />
            <Donnee terme="Version du document" valeur={sortie.version} />
            {location && (
              <Donnee
                terme="Location"
                valeur={
                  <Link to={`/locations/${location.id}`} className="text-alfa-ink hover:underline">
                    {location.numero}
                  </Link>
                }
              />
            )}
          </dl>
        </Section>

        <Section titre="Lignes du bon" className="lg:col-span-2">
          <Tableau
            legende="Lignes du bon de livraison"
            entetes={[
              { libelle: 'Code' },
              { libelle: 'Article' },
              { libelle: 'Type' },
              { libelle: 'Commandee', alignement: 'droite' },
              { libelle: 'Expediee', alignement: 'droite' },
              { libelle: 'A venir', alignement: 'droite' },
            ]}
          >
            {sortie.lignes.map((ligne) => {
              const produit = reference.produit(ligne.produitId);
              return (
                <tr key={ligne.id}>
                  <Cellule>
                    <span className="tabular-nums text-alfa-slate">{produit?.codeItem}</span>
                  </Cellule>
                  <Cellule>
                    <Link to={`/catalogue/${ligne.produitId}`} className="text-alfa-ink hover:underline">
                      {produit?.nom}
                    </Link>
                    {ligne.note && <span className="block text-xs text-alfa-muted">{ligne.note}</span>}
                  </Cellule>
                  <Cellule>
                    <TypeItemBadge type={ligne.typeItem} />
                  </Cellule>
                  <Cellule alignement="droite">{ligne.quantiteCommandee}</Cellule>
                  <Cellule alignement="droite">
                    <strong>{ligne.quantite}</strong>
                  </Cellule>
                  <Cellule alignement="droite">
                    <span className={ligne.quantiteAVenir > 0 ? 'font-semibold text-alfa-redDark' : ''}>
                      {ligne.quantiteAVenir}
                    </span>
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        </Section>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Section titre="Suivi du document">
          <div className="space-y-3 p-4">
            {transitions.length === 0 ? (
              <Message ton="succes" titre="Le bon est signe : le dossier documentaire est complet." />
            ) : (
              <>
                <p className="text-sm text-alfa-slate">
                  Statut actuel : <strong>{LIBELLE_STATUT_SORTIE[sortie.statut]}</strong>. Seules les
                  transitions autorisees sont proposees.
                </p>
                <div className="flex flex-wrap gap-2">
                  {transitions.map((cible) => (
                    <Bouton
                      key={cible}
                      onClick={() =>
                        appliquer(
                          changerStatutSortie(donnees, sortie.id, cible, contexte),
                          `Bon ${sortie.numero} : ${LIBELLE_STATUT_SORTIE[cible]}.`,
                        )
                      }
                    >
                      {LIBELLE_STATUT_SORTIE[cible]}
                    </Bouton>
                  ))}
                </div>
              </>
            )}

            {sortie.signatureDataUrl && (
              <div className="border-t border-alfa-line pt-3">
                <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                  Signature recueillie
                </p>
                <img
                  src={sortie.signatureDataUrl}
                  alt={`Signature de ${sortie.signataireNom}`}
                  className="mt-1.5 h-20 rounded-alfa border border-alfa-line bg-white"
                />
                <p className="mt-1 text-sm text-alfa-slate">
                  {sortie.signataireNom} — {formatDateHeure(sortie.dateSignature)}
                </p>
              </div>
            )}

            {sortie.receptionClient.length > 0 && (
              <div className="border-t border-alfa-line pt-3">
                <p className="mb-1.5 text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                  Verification faite par le client
                </p>
                <ul className="space-y-1 text-sm">
                  {sortie.receptionClient.map((ligne) => {
                    const ligneSortie = sortie.lignes.find((l) => l.id === ligne.ligneSortieId);
                    const produit = ligneSortie ? reference.produit(ligneSortie.produitId) : undefined;
                    return (
                      <li key={ligne.ligneSortieId} className="flex flex-wrap items-center gap-2">
                        <Statut ton={ligne.conforme ? 'succes' : 'critique'}>
                          {ligne.conforme ? 'Conforme' : `Recu ${ligne.quantiteConstatee}`}
                        </Statut>
                        <span className="text-alfa-slate">{produit?.nom}</span>
                        {ligne.commentaire && (
                          <span className="text-alfa-muted">— {ligne.commentaire}</span>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
          </div>
        </Section>

        <Section titre="Lien client (simulation de demonstration)">
          <div className="space-y-3 p-4">
            <Message
              ton="attention"
              titre="Simulation de demonstration"
              details={[
                'Le lien n est ni signe, ni expirable, ni revocable.',
                'La signature recueillie n a aucune valeur juridique.',
              ]}
            />
            <div className="flex flex-wrap gap-2">
              <Bouton
                onClick={() => window.open(`/bon/${sortie.jetonPublic}`, '_blank')}
                icone={<ExternalLink aria-hidden="true" className="h-4 w-4" />}
              >
                Ouvrir la page client
              </Bouton>
              <Bouton
                onClick={() => {
                  void navigator.clipboard?.writeText(lienClient);
                  notifier('succes', 'Lien copie dans le presse-papiers.');
                }}
                icone={<Copy aria-hidden="true" className="h-4 w-4" />}
              >
                Copier le lien
              </Bouton>
              <Bouton
                onClick={() => {
                  modifier((etat) => ({
                    ...etat,
                    sorties: etat.sorties.map((s) =>
                      s.id === sortie.id ? { ...s, envoiSimule: true } : s,
                    ),
                  }));
                  notifier(
                    'info',
                    "Envoi simule : aucun courriel n'est reellement expedie par le demonstrateur.",
                  );
                }}
                icone={<Mail aria-hidden="true" className="h-4 w-4" />}
              >
                Simuler l'envoi au client
              </Bouton>
            </div>
            <p className="break-all rounded-alfa bg-alfa-surface px-3 py-2 text-xs text-alfa-slate">
              {lienClient}
            </p>
            {sortie.envoiSimule && <Statut ton="info">Envoi simule effectue</Statut>}
          </div>
        </Section>
      </div>

      {apercu && (
        <Section titre="Apercu du bon de livraison" className="mt-4">
          <div className="p-3">
            <iframe
              title={`Apercu du bon ${sortie.numero}`}
              src={apercu}
              className="h-[70vh] w-full rounded-alfa border border-alfa-line"
            />
          </div>
        </Section>
      )}
    </Page>
  );
}
