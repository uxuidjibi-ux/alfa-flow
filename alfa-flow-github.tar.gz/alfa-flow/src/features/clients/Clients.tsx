import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Building2, MapPin, Phone, Plus, Search, User } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  Donnee,
  EtatVide,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutDemandeBadge, StatutLocationBadge, StatutSortieBadge } from '../../components/ui/statuts';
import { quantiteRestante } from '../../services/operations';
import { contient, formatDate, somme } from '../../utils';

/** ECRAN 3 — repertoire des clients et de leurs chantiers. */
export function Clients() {
  const donnees = useBoutique((e) => e.donnees);
  const [requete, setRequete] = useState('');

  const clients = useMemo(
    () =>
      donnees.clients.filter((client) =>
        contient(`${client.nom} ${client.code} ${client.ville} ${client.courriel}`, requete),
      ),
    [donnees.clients, requete],
  );

  return (
    <Page
      titre="Clients et chantiers"
      description="Repertoire des clients de demonstration. Un client peut avoir plusieurs chantiers et plusieurs signataires."
    >
      <Section className="mb-4">
        <div className="p-3">
          <label htmlFor="recherche-clients" className="sr-only">
            Rechercher un client
          </label>
          <div className="relative">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-alfa-muted"
            />
            <input
              id="recherche-clients"
              type="search"
              value={requete}
              onChange={(e) => setRequete(e.target.value)}
              placeholder="Nom, code, ville…"
              className="champ pl-9"
            />
          </div>
        </div>
      </Section>

      {clients.length === 0 ? (
        <Section>
          <EtatVide titre="Aucun client ne correspond a cette recherche" />
        </Section>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {clients.map((client) => {
            const chantiers = donnees.chantiers.filter((c) => c.clientId === client.id);
            const locations = donnees.locations.filter(
              (l) => l.clientId === client.id && l.statut !== 'CLOTUREE',
            );
            const chezClient = somme(locations, (l) => somme(l.lignes, quantiteRestante));

            return (
              <li key={client.id}>
                <Link
                  to={`/clients/${client.id}`}
                  className="flex h-full flex-col gap-3 rounded-alfa border border-alfa-line p-4 transition-colors hover:border-alfa-slate hover:bg-alfa-surface"
                >
                  <div>
                    <p className="font-semibold text-alfa-ink">{client.nom}</p>
                    <p className="text-xs text-alfa-muted">
                      {client.code} · {client.ville}
                    </p>
                  </div>
                  <dl className="mt-auto grid grid-cols-3 gap-2 border-t border-alfa-line pt-3">
                    <Donnee terme="Chantiers" valeur={chantiers.length} />
                    <Donnee terme="Locations" valeur={locations.length} />
                    <Donnee terme="Chez le client" valeur={`${chezClient} u.`} accent />
                  </dl>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </Page>
  );
}

/** Fiche client : chantiers, contacts, materiel sur place, dossiers. */
export function FicheClient() {
  const { clientId } = useParams<{ clientId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();
  const peutCreer = useDroit('demande.creer');
  const naviguer = useNavigate();

  const client = donnees.clients.find((c) => c.id === clientId);
  const locations = useMemo(
    () => donnees.locations.filter((l) => l.clientId === clientId),
    [donnees.locations, clientId],
  );

  // Materiel actuellement chez ce client, article par article.
  const materielSurPlace = useMemo(() => {
    const total = new Map<string, number>();
    for (const location of locations) {
      if (location.statut === 'CLOTUREE') continue;
      for (const ligne of location.lignes) {
        const reste = quantiteRestante(ligne);
        if (reste > 0) total.set(ligne.produitId, (total.get(ligne.produitId) ?? 0) + reste);
      }
    }
    return [...total.entries()].sort((a, b) => b[1] - a[1]);
  }, [locations]);

  if (!client) {
    return (
      <Page titre="Client introuvable">
        <Section>
          <EtatVide
            titre="Ce client n'existe pas"
            action={
              <Link to="/clients" className="text-alfa-redDark underline">
                Retour au repertoire
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const chantiers = donnees.chantiers.filter((c) => c.clientId === client.id);
  const contacts = donnees.contacts.filter((c) => c.clientId === client.id);
  const demandes = donnees.demandes.filter((d) => d.clientId === client.id);
  const sorties = donnees.sorties.filter((s) => s.clientId === client.id);
  const retours = donnees.retours.filter((r) => locations.some((l) => l.id === r.locationId));

  return (
    <Page
      titre={client.nom}
      fil={[{ libelle: 'Clients et chantiers', lien: '/clients' }, { libelle: client.nom }]}
      actions={
        peutCreer && (
          <Bouton
            variante="principal"
            icone={<Plus aria-hidden="true" className="h-4 w-4" />}
            onClick={() => naviguer(`/demandes/nouvelle?client=${client.id}`)}
          >
            Creer une demande
          </Bouton>
        )
      }
    >
      <div className="grid gap-4 lg:grid-cols-3">
        <Section titre="Coordonnees">
          <dl className="grid grid-cols-2 gap-4 p-4">
            <Donnee terme="Code" valeur={client.code} />
            <Donnee terme="Ville" valeur={client.ville} />
            <Donnee terme="Telephone" valeur={client.telephone} />
            <Donnee terme="Courriel" valeur={client.courriel} />
          </dl>
          {client.notes && (
            <p className="border-t border-alfa-line px-4 py-3 text-sm text-alfa-slate">
              {client.notes}
            </p>
          )}
        </Section>

        <Section titre="Contacts et signataires">
          {contacts.length === 0 ? (
            <EtatVide titre="Aucun contact enregistre" />
          ) : (
            <ul className="divide-y divide-alfa-line">
              {contacts.map((contact) => (
                <li key={contact.id} className="flex items-start gap-2.5 px-4 py-3">
                  <User aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-alfa-muted" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-alfa-ink">{contact.nom}</p>
                    <p className="text-xs text-alfa-muted">{contact.fonction}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-alfa-slate">
                      <Phone aria-hidden="true" className="h-3 w-3" />
                      {contact.telephone}
                    </p>
                  </div>
                  {contact.signataire && <Statut ton="info">Signataire</Statut>}
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section titre="Materiel actuellement chez ce client">
          {materielSurPlace.length === 0 ? (
            <EtatVide titre="Aucun materiel sur place" texte="Tous les dossiers sont rapproches." />
          ) : (
            <ul className="divide-y divide-alfa-line">
              {materielSurPlace.slice(0, 8).map(([produitId, quantite]) => (
                <li key={produitId} className="flex items-center justify-between gap-3 px-4 py-2.5">
                  <Link
                    to={`/catalogue/${produitId}`}
                    className="min-w-0 truncate text-sm text-alfa-ink hover:underline"
                  >
                    {reference.nomProduit(produitId)}
                  </Link>
                  <span className="flex-none font-semibold tabular-nums text-alfa-ink">
                    {quantite}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Section>
      </div>

      <Section titre="Chantiers" className="mt-4">
        {chantiers.length === 0 ? (
          <EtatVide titre="Aucun chantier" />
        ) : (
          <ul className="divide-y divide-alfa-line">
            {chantiers.map((chantier) => {
              const contact = reference.contact(chantier.contactId);
              const locationsChantier = locations.filter(
                (l) => l.chantierId === chantier.id && l.statut !== 'CLOTUREE',
              );
              return (
                <li key={chantier.id} className="flex flex-wrap items-start gap-3 px-4 py-3">
                  <Building2 aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-alfa-muted" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-alfa-ink">{chantier.nom}</p>
                    <p className="mt-0.5 flex items-center gap-1.5 text-xs text-alfa-slate">
                      <MapPin aria-hidden="true" className="h-3 w-3" />
                      {chantier.adresse}, {chantier.ville}
                    </p>
                    {contact && (
                      <p className="mt-0.5 text-xs text-alfa-muted">
                        Responsable sur place : {contact.nom} · {contact.telephone}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-alfa-muted">{chantier.code}</span>
                    {locationsChantier.length > 0 && (
                      <Statut ton="info">{locationsChantier.length} location(s)</Statut>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Section titre="Demandes">
          {demandes.length === 0 ? (
            <EtatVide titre="Aucune demande" />
          ) : (
            <Tableau
              legende="Demandes de ce client"
              entetes={[{ libelle: 'Numero' }, { libelle: 'Chantier' }, { libelle: 'Date' }, { libelle: 'Statut' }]}
            >
              {demandes.map((demande) => (
                <tr key={demande.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link
                      to={`/demandes/${demande.id}`}
                      className="font-medium text-alfa-ink hover:underline"
                    >
                      {demande.numero}
                    </Link>
                  </Cellule>
                  <Cellule>
                    <span className="text-alfa-slate">{reference.nomChantier(demande.chantierId)}</span>
                  </Cellule>
                  <Cellule>
                    <span className="whitespace-nowrap text-alfa-slate">
                      {formatDate(demande.dateSouhaitee)}
                    </span>
                  </Cellule>
                  <Cellule>
                    <StatutDemandeBadge statut={demande.statut} />
                  </Cellule>
                </tr>
              ))}
            </Tableau>
          )}
        </Section>

        <Section titre="Sorties et locations">
          {sorties.length === 0 ? (
            <EtatVide titre="Aucune sortie" />
          ) : (
            <Tableau
              legende="Bons de livraison et locations de ce client"
              entetes={[{ libelle: 'Bon' }, { libelle: 'Statut bon' }, { libelle: 'Location' }, { libelle: 'Statut location' }]}
            >
              {sorties.map((sortie) => {
                const location = locations.find((l) => l.sortieId === sortie.id);
                return (
                  <tr key={sortie.id} className="hover:bg-alfa-surface">
                    <Cellule>
                      <Link
                        to={`/livraisons/${sortie.id}`}
                        className="font-medium text-alfa-ink hover:underline"
                      >
                        {sortie.numero}
                      </Link>
                    </Cellule>
                    <Cellule>
                      <StatutSortieBadge statut={sortie.statut} />
                    </Cellule>
                    <Cellule>
                      {location ? (
                        <Link
                          to={`/locations/${location.id}`}
                          className="text-alfa-slate hover:underline"
                        >
                          {location.numero}
                        </Link>
                      ) : (
                        <span className="text-alfa-muted">Vente ferme</span>
                      )}
                    </Cellule>
                    <Cellule>
                      {location ? <StatutLocationBadge statut={location.statut} /> : '—'}
                    </Cellule>
                  </tr>
                );
              })}
            </Tableau>
          )}
        </Section>
      </div>

      {retours.length > 0 && (
        <Section titre="Retours" className="mt-4">
          <Tableau
            legende="Retours enregistres pour ce client"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Date' },
              { libelle: 'Lignes', alignement: 'droite' },
              { libelle: 'Acceptees', alignement: 'droite' },
              { libelle: 'Statut' },
            ]}
          >
            {retours.map((retour) => (
              <tr key={retour.id} className="hover:bg-alfa-surface">
                <Cellule>{retour.numero}</Cellule>
                <Cellule>
                  <span className="whitespace-nowrap text-alfa-slate">{formatDate(retour.date)}</span>
                </Cellule>
                <Cellule alignement="droite">{retour.lignes.length}</Cellule>
                <Cellule alignement="droite">
                  {somme(retour.lignes, (l) => l.quantiteAcceptee)}
                </Cellule>
                <Cellule>
                  <Statut ton={retour.statut === 'CLOTURE' ? 'succes' : 'attention'}>
                    {retour.statut}
                  </Statut>
                </Cellule>
              </tr>
            ))}
          </Tableau>
        </Section>
      )}
    </Page>
  );
}
