import { useState } from 'react';
import { ArrowRight, ShieldAlert } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { LIBELLE_ROLE, ORGANISATION } from '../../models/referentiel';
import { LOGO_ALFA_BASE64 } from '../../assets/logo';
import type { Role } from '../../models/types';
import { Bouton } from '../../components/ui/primitives';

interface Profil {
  role: Role;
  resume: string;
  taches: string[];
}

/**
 * Chaque profil annonce ce qu'il permet de faire : l'utilisateur entre
 * directement dans son propre perimetre de travail.
 */
const PROFILS: Profil[] = [
  {
    role: 'SECRETARIAT',
    resume: 'Recevoir les demandes, verifier les quantites, suivre les documents.',
    taches: [
      'Creer une demande pour un client et un chantier',
      'Verifier la disponibilite et approuver les quantites',
      'Generer et suivre les bons de livraison',
      'Gerer les clients, les chantiers et les contacts',
    ],
  },
  {
    role: 'COUR',
    resume: 'Preparer, charger, recevoir les retours. Concu pour le telephone et la tablette.',
    taches: [
      'Preparer les commandes ligne par ligne, avec photos',
      'Passer le controle final et confirmer une sortie',
      'Enregistrer un retour et qualifier le materiel',
      'Declarer les manquants et les dommages',
    ],
  },
  {
    role: 'DIRECTION',
    resume: 'Voir l etat reel du parc et decider des ecarts.',
    taches: [
      'Suivre le stock, les locations et les retards',
      'Decider des ecarts : facturer, remplacer, abandonner',
      'Consulter les rapports et le journal d activite',
      'Exporter les donnees pour verification externe',
    ],
  },
  {
    role: 'ADMIN',
    resume: 'Acces complet, ajustements de stock et journal.',
    taches: [
      'Acceder a tous les modules sans restriction',
      'Ajuster le stock avec motif obligatoire',
      'Consulter le journal d activite complet',
      'Reinitialiser les donnees de demonstration',
    ],
  },
];

export function ChoixProfil() {
  const choisirProfil = useBoutique((e) => e.choisirProfil);
  const [selection, setSelection] = useState<Role | null>(null);

  return (
    <div className="flex min-h-screen flex-col bg-alfa-surface">
      <main className="mx-auto flex w-full max-w-4xl flex-1 flex-col justify-center px-4 py-8 sm:py-12">
        <header className="mb-6 text-center">
          <img
            src={LOGO_ALFA_BASE64}
            alt={ORGANISATION.marque}
            className="mx-auto h-12 w-auto sm:h-14"
          />
          <h1 className="mt-4 text-xl font-semibold tracking-tight text-alfa-ink sm:text-2xl">
            ALFA Flow
          </h1>
          <p className="mt-1.5 text-sm text-alfa-slate">
            Choisissez votre profil pour acceder a vos taches.
          </p>
        </header>

        <ul className="grid gap-3 sm:grid-cols-2">
          {PROFILS.map((profil) => {
            const actif = selection === profil.role;
            return (
              <li key={profil.role}>
                <button
                  type="button"
                  onClick={() => setSelection(profil.role)}
                  onDoubleClick={() => choisirProfil(profil.role)}
                  aria-pressed={actif}
                  className={`flex h-full w-full flex-col gap-2 rounded-alfa border p-4 text-left transition-colors ${
                    actif
                      ? 'border-alfa-red bg-white shadow-panel'
                      : 'border-alfa-line bg-white hover:border-alfa-slate'
                  }`}
                >
                  <span className="flex items-start justify-between gap-2">
                    <span className="font-semibold text-alfa-ink">{LIBELLE_ROLE[profil.role]}</span>
                    <span
                      aria-hidden="true"
                      className={`mt-0.5 h-4 w-4 flex-none rounded-full border-2 ${
                        actif ? 'border-alfa-red bg-alfa-red' : 'border-alfa-line'
                      }`}
                    />
                  </span>
                  <span className="text-sm text-alfa-slate">{profil.resume}</span>
                  <ul className="mt-1 space-y-1">
                    {profil.taches.map((tache) => (
                      <li key={tache} className="flex gap-1.5 text-xs text-alfa-muted">
                        <span aria-hidden="true" className="text-alfa-red">
                          —
                        </span>
                        {tache}
                      </li>
                    ))}
                  </ul>
                </button>
              </li>
            );
          })}
        </ul>

        <div className="mt-5 flex justify-center">
          <Bouton
            variante="principal"
            disabled={!selection}
            onClick={() => selection && choisirProfil(selection)}
            icone={<ArrowRight aria-hidden="true" className="h-4 w-4" />}
            className="w-full sm:w-auto sm:px-8"
          >
            {selection ? `Entrer comme ${LIBELLE_ROLE[selection].toLowerCase()}` : 'Choisissez un profil'}
          </Bouton>
        </div>

        <p className="mx-auto mt-6 flex max-w-xl items-start gap-2 rounded-alfa border border-alfa-line bg-white px-3 py-2.5 text-xs text-alfa-slate">
          <ShieldAlert aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-alfa-muted" />
          <span>
            <strong className="font-semibold text-alfa-ink">Demonstration.</strong> Ce choix de
            profil n'est pas une authentification : il adapte l'affichage et les actions
            disponibles. Le systeme de production exigera un compte et un mot de passe, verifies
            par le serveur. Vous pourrez changer de profil a tout moment depuis l'en-tete.
          </span>
        </p>
      </main>

      <footer className="pb-6 text-center text-xs text-alfa-muted">
        {ORGANISATION.marque} — {ORGANISATION.descripteur}
      </footer>
    </div>
  );
}
