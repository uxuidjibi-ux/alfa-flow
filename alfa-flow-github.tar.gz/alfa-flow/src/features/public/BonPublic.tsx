import { useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  AlertTriangle,
  Check,
  CircleAlert,
  Download,
  FileText,
  Link2Off,
  Printer,
  ShieldAlert,
} from 'lucide-react';
import { useBoutique } from '../../state/store';
import { signerBon } from '../../services/operations';
import { imprimerBon, telechargerBon } from '../../services/pdf';
import { CONDITIONS_BON, ORGANISATION } from '../../models/referentiel';
import type { ReceptionLigne } from '../../models/types';
import { ZoneSignature } from '../../components/ui/ZoneSignature';
import { formatDate, formatDateHeure } from '../../utils';

/**
 * ECRAN 7 — page client par lien securise simule.
 *
 * Isolee de l'administration : aucune barre laterale, aucun selecteur de role,
 * aucune donnee d'un autre client. Le signataire verifie chaque ligne, signale
 * un ecart s'il y a lieu, puis confirme la reception et signe.
 *
 * SIMULATION DE DEMONSTRATION : le jeton n'est ni signe, ni expirable, ni
 * revocable, et la signature n'a aucune valeur juridique (voir ASSUMPTIONS.md).
 */
export function BonPublic() {
  const { jeton } = useParams<{ jeton: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);

  const sortie = useMemo(
    () => donnees.sorties.find((s) => s.jetonPublic === jeton),
    [donnees.sorties, jeton],
  );

  const [nom, setNom] = useState('');
  const [signature, setSignature] = useState<string | null>(null);
  const [consentement, setConsentement] = useState(false);
  const [reception, setReception] = useState<Record<string, ReceptionLigne>>({});
  const [erreur, setErreur] = useState<string | null>(null);

  if (!sortie) {
    return (
      <CadrePublic>
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <Link2Off aria-hidden="true" className="h-8 w-8 text-alfa-muted" />
          <h1 className="text-lg font-semibold text-alfa-ink">Lien invalide ou expire</h1>
          <p className="max-w-md text-sm text-alfa-slate">
            Ce lien de consultation ne correspond a aucun bon de livraison. Contactez le
            secretariat de {ORGANISATION.marque} au {ORGANISATION.telephone} pour en obtenir un
            nouveau.
          </p>
        </div>
      </CadrePublic>
    );
  }

  const client = donnees.clients.find((c) => c.id === sortie.clientId);
  const chantier = donnees.chantiers.find((c) => c.id === sortie.chantierId);
  const contact = donnees.contacts.find((c) => c.id === chantier?.contactId);
  const preparateur = donnees.utilisateurs.find((u) => u.id === sortie.preparateurId);
  const demande = donnees.demandes.find((d) => d.id === sortie.demandeId);
  const dejaSigne = sortie.statut === 'SIGNEE';

  const donneesBon = {
    sortie,
    client: client!,
    chantier: chantier!,
    contact,
    produits: donnees.produits,
    preparateur,
    referenceDemande: demande?.numero ?? '—',
  };

  const ligneReception = (ligneId: string, quantite: number): ReceptionLigne =>
    reception[ligneId] ?? {
      ligneSortieId: ligneId,
      quantiteConstatee: quantite,
      conforme: true,
      commentaire: '',
    };

  const majReception = (ligneId: string, patch: Partial<ReceptionLigne>, quantite: number) => {
    setReception((courant) => ({
      ...courant,
      [ligneId]: { ...ligneReception(ligneId, quantite), ...patch },
    }));
  };

  const ecarts = Object.values(reception).filter((r) => !r.conforme);
  const totalExpedie = sortie.lignes.reduce((t, l) => t + l.quantite, 0);
  const totalAVenir = sortie.lignes.reduce((t, l) => t + l.quantiteAVenir, 0);

  const confirmer = () => {
    if (!nom.trim()) {
      setErreur('Indiquez votre nom en lettres moulees avant de confirmer la reception.');
      return;
    }
    if (!consentement) {
      setErreur(
        'Cochez la case de consentement : vous devez confirmer avoir verifie les quantites recues.',
      );
      return;
    }
    if (!signature) {
      setErreur('Tracez votre signature dans la zone prevue avant de confirmer.');
      return;
    }
    const manquantes = ecarts.filter((e) => !e.commentaire.trim());
    if (manquantes.length > 0) {
      setErreur(
        `Precisez le motif pour ${manquantes.length} ligne(s) signalee(s) comme non conforme(s).`,
      );
      return;
    }
    setErreur(null);

    const resultat = signerBon(
      donnees,
      sortie.id,
      {
        nom: nom.trim(),
        lettresMoulees: nom.trim().toUpperCase(),
        dataUrl: signature,
        reception: Object.values(reception),
      },
      { utilisateurId: 'client_externe', appareil: 'Lien client (navigateur)' },
    );
    appliquer(resultat, 'Reception confirmee. Merci.');
  };

  return (
    <CadrePublic>
      {/* ---------------------------------------------------------- En-tete */}
      <header className="flex flex-col gap-4 border-b border-alfa-line pb-5 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-4">
          <img
            src="/marque/alfa-logo.png"
            alt={`${ORGANISATION.marque} — ${ORGANISATION.descripteur}`}
            className="h-12 w-auto"
          />
          <div className="text-xs leading-relaxed text-alfa-slate">
            <p className="font-semibold text-alfa-ink">{ORGANISATION.raisonSociale}</p>
            <p>{ORGANISATION.adresse}</p>
            <p>{ORGANISATION.ville}</p>
            <p>Tel. : {ORGANISATION.telephone}</p>
          </div>
        </div>

        <div className="sm:text-right">
          <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
            Bon de livraison
          </p>
          <p className="text-2xl font-bold tabular-nums text-alfa-red">{sortie.numero}</p>
          <p className="text-sm text-alfa-slate">Date : {formatDate(sortie.dateSortie)}</p>
        </div>
      </header>

      {/* ------------------------------------------------ Bandeau simulation */}
      <p className="mt-4 flex items-start gap-2 rounded-alfa border border-alfa-line bg-alfa-surface px-3 py-2 text-xs text-alfa-slate">
        <ShieldAlert aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none" />
        <span>
          <strong className="font-semibold text-alfa-ink">Simulation de demonstration.</strong> Ce
          lien n'est ni signe, ni expirable, ni revocable, et la signature recueillie ne constitue
          pas un dispositif de signature juridiquement qualifie.
        </span>
      </p>

      {dejaSigne && (
        <p className="mt-4 flex items-start gap-2 rounded-alfa border border-etat-succes/30 bg-etat-succes/5 px-3 py-2 text-sm text-alfa-ink">
          <Check aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-etat-succes" />
          <span>
            Reception confirmee par <strong>{sortie.signataireNom}</strong> le{' '}
            {formatDateHeure(sortie.dateSignature)}.
          </span>
        </p>
      )}

      {/* ------------------------------------------------ Client et chantier */}
      <section className="mt-6 grid gap-4 sm:grid-cols-2">
        <Bloc titre="Vendu a">
          <p className="font-medium text-alfa-ink">{client?.nom}</p>
          {contact && <p>{contact.nom}</p>}
          <p>{client?.ville}</p>
          <p>Tel. : {client?.telephone}</p>
        </Bloc>
        <Bloc titre="Expedie a">
          <p className="font-medium text-alfa-ink">{chantier?.nom}</p>
          <p>{sortie.expedieA || chantier?.adresse}</p>
          <p>{chantier?.ville}</p>
          {sortie.expedieVia && <p>Expedie via : {sortie.expedieVia}</p>}
        </Bloc>
      </section>

      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 rounded-alfa border border-alfa-line px-3 py-3 text-sm sm:grid-cols-4">
        <Donnee terme="Bon de comm. client" valeur={sortie.bonCommandeClient} />
        <Donnee terme="# comm. Alfa" valeur={sortie.commandeAlfa} />
        <Donnee terme="Representant" valeur={sortie.representant} />
        <Donnee terme="Termes" valeur={sortie.termes} />
      </dl>

      {/* ------------------------------------------------------ Verification */}
      <section className="mt-8">
        <h2 className="text-base font-semibold text-alfa-ink">Verifiez les quantites recues</h2>
        <p className="mt-1 text-sm text-alfa-slate">
          Chaque ligne est conforme par defaut. Signalez toute difference constatee a la
          reception : l'ecart part immediatement au secretariat.
        </p>

        <ul className="mt-4 space-y-3">
          {sortie.lignes.map((ligne) => {
            const produit = donnees.produits.find((p) => p.id === ligne.produitId);
            const etat = ligneReception(ligne.id, ligne.quantite);
            return (
              <li key={ligne.id} className="rounded-alfa border border-alfa-line p-3 sm:p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium text-alfa-ink">{produit?.nom ?? ligne.produitId}</p>
                    <p className="mt-0.5 text-xs text-alfa-muted">
                      Code {produit?.codeItem} · {ligne.typeItem === 'ACHAT' ? 'Achat' : 'Location'}
                      {produit?.dimensions ? ` · ${produit.dimensions}` : ''}
                      {produit?.couleur ? ` · ${produit.couleur}` : ''}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-4 text-right text-sm">
                    <Quantite terme="Commandee" valeur={ligne.quantiteCommandee} />
                    <Quantite terme="Expediee" valeur={ligne.quantite} accent />
                    {ligne.quantiteAVenir > 0 && (
                      <Quantite terme="A venir" valeur={ligne.quantiteAVenir} alerte />
                    )}
                  </div>
                </div>

                {!dejaSigne && (
                  <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-alfa-line pt-3">
                    <BoutonChoix
                      actif={etat.conforme}
                      onClick={() =>
                        majReception(
                          ligne.id,
                          { conforme: true, quantiteConstatee: ligne.quantite, commentaire: '' },
                          ligne.quantite,
                        )
                      }
                    >
                      <Check aria-hidden="true" className="h-4 w-4" />
                      Conforme
                    </BoutonChoix>
                    <BoutonChoix
                      actif={!etat.conforme}
                      alerte
                      onClick={() => majReception(ligne.id, { conforme: false }, ligne.quantite)}
                    >
                      <CircleAlert aria-hidden="true" className="h-4 w-4" />
                      Quantite differente
                    </BoutonChoix>

                    {!etat.conforme && (
                      <div className="flex w-full flex-col gap-2 sm:flex-row sm:items-center">
                        <label className="flex items-center gap-2 text-sm text-alfa-slate">
                          <span>Quantite recue</span>
                          <input
                            type="number"
                            min={0}
                            inputMode="numeric"
                            value={etat.quantiteConstatee}
                            onChange={(e) =>
                              majReception(
                                ligne.id,
                                { quantiteConstatee: Number(e.target.value) },
                                ligne.quantite,
                              )
                            }
                            className="min-h-[44px] w-24 rounded-alfa border border-alfa-line px-2 text-right tabular-nums focus:border-alfa-red focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
                          />
                        </label>
                        <label className="flex flex-1 items-center gap-2 text-sm text-alfa-slate">
                          <span className="sr-only">Motif de l'ecart</span>
                          <input
                            type="text"
                            value={etat.commentaire}
                            placeholder="Motif (obligatoire) : materiel manquant, endommage..."
                            onChange={(e) =>
                              majReception(ligne.id, { commentaire: e.target.value }, ligne.quantite)
                            }
                            className="min-h-[44px] w-full rounded-alfa border border-alfa-line px-3 focus:border-alfa-red focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
                          />
                        </label>
                      </div>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>

        <div className="mt-4 flex flex-wrap justify-end gap-6 border-t border-alfa-line pt-3 text-sm">
          <p className="text-alfa-slate">
            Total expedie : <strong className="tabular-nums text-alfa-ink">{totalExpedie}</strong>{' '}
            unite(s)
          </p>
          {totalAVenir > 0 && (
            <p className="text-alfa-red">
              Reste a venir : <strong className="tabular-nums">{totalAVenir}</strong> unite(s)
            </p>
          )}
        </div>
      </section>

      {/* ------------------------------------------------------- Conditions */}
      <section className="mt-6 rounded-alfa border border-alfa-line bg-alfa-surface p-3 text-xs leading-relaxed text-alfa-slate">
        <h2 className="mb-1.5 text-micro font-semibold uppercase tracking-wide text-alfa-muted">
          Location / Achat — conditions
        </h2>
        <p>{CONDITIONS_BON.achat}</p>
        <p className="mt-1">{CONDITIONS_BON.location}</p>
        <p className="mt-1">{CONDITIONS_BON.transport}</p>
      </section>

      {/* -------------------------------------------------------- Signature */}
      {!dejaSigne && (
        <section className="mt-8">
          <h2 className="text-base font-semibold text-alfa-ink">Confirmation de reception</h2>

          {ecarts.length > 0 && (
            <p className="mt-3 flex items-start gap-2 rounded-alfa border border-etat-attention/40 bg-etat-attention/5 px-3 py-2 text-sm text-alfa-ink">
              <AlertTriangle aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-etat-attention" />
              <span>
                {ecarts.length} ligne(s) signalee(s) comme non conforme(s). Votre signature vaut
                confirmation des quantites reellement recues, pas des quantites expediees.
              </span>
            </p>
          )}

          <div className="mt-4 grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="nom-signataire" className="block text-sm font-medium text-alfa-ink">
                Nom en lettres moulees
              </label>
              <input
                id="nom-signataire"
                type="text"
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                autoComplete="name"
                aria-describedby="aide-nom"
                className="mt-1.5 min-h-[44px] w-full rounded-alfa border border-alfa-line px-3 uppercase focus:border-alfa-red focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
              />
              <p id="aide-nom" className="mt-1 text-xs text-alfa-muted">
                Personne presente a la reception du materiel.
              </p>

              <label className="mt-4 flex items-start gap-2.5 text-sm text-alfa-slate">
                <input
                  type="checkbox"
                  checked={consentement}
                  onChange={(e) => setConsentement(e.target.checked)}
                  className="mt-0.5 h-5 w-5 rounded border-alfa-line text-alfa-red focus:ring-2 focus:ring-alfa-red/30"
                />
                <span>
                  Je confirme avoir verifie les quantites recues et accepter les conditions de
                  location et d'achat ci-dessus.
                </span>
              </label>
            </div>

            <ZoneSignature onChange={setSignature} label="Signature du client" />
          </div>

          {erreur && (
            <p
              role="alert"
              className="mt-4 flex items-start gap-2 rounded-alfa border border-alfa-red/40 bg-alfa-redSoft px-3 py-2 text-sm text-alfa-ink"
            >
              <CircleAlert aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none text-alfa-red" />
              {erreur}
            </p>
          )}

          <button
            type="button"
            onClick={confirmer}
            className="mt-5 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-alfa bg-alfa-red px-6 font-semibold text-white transition-colors hover:bg-alfa-redDark focus:outline-none focus:ring-2 focus:ring-alfa-red/40 focus:ring-offset-2 sm:w-auto"
          >
            <Check aria-hidden="true" className="h-5 w-5" />
            Confirmer la reception et signer
          </button>
        </section>
      )}

      {/* ------------------------------------------------------- Documents */}
      <section className="mt-8 flex flex-wrap gap-3 border-t border-alfa-line pt-5">
        <button
          type="button"
          onClick={() => telechargerBon(donneesBon)}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-alfa border border-alfa-line px-4 text-sm font-medium text-alfa-ink hover:bg-alfa-surface focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
        >
          <Download aria-hidden="true" className="h-4 w-4" />
          Telecharger le PDF
        </button>
        <button
          type="button"
          onClick={() => imprimerBon(donneesBon)}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-alfa border border-alfa-line px-4 text-sm font-medium text-alfa-ink hover:bg-alfa-surface focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
        >
          <Printer aria-hidden="true" className="h-4 w-4" />
          Imprimer
        </button>
        <p className="flex items-center gap-1.5 text-xs text-alfa-muted">
          <FileText aria-hidden="true" className="h-3.5 w-3.5" />
          Version {sortie.version} du document
        </p>
      </section>
    </CadrePublic>
  );
}

/* ----------------------------------------------------- Elements internes */

function CadrePublic({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-alfa-surface py-6 px-4 sm:py-10">
      <main className="mx-auto max-w-3xl rounded-alfa border border-alfa-line bg-white p-4 shadow-panel sm:p-8">
        {children}
      </main>
      <p className="mx-auto mt-4 max-w-3xl text-center text-xs text-alfa-muted">
        {ORGANISATION.marque} — {ORGANISATION.descripteur}
      </p>
    </div>
  );
}

function Bloc({ titre, children }: { titre: string; children: React.ReactNode }) {
  return (
    <div className="rounded-alfa border border-alfa-line p-3">
      <h2 className="mb-1.5 text-micro font-semibold uppercase tracking-wide text-alfa-muted">
        {titre}
      </h2>
      <div className="space-y-0.5 text-sm text-alfa-slate">{children}</div>
    </div>
  );
}

function Donnee({ terme, valeur }: { terme: string; valeur: string }) {
  return (
    <div>
      <dt className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">{terme}</dt>
      <dd className="text-alfa-ink">{valeur || '—'}</dd>
    </div>
  );
}

function Quantite({
  terme,
  valeur,
  accent,
  alerte,
}: {
  terme: string;
  valeur: number;
  accent?: boolean;
  alerte?: boolean;
}) {
  return (
    <div>
      <p className="text-micro uppercase tracking-wide text-alfa-muted">{terme}</p>
      <p
        className={`tabular-nums ${
          alerte ? 'font-semibold text-alfa-red' : accent ? 'font-semibold text-alfa-ink' : 'text-alfa-slate'
        }`}
      >
        {valeur}
      </p>
    </div>
  );
}

function BoutonChoix({
  actif,
  alerte,
  onClick,
  children,
}: {
  actif: boolean;
  alerte?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  const base =
    'inline-flex min-h-[44px] items-center gap-1.5 rounded-alfa border px-3 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-alfa-red/30';
  const style = actif
    ? alerte
      ? 'border-alfa-red bg-alfa-redSoft text-alfa-ink'
      : 'border-etat-succes bg-etat-succes/10 text-alfa-ink'
    : 'border-alfa-line text-alfa-slate hover:bg-alfa-surface';
  return (
    <button type="button" onClick={onClick} aria-pressed={actif} className={`${base} ${style}`}>
      {children}
    </button>
  );
}
