import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Grid2x2, List, Search, Trash2 } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useReferentiel, useStocks } from '../../state/selecteurs';
import {
  Bouton,
  Champ,
  ChampSelection,
  ChampTexte,
  CompteurQuantite,
  Donnee,
  EtatVide,
  Message,
  Page,
  Section,
  Statut,
} from '../../components/ui/primitives';
import { TypeItemBadge } from '../../components/ui/statuts';
import { VignetteProduit } from '../catalog/Catalogue';
import { enregistrerDemande, soumettreDemande } from '../../services/operations';
import { aujourdHui, contient, formatDate, id, jourPlus, numeroSuivant, somme } from '../../utils';
import type { Demande, LigneDemande, TypeItem } from '../../models/types';

const ETAPES = [
  'Client',
  'Chantier',
  'Date et informations',
  'Produits',
  'Quantites',
  'Notes',
  'Recapitulatif',
];

/** ECRAN 4 — parcours de creation d'une demande, en sept etapes. */
export function AssistantDemande() {
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const notifier = useBoutique((e) => e.notifier);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const stocks = useStocks();
  const naviguer = useNavigate();
  const [parametres] = useSearchParams();

  const [etape, setEtape] = useState(0);
  const [clientId, setClientId] = useState(parametres.get('client') ?? '');
  const [chantierId, setChantierId] = useState('');
  const [contactId, setContactId] = useState('');
  const [dateSouhaitee, setDateSouhaitee] = useState(jourPlus(3));
  const [notes, setNotes] = useState('');
  const [lignes, setLignes] = useState<LigneDemande[]>([]);
  const [requete, setRequete] = useState('');
  const [affichage, setAffichage] = useState<'liste' | 'galerie'>('liste');
  const [erreur, setErreur] = useState<string | null>(null);

  const contexte = { utilisateurId: utilisateur.id, appareil: 'Poste web' };
  const chantiers = donnees.chantiers.filter((c) => c.clientId === clientId);
  const contacts = donnees.contacts.filter((c) => c.clientId === clientId);

  const resultats = useMemo(() => {
    if (requete.trim().length < 2) return [];
    return donnees.produits
      .filter((produit) =>
        contient(
          `${produit.nom} ${produit.codeItem} ${produit.famille} ${produit.dimensions} ${produit.couleur}`,
          requete,
        ),
      )
      .slice(0, 24);
  }, [donnees.produits, requete]);

  const ajouter = (produitId: string) => {
    if (lignes.some((l) => l.produitId === produitId)) {
      notifier('info', 'Cet article est deja dans la demande.');
      return;
    }
    setLignes((courant) => [
      ...courant,
      {
        id: id('ldem'),
        produitId,
        typeItem: 'LOCATION',
        quantiteDemandee: 1,
        quantiteApprouvee: null,
        note: '',
      },
    ]);
  };

  const majLigne = (ligneId: string, patch: Partial<LigneDemande>) =>
    setLignes((courant) => courant.map((l) => (l.id === ligneId ? { ...l, ...patch } : l)));

  const retirer = (ligneId: string) =>
    setLignes((courant) => courant.filter((l) => l.id !== ligneId));

  const valider = (): boolean => {
    if (etape === 0 && !clientId) {
      setErreur('Selectionnez un client avant de continuer.');
      return false;
    }
    if (etape === 1 && !chantierId) {
      setErreur('Selectionnez un chantier : une demande porte toujours un chantier.');
      return false;
    }
    if (etape === 2 && !dateSouhaitee) {
      setErreur('Indiquez la date souhaitee de mise a disposition.');
      return false;
    }
    if (etape === 3 && lignes.length === 0) {
      setErreur('Ajoutez au moins un article a la demande.');
      return false;
    }
    if (etape === 4 && lignes.some((l) => l.quantiteDemandee <= 0)) {
      setErreur('Chaque ligne doit porter une quantite superieure a zero, ou etre retiree.');
      return false;
    }
    setErreur(null);
    return true;
  };

  const construireDemande = (statut: Demande['statut']): { demande: Demande; compteurs: Record<string, number> } => {
    const suite = numeroSuivant(donnees.compteurs, 'DEM', new Date().getFullYear());
    return {
      compteurs: suite.compteurs,
      demande: {
        id: id('dem'),
        numero: suite.numero,
        clientId,
        chantierId,
        contactId: contactId || null,
        dateSouhaitee,
        dateCreation: new Date().toISOString(),
        statut,
        lignes,
        notes,
        piecesJointes: [],
        creeParId: utilisateur.id,
      },
    };
  };

  const enregistrer = (statut: Demande['statut']) => {
    const { demande, compteurs } = construireDemande(statut);
    const resultat = enregistrerDemande({ ...donnees, compteurs }, demande, contexte);
    if (!appliquer(resultat, `Demande ${demande.numero} enregistree.`)) return;
    if (statut === 'A_VERIFIER') {
      // Le brouillon est cree puis soumis, ce qui trace les deux etapes au journal.
      const apres = soumettreDemande(resultat.valeur!, demande.id, contexte);
      if (apres.ok) appliquer(apres, `Demande ${demande.numero} soumise pour verification.`);
    }
    naviguer(`/demandes/${demande.id}`);
  };

  const totalDemande = somme(lignes, (l) => l.quantiteDemandee);

  return (
    <Page
      titre="Nouvelle demande"
      fil={[{ libelle: 'Demandes', lien: '/demandes' }, { libelle: 'Nouvelle demande' }]}
      description="Un client, un chantier. Aucune quantite n'est reservee avant la verification interne."
    >
      {/* --------------------------------------------------------- Etapes */}
      <ol className="mb-4 flex flex-wrap gap-1.5" aria-label="Etapes de la demande">
        {ETAPES.map((libelle, index) => (
          <li key={libelle}>
            <span
              aria-current={index === etape ? 'step' : undefined}
              className={`inline-flex min-h-[36px] items-center gap-1.5 rounded-alfa border px-2.5 text-sm ${
                index === etape
                  ? 'border-alfa-red bg-alfa-redSoft font-medium text-alfa-redDark'
                  : index < etape
                    ? 'border-alfa-line bg-white text-alfa-slate'
                    : 'border-alfa-line bg-alfa-surface text-alfa-muted'
              }`}
            >
              <span className="tabular-nums">{index + 1}</span>
              {libelle}
              {index < etape && <Check aria-hidden="true" className="h-3.5 w-3.5" />}
            </span>
          </li>
        ))}
      </ol>

      {erreur && (
        <div className="mb-4">
          <Message ton="erreur" titre={erreur} />
        </div>
      )}

      <Section>
        <div className="p-4">
          {/* Etape 1 — client */}
          {etape === 0 && (
            <div className="space-y-3">
              <p className="text-sm text-alfa-slate">Pour quel client cette demande est-elle creee ?</p>
              <ul className="grid gap-2 sm:grid-cols-2">
                {donnees.clients.map((client) => (
                  <li key={client.id}>
                    <button
                      type="button"
                      onClick={() => {
                        setClientId(client.id);
                        setChantierId('');
                        setContactId('');
                      }}
                      aria-pressed={clientId === client.id}
                      className={`w-full rounded-alfa border p-3 text-left transition-colors ${
                        clientId === client.id
                          ? 'border-alfa-red bg-alfa-redSoft'
                          : 'border-alfa-line hover:bg-alfa-surface'
                      }`}
                    >
                      <span className="block font-medium text-alfa-ink">{client.nom}</span>
                      <span className="block text-xs text-alfa-muted">
                        {client.code} · {client.ville}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Etape 2 — chantier */}
          {etape === 1 && (
            <div className="space-y-3">
              <p className="text-sm text-alfa-slate">
                Chantier de destination pour {reference.nomClient(clientId)}.
              </p>
              {chantiers.length === 0 ? (
                <EtatVide titre="Ce client n'a aucun chantier actif" />
              ) : (
                <ul className="grid gap-2 sm:grid-cols-2">
                  {chantiers.map((chantier) => (
                    <li key={chantier.id}>
                      <button
                        type="button"
                        onClick={() => {
                          setChantierId(chantier.id);
                          setContactId(chantier.contactId ?? '');
                        }}
                        aria-pressed={chantierId === chantier.id}
                        className={`w-full rounded-alfa border p-3 text-left transition-colors ${
                          chantierId === chantier.id
                            ? 'border-alfa-red bg-alfa-redSoft'
                            : 'border-alfa-line hover:bg-alfa-surface'
                        }`}
                      >
                        <span className="block font-medium text-alfa-ink">{chantier.nom}</span>
                        <span className="block text-xs text-alfa-muted">
                          {chantier.adresse}, {chantier.ville}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* Etape 3 — date et informations */}
          {etape === 2 && (
            <div className="grid gap-4 sm:grid-cols-2">
              <Champ
                etiquette="Date souhaitee de mise a disposition"
                type="date"
                min={aujourdHui()}
                value={dateSouhaitee}
                onChange={(e) => setDateSouhaitee(e.target.value)}
              />
              <ChampSelection
                etiquette="Contact sur le chantier"
                value={contactId}
                onChange={(e) => setContactId(e.target.value)}
                aide="Ce contact pourra signer la reception du materiel."
              >
                <option value="">Aucun contact designe</option>
                {contacts.map((contact) => (
                  <option key={contact.id} value={contact.id}>
                    {contact.nom} — {contact.fonction}
                    {contact.signataire ? ' (signataire)' : ''}
                  </option>
                ))}
              </ChampSelection>
            </div>
          )}

          {/* Etape 4 — produits */}
          {etape === 3 && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-end gap-3">
                <div className="min-w-[220px] flex-1">
                  <label htmlFor="recherche-produits" className="etiquette-champ">
                    Rechercher un article
                  </label>
                  <div className="relative mt-1.5">
                    <Search
                      aria-hidden="true"
                      className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-alfa-muted"
                    />
                    <input
                      id="recherche-produits"
                      type="search"
                      value={requete}
                      onChange={(e) => setRequete(e.target.value)}
                      placeholder="Nom, code, dimension…"
                      className="champ pl-9"
                    />
                  </div>
                </div>
                <div className="flex rounded-alfa border border-alfa-line" role="group" aria-label="Affichage">
                  <button
                    type="button"
                    onClick={() => setAffichage('liste')}
                    aria-pressed={affichage === 'liste'}
                    className={`flex min-h-[44px] items-center gap-1.5 rounded-l-alfa px-3 text-sm ${
                      affichage === 'liste' ? 'bg-alfa-surface font-medium' : 'text-alfa-slate'
                    }`}
                  >
                    <List aria-hidden="true" className="h-4 w-4" />
                    Liste
                  </button>
                  <button
                    type="button"
                    onClick={() => setAffichage('galerie')}
                    aria-pressed={affichage === 'galerie'}
                    className={`flex min-h-[44px] items-center gap-1.5 rounded-r-alfa border-l border-alfa-line px-3 text-sm ${
                      affichage === 'galerie' ? 'bg-alfa-surface font-medium' : 'text-alfa-slate'
                    }`}
                  >
                    <Grid2x2 aria-hidden="true" className="h-4 w-4" />
                    Galerie
                  </button>
                </div>
              </div>

              {requete.trim().length < 2 ? (
                <p className="text-sm text-alfa-slate">
                  Saisissez au moins deux caracteres pour rechercher parmi les{' '}
                  {donnees.produits.length} articles.
                </p>
              ) : resultats.length === 0 ? (
                <EtatVide titre={`Aucun article ne correspond a « ${requete} »`} />
              ) : affichage === 'liste' ? (
                <ul className="divide-y divide-alfa-line rounded-alfa border border-alfa-line">
                  {resultats.map((produit) => {
                    const stock = stocks.get(produit.id);
                    const dejaAjoute = lignes.some((l) => l.produitId === produit.id);
                    return (
                      <li key={produit.id} className="flex flex-wrap items-center gap-3 p-2.5">
                        <span className="min-w-0 flex-1">
                          <span className="block font-medium text-alfa-ink">{produit.nom}</span>
                          <span className="block text-xs text-alfa-muted">
                            {produit.codeItem} · {produit.emplacement}
                          </span>
                        </span>
                        <Statut ton={(stock?.disponible ?? 0) > 0 ? 'succes' : 'critique'}>
                          {stock?.disponible ?? 0} disponible(s)
                        </Statut>
                        <Bouton
                          compact
                          variante={dejaAjoute ? 'discret' : 'secondaire'}
                          disabled={dejaAjoute}
                          onClick={() => ajouter(produit.id)}
                        >
                          {dejaAjoute ? 'Deja ajoute' : 'Ajouter'}
                        </Bouton>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                  {resultats.map((produit) => {
                    const stock = stocks.get(produit.id);
                    return (
                      <li key={produit.id} className="overflow-hidden rounded-alfa border border-alfa-line">
                        <VignetteProduit produit={produit} />
                        <div className="space-y-1.5 p-2.5">
                          <p className="line-clamp-2 text-sm font-medium text-alfa-ink">{produit.nom}</p>
                          <Statut ton={(stock?.disponible ?? 0) > 0 ? 'succes' : 'critique'}>
                            {stock?.disponible ?? 0} dispo.
                          </Statut>
                          <Bouton compact className="w-full" onClick={() => ajouter(produit.id)}>
                            Ajouter
                          </Bouton>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}

              {lignes.length > 0 && (
                <p className="text-sm text-alfa-slate">
                  {lignes.length} article(s) dans la demande. Passez a l'etape suivante pour ajuster
                  les quantites.
                </p>
              )}
            </div>
          )}

          {/* Etape 5 — quantites */}
          {etape === 4 && (
            <ul className="space-y-3">
              {lignes.map((ligne) => {
                const produit = reference.produit(ligne.produitId);
                const stock = stocks.get(ligne.produitId);
                const excede = ligne.quantiteDemandee > (stock?.disponible ?? 0);
                return (
                  <li key={ligne.id} className="rounded-alfa border border-alfa-line p-3">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-medium text-alfa-ink">{produit?.nom}</p>
                        <p className="text-xs text-alfa-muted">
                          {produit?.codeItem} · {stock?.disponible ?? 0} disponible(s)
                        </p>
                      </div>
                      <Bouton
                        compact
                        variante="discret"
                        onClick={() => retirer(ligne.id)}
                        icone={<Trash2 aria-hidden="true" className="h-4 w-4" />}
                      >
                        Retirer
                      </Bouton>
                    </div>

                    <div className="mt-3 grid gap-3 sm:grid-cols-2">
                      <div>
                        <p className="mb-1.5 text-sm font-medium text-alfa-ink">Quantite demandee</p>
                        <CompteurQuantite
                          etiquette={`Quantite pour ${produit?.nom ?? ''}`}
                          valeur={ligne.quantiteDemandee}
                          onChange={(valeur) => majLigne(ligne.id, { quantiteDemandee: valeur })}
                        />
                      </div>
                      <ChampSelection
                        etiquette="Type"
                        value={ligne.typeItem}
                        onChange={(e) => majLigne(ligne.id, { typeItem: e.target.value as TypeItem })}
                        aide="Une ligne en achat ne revient jamais et n'entre dans aucune location."
                      >
                        <option value="LOCATION">Location</option>
                        <option value="ACHAT">Achat</option>
                      </ChampSelection>
                    </div>

                    {excede && (
                      <p className="mt-2 text-sm text-alfa-redDark">
                        {ligne.quantiteDemandee} unites demandees pour {stock?.disponible ?? 0}{' '}
                        disponibles. La demande reste possible : la quantite sera ajustee a la
                        verification.
                      </p>
                    )}
                  </li>
                );
              })}
            </ul>
          )}

          {/* Etape 6 — notes */}
          {etape === 5 && (
            <div className="space-y-4">
              <ChampTexte
                etiquette="Notes pour la cour et le secretariat"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                aide="Contraintes d acces, horaire de livraison, personne a joindre sur place…"
              />
              <Message
                ton="info"
                titre="Pieces jointes"
                details={[
                  'Le demonstrateur ne televerse pas de fichier : les pieces jointes sont simulees.',
                ]}
              />
            </div>
          )}

          {/* Etape 7 — recapitulatif */}
          {etape === 6 && (
            <div className="space-y-4">
              <dl className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                <Donnee terme="Client" valeur={reference.nomClient(clientId)} accent />
                <Donnee terme="Chantier" valeur={reference.nomChantier(chantierId)} accent />
                <Donnee terme="Date souhaitee" valeur={formatDate(dateSouhaitee)} />
                <Donnee terme="Contact" valeur={reference.contact(contactId)?.nom ?? '—'} />
              </dl>

              <ul className="divide-y divide-alfa-line rounded-alfa border border-alfa-line">
                {lignes.map((ligne) => {
                  const produit = reference.produit(ligne.produitId);
                  return (
                    <li key={ligne.id} className="flex flex-wrap items-center gap-3 p-2.5">
                      <span className="min-w-0 flex-1">
                        <span className="block font-medium text-alfa-ink">{produit?.nom}</span>
                        <span className="block text-xs text-alfa-muted">{produit?.codeItem}</span>
                      </span>
                      <TypeItemBadge type={ligne.typeItem} />
                      <span className="font-semibold tabular-nums text-alfa-ink">
                        {ligne.quantiteDemandee}
                      </span>
                    </li>
                  );
                })}
              </ul>

              <p className="text-sm text-alfa-slate">
                Total demande : <strong className="tabular-nums text-alfa-ink">{totalDemande}</strong>{' '}
                unites sur {lignes.length} ligne(s).
              </p>

              {notes && (
                <p className="rounded-alfa bg-alfa-surface px-3 py-2 text-sm text-alfa-slate">{notes}</p>
              )}

              <Message
                ton="info"
                titre="Aucune quantite n'est reservee a ce stade."
                details={['La reservation du stock intervient uniquement a l approbation interne.']}
              />
            </div>
          )}
        </div>

        {/* ------------------------------------------------------ Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-alfa-line px-4 py-3">
          <Bouton
            disabled={etape === 0}
            onClick={() => {
              setErreur(null);
              setEtape((e) => Math.max(0, e - 1));
            }}
            icone={<ArrowLeft aria-hidden="true" className="h-4 w-4" />}
          >
            Precedent
          </Bouton>

          <div className="flex flex-wrap gap-2">
            {etape === ETAPES.length - 1 ? (
              <>
                <Bouton onClick={() => enregistrer('BROUILLON')}>Enregistrer le brouillon</Bouton>
                <Bouton
                  variante="principal"
                  onClick={() => enregistrer('A_VERIFIER')}
                  icone={<Check aria-hidden="true" className="h-4 w-4" />}
                >
                  Soumettre la demande
                </Bouton>
              </>
            ) : (
              <Bouton
                variante="principal"
                onClick={() => {
                  if (valider()) setEtape((e) => e + 1);
                }}
                icone={<ArrowRight aria-hidden="true" className="h-4 w-4" />}
              >
                Etape suivante
              </Bouton>
            )}
          </div>
        </div>
      </Section>
    </Page>
  );
}
