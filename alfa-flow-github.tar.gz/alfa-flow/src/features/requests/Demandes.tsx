import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Check, Plus, Search, X } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel, useStocks } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  ChampTexte,
  CompteurQuantite,
  Donnee,
  EtatVide,
  Message,
  Modale,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutDemandeBadge, TypeItemBadge } from '../../components/ui/statuts';
import { approuverDemande, creerPreparation, refuserDemande, soumettreDemande } from '../../services/operations';
import { LIBELLE_STATUT_DEMANDE } from '../../models/referentiel';
import { contient, formatDate, somme } from '../../utils';
import type { StatutDemande } from '../../models/types';

const STATUTS: StatutDemande[] = [
  'BROUILLON',
  'SOUMISE',
  'A_VERIFIER',
  'APPROUVEE',
  'REFUSEE',
  'ANNULEE',
];

/** ECRAN 4 — liste des demandes. */
export function Demandes() {
  const donnees = useBoutique((e) => e.donnees);
  const naviguer = useNavigate();
  const reference = useReferentiel();
  const peutCreer = useDroit('demande.creer');
  const [requete, setRequete] = useState('');
  const [statut, setStatut] = useState<'' | StatutDemande>('');

  const demandes = useMemo(
    () =>
      donnees.demandes
        .filter((demande) => {
          if (statut && demande.statut !== statut) return false;
          const client = reference.nomClient(demande.clientId);
          const chantier = reference.nomChantier(demande.chantierId);
          return contient(`${demande.numero} ${client} ${chantier}`, requete);
        })
        .sort((a, b) => b.dateCreation.localeCompare(a.dateCreation)),
    [donnees.demandes, requete, statut, reference],
  );

  return (
    <Page
      titre="Demandes"
      description="Une demande porte un client et un chantier. Aucune quantite n'est reservee avant la verification interne."
      actions={
        peutCreer && (
          <Bouton
            variante="principal"
            onClick={() => naviguer('/demandes/nouvelle')}
            icone={<Plus aria-hidden="true" className="h-4 w-4" />}
          >
            Nouvelle demande
          </Bouton>
        )
      }
    >
      <Section className="mb-4">
        <div className="flex flex-wrap items-end gap-3 p-3">
          <div className="min-w-[220px] flex-1">
            <label htmlFor="recherche-demandes" className="sr-only">
              Rechercher une demande
            </label>
            <div className="relative">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-alfa-muted"
              />
              <input
                id="recherche-demandes"
                type="search"
                value={requete}
                onChange={(e) => setRequete(e.target.value)}
                placeholder="Numero, client, chantier…"
                className="champ pl-9"
              />
            </div>
          </div>
          <div>
            <label htmlFor="filtre-statut-demande" className="etiquette-champ">
              Statut
            </label>
            <select
              id="filtre-statut-demande"
              value={statut}
              onChange={(e) => setStatut(e.target.value as StatutDemande | '')}
              className="champ mt-1.5 w-48"
            >
              <option value="">Tous les statuts</option>
              {STATUTS.map((valeur) => (
                <option key={valeur} value={valeur}>
                  {LIBELLE_STATUT_DEMANDE[valeur]}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Section>

      <Section>
        {demandes.length === 0 ? (
          <EtatVide titre="Aucune demande ne correspond" texte="Modifiez la recherche ou le statut." />
        ) : (
          <Tableau
            legende="Liste des demandes de materiel"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Client' },
              { libelle: 'Chantier', discret: true },
              { libelle: 'Date souhaitee' },
              { libelle: 'Lignes', alignement: 'droite', discret: true },
              { libelle: 'Quantites', alignement: 'droite' },
              { libelle: 'Statut' },
            ]}
          >
            {demandes.map((demande) => (
              <tr key={demande.id} className="hover:bg-alfa-surface">
                <Cellule>
                  <Link
                    to={`/demandes/${demande.id}`}
                    className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                  >
                    {demande.numero}
                  </Link>
                </Cellule>
                <Cellule>{reference.nomClient(demande.clientId)}</Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">{reference.nomChantier(demande.chantierId)}</span>
                </Cellule>
                <Cellule>
                  <span className="whitespace-nowrap text-alfa-slate">
                    {formatDate(demande.dateSouhaitee)}
                  </span>
                </Cellule>
                <Cellule alignement="droite" discret>
                  {demande.lignes.length}
                </Cellule>
                <Cellule alignement="droite">
                  {somme(demande.lignes, (l) => l.quantiteApprouvee ?? l.quantiteDemandee)}
                </Cellule>
                <Cellule>
                  <StatutDemandeBadge statut={demande.statut} />
                </Cellule>
              </tr>
            ))}
          </Tableau>
        )}
      </Section>
    </Page>
  );
}

/** Fiche de demande : verification ligne a ligne puis approbation. */
export function FicheDemande() {
  const { demandeId } = useParams<{ demandeId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const stocks = useStocks();
  const naviguer = useNavigate();

  const peutApprouver = useDroit('demande.approuver');
  const peutPreparer = useDroit('preparation.executer');

  const demande = donnees.demandes.find((d) => d.id === demandeId);
  const [quantites, setQuantites] = useState<Record<string, number>>({});
  const [refusOuvert, setRefusOuvert] = useState(false);
  const [motifRefus, setMotifRefus] = useState('');

  if (!demande) {
    return (
      <Page titre="Demande introuvable">
        <Section>
          <EtatVide
            titre="Cette demande n'existe pas"
            action={
              <Link to="/demandes" className="text-alfa-redDark underline">
                Retour aux demandes
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const contexte = { utilisateurId: utilisateur.id, appareil: 'Poste web' };
  const preparation = donnees.preparations.find((p) => p.demandeId === demande.id);
  const modifiable = demande.statut === 'A_VERIFIER' || demande.statut === 'SOUMISE';

  const quantiteApprouvee = (ligneId: string, defaut: number) => quantites[ligneId] ?? defaut;

  const approuver = () => {
    const valeurs = Object.fromEntries(
      demande.lignes.map((ligne) => [
        ligne.id,
        quantiteApprouvee(ligne.id, ligne.quantiteApprouvee ?? ligne.quantiteDemandee),
      ]),
    );
    appliquer(
      approuverDemande(donnees, demande.id, valeurs, contexte),
      `Demande ${demande.numero} approuvee. Les quantites sont reservees.`,
    );
  };

  return (
    <Page
      titre={demande.numero}
      fil={[{ libelle: 'Demandes', lien: '/demandes' }, { libelle: demande.numero }]}
      actions={
        <>
          {demande.statut === 'BROUILLON' && (
            <Bouton
              onClick={() =>
                appliquer(
                  soumettreDemande(donnees, demande.id, contexte),
                  'Demande soumise pour verification.',
                )
              }
            >
              Soumettre pour verification
            </Bouton>
          )}
          {modifiable && peutApprouver && (
            <>
              <Bouton
                variante="danger"
                onClick={() => setRefusOuvert(true)}
                icone={<X aria-hidden="true" className="h-4 w-4" />}
              >
                Refuser
              </Bouton>
              <Bouton
                variante="principal"
                onClick={approuver}
                icone={<Check aria-hidden="true" className="h-4 w-4" />}
              >
                Approuver et reserver
              </Bouton>
            </>
          )}
          {demande.statut === 'APPROUVEE' && !preparation && peutPreparer && (
            <Bouton
              variante="principal"
              onClick={() => {
                const resultat = creerPreparation(donnees, demande.id, utilisateur.id, contexte);
                if (appliquer(resultat, 'Preparation creee.')) naviguer('/preparations');
              }}
            >
              Creer la preparation
            </Bouton>
          )}
          {preparation && (
            <Bouton onClick={() => naviguer(`/preparations/${preparation.id}`)}>
              Ouvrir la preparation {preparation.numero}
            </Bouton>
          )}
        </>
      }
    >
      <div className="grid gap-4 lg:grid-cols-4">
        <Section titre="Dossier" className="lg:col-span-1">
          <dl className="space-y-4 p-4">
            <Donnee terme="Statut" valeur={<StatutDemandeBadge statut={demande.statut} />} />
            <Donnee
              terme="Client"
              valeur={
                <Link to={`/clients/${demande.clientId}`} className="text-alfa-ink hover:underline">
                  {reference.nomClient(demande.clientId)}
                </Link>
              }
            />
            <Donnee terme="Chantier" valeur={reference.nomChantier(demande.chantierId)} />
            <Donnee terme="Contact" valeur={reference.contact(demande.contactId)?.nom ?? '—'} />
            <Donnee terme="Date souhaitee" valeur={formatDate(demande.dateSouhaitee)} accent />
            <Donnee terme="Creee par" valeur={reference.nomUtilisateur(demande.creeParId)} />
          </dl>
          {demande.notes && (
            <p className="border-t border-alfa-line px-4 py-3 text-sm text-alfa-slate">
              {demande.notes}
            </p>
          )}
        </Section>

        <Section titre="Lignes demandees" className="lg:col-span-3">
          {modifiable && peutApprouver && (
            <div className="border-b border-alfa-line p-3">
              <Message
                ton="info"
                titre="Verification avant engagement du stock"
                details={[
                  'Ajustez la quantite approuvee si le disponible ne couvre pas la demande.',
                  'La reservation n est creee qu au moment de l approbation.',
                ]}
              />
            </div>
          )}

          <ul className="divide-y divide-alfa-line">
            {demande.lignes.map((ligne) => {
              const produit = reference.produit(ligne.produitId);
              const stock = stocks.get(ligne.produitId);
              const disponible = stock?.disponible ?? 0;
              const valeur = quantiteApprouvee(
                ligne.id,
                ligne.quantiteApprouvee ?? ligne.quantiteDemandee,
              );
              const insuffisant = valeur > disponible;

              return (
                <li key={ligne.id} className="p-3 sm:p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <Link
                        to={`/catalogue/${ligne.produitId}`}
                        className="font-medium text-alfa-ink hover:underline"
                      >
                        {produit?.nom ?? ligne.produitId}
                      </Link>
                      <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-alfa-muted">
                        <span>{produit?.codeItem}</span>
                        <TypeItemBadge type={ligne.typeItem} />
                        <span>{produit?.emplacement}</span>
                      </p>
                    </div>
                    <div className="flex gap-5 text-right text-sm">
                      <Donnee terme="Demandee" valeur={ligne.quantiteDemandee} />
                      <Donnee
                        terme="Disponible"
                        valeur={
                          <span className={insuffisant ? 'font-semibold text-alfa-redDark' : ''}>
                            {disponible}
                          </span>
                        }
                      />
                      {!modifiable && (
                        <Donnee terme="Approuvee" valeur={ligne.quantiteApprouvee ?? '—'} accent />
                      )}
                    </div>
                  </div>

                  {modifiable && peutApprouver && (
                    <div className="mt-3 border-t border-alfa-line pt-3">
                      <p className="mb-1.5 text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                        Quantite a approuver
                      </p>
                      <CompteurQuantite
                        etiquette={`Quantite approuvee pour ${produit?.nom ?? ''}`}
                        valeur={valeur}
                        max={Math.max(disponible, 0)}
                        onChange={(nouvelle) =>
                          setQuantites((courant) => ({ ...courant, [ligne.id]: nouvelle }))
                        }
                      />
                      {insuffisant && (
                        <p className="mt-2 text-sm text-alfa-redDark">
                          {valeur} unites demandees pour {disponible} disponibles. Reduisez la
                          quantite : le reliquat restera visible au dossier.
                        </p>
                      )}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>

          <div className="flex flex-wrap justify-end gap-6 border-t border-alfa-line px-4 py-3 text-sm">
            <p className="text-alfa-slate">
              Total demande :{' '}
              <strong className="tabular-nums text-alfa-ink">
                {somme(demande.lignes, (l) => l.quantiteDemandee)}
              </strong>{' '}
              unites
            </p>
            {demande.statut === 'APPROUVEE' && (
              <p className="text-alfa-slate">
                Total approuve :{' '}
                <strong className="tabular-nums text-alfa-ink">
                  {somme(demande.lignes, (l) => l.quantiteApprouvee ?? 0)}
                </strong>{' '}
                unites
              </p>
            )}
          </div>
        </Section>
      </div>

      <Modale
        ouverte={refusOuvert}
        titre="Refuser la demande"
        description={`Demande ${demande.numero}`}
        onFermer={() => setRefusOuvert(false)}
        actions={
          <>
            <Bouton onClick={() => setRefusOuvert(false)}>Annuler</Bouton>
            <Bouton
              variante="principal"
              onClick={() => {
                const resultat = refuserDemande(donnees, demande.id, motifRefus, contexte);
                if (appliquer(resultat, 'Demande refusee.')) {
                  setRefusOuvert(false);
                  setMotifRefus('');
                }
              }}
            >
              Confirmer le refus
            </Bouton>
          </>
        }
      >
        <ChampTexte
          etiquette="Motif du refus"
          value={motifRefus}
          onChange={(e) => setMotifRefus(e.target.value)}
          aide="Obligatoire. Le motif est inscrit au journal avec votre nom et l horodatage."
        />
      </Modale>

      {demande.statut === 'REFUSEE' && (
        <div className="mt-4">
          <Statut ton="critique">Demande refusee</Statut>
        </div>
      )}
    </Page>
  );
}
