import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Download, SlidersHorizontal } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel, useStockProduit } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  Champ,
  ChampTexte,
  Donnee,
  EtatVide,
  Message,
  Modale,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { VignetteProduit } from './Catalogue';
import { ajusterStock } from '../../services/operations';
import { quantiteSignee } from '../../services/stock';
import { LIBELLE_MOUVEMENT } from '../../models/referentiel';
import { telechargerCsv } from '../../services/csv';
import { formatDateHeure } from '../../utils';

/** Fiche article : les sept quantites sont calculees, jamais saisies (DATA-002). */
export function FicheProduit() {
  const { produitId } = useParams<{ produitId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutAjuster = useDroit('stock.ajuster');

  const produit = donnees.produits.find((p) => p.id === produitId);
  const stock = useStockProduit(produitId ?? '');
  const [ajustementOuvert, setAjustementOuvert] = useState(false);

  const mouvements = useMemo(
    () =>
      donnees.mouvements
        .filter((m) => m.produitId === produitId)
        .sort((a, b) => b.dateHeure.localeCompare(a.dateHeure)),
    [donnees.mouvements, produitId],
  );

  if (!produit || !stock) {
    return (
      <Page titre="Article introuvable">
        <Section>
          <EtatVide
            titre="Cet article n'existe pas"
            texte="Il a peut-etre ete archive."
            action={<Link to="/catalogue" className="text-alfa-redDark underline">Retour au catalogue</Link>}
          />
        </Section>
      </Page>
    );
  }

  const compartiments = [
    { libelle: 'Stock physique', valeur: stock.physique, aide: 'Present dans les emplacements internes' },
    { libelle: 'Disponible', valeur: stock.disponible, accent: true, aide: 'Physique moins reserve, en preparation et endommage' },
    { libelle: 'Reserve', valeur: stock.reserve, aide: 'Engage sur une demande approuvee' },
    { libelle: 'En preparation', valeur: stock.enPreparation, aide: 'Sorti de la reserve, pas encore charge' },
    { libelle: 'Chez les clients', valeur: stock.enCirculation, aide: 'Sorti et non encore rapproche' },
    { libelle: 'Endommage ou bloque', valeur: stock.endommage, aide: 'En quarantaine ou en reparation' },
    { libelle: 'Theorique total', valeur: stock.theorique, aide: 'Physique plus circulation' },
  ];

  const exporterMouvements = () => {
    telechargerCsv(
      `mouvements-${produit.codeItem}`,
      ['Date', 'Type', 'Quantite', 'Effet stock physique', 'Source', 'Destination', 'Document', 'Utilisateur', 'Motif'],
      mouvements.map((m) => [
        m.dateHeure,
        LIBELLE_MOUVEMENT[m.type],
        m.quantite,
        quantiteSignee(m),
        m.emplacementSource ?? '',
        m.emplacementDestination ?? '',
        m.documentRef ?? '',
        reference.nomUtilisateur(m.utilisateurId),
        m.motif ?? '',
      ]),
    );
  };

  return (
    <Page
      titre={produit.nom}
      fil={[
        { libelle: 'Catalogue', lien: '/catalogue' },
        { libelle: produit.nom },
      ]}
      actions={
        <>
          <Bouton onClick={exporterMouvements} icone={<Download aria-hidden="true" className="h-4 w-4" />}>
            Exporter les mouvements
          </Bouton>
          {peutAjuster && (
            <Bouton
              variante="principal"
              onClick={() => setAjustementOuvert(true)}
              icone={<SlidersHorizontal aria-hidden="true" className="h-4 w-4" />}
            >
              Ajuster le stock
            </Bouton>
          )}
        </>
      }
    >
      <div className="grid gap-4 lg:grid-cols-3">
        <Section titre="Identification">
          <div className="border-b border-alfa-line">
            <VignetteProduit produit={produit} grande />
          </div>
          <dl className="grid grid-cols-2 gap-4 p-4">
            <Donnee terme="Code article" valeur={produit.codeItem} accent />
            <Donnee terme="SKU interne" valeur={produit.sku} />
            <Donnee terme="Famille" valeur={produit.famille} />
            <Donnee terme="Sous-famille" valeur={produit.sousFamille} />
            <Donnee terme="Dimensions" valeur={produit.dimensions || '—'} />
            <Donnee terme="Couleur" valeur={produit.couleur || '—'} />
            <Donnee terme="Unite" valeur={produit.unite} />
            <Donnee terme="Emplacement" valeur={produit.emplacement} />
            <Donnee terme="Seuil d'alerte" valeur={`${produit.seuilAlerte} unites`} />
          </dl>
        </Section>

        <Section titre="Etat du stock" className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-px bg-alfa-line sm:grid-cols-4">
            {compartiments.map((compartiment) => (
              <div key={compartiment.libelle} className="bg-white p-3">
                <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                  {compartiment.libelle}
                </p>
                <p
                  className={
                    compartiment.accent
                      ? 'mt-1 text-2xl font-semibold tabular-nums text-alfa-ink'
                      : 'mt-1 text-xl tabular-nums text-alfa-slate'
                  }
                >
                  {compartiment.valeur}
                </p>
                <p className="mt-1 text-xs leading-snug text-alfa-muted">{compartiment.aide}</p>
              </div>
            ))}
            <div className="bg-white p-3">
              <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                Niveau
              </p>
              <p className="mt-1.5">
                {stock.disponible < produit.seuilAlerte ? (
                  <Statut ton="critique">Sous le seuil</Statut>
                ) : (
                  <Statut ton="succes">Au-dessus du seuil</Statut>
                )}
              </p>
            </div>
          </div>

          <p className="border-t border-alfa-line px-4 py-2.5 text-xs text-alfa-slate">
            Ces quantites ne sont pas modifiables directement : elles resultent des{' '}
            {mouvements.length} mouvements ci-dessous. Toute correction passe par une ecriture
            d'ajustement motivee.
          </p>
        </Section>
      </div>

      <Section titre="Historique des mouvements" className="mt-4">
        {mouvements.length === 0 ? (
          <EtatVide titre="Aucun mouvement" texte="Cet article n'a pas encore bouge." />
        ) : (
          <Tableau
            legende="Registre des mouvements de cet article"
            entetes={[
              { libelle: 'Date et heure' },
              { libelle: 'Type' },
              { libelle: 'Quantite', alignement: 'droite' },
              { libelle: 'Effet physique', alignement: 'droite' },
              { libelle: 'Source', discret: true },
              { libelle: 'Destination', discret: true },
              { libelle: 'Document' },
              { libelle: 'Utilisateur', discret: true },
            ]}
          >
            {mouvements.slice(0, 80).map((mouvement) => {
              const signe = quantiteSignee(mouvement);
              return (
                <tr key={mouvement.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <span className="whitespace-nowrap text-alfa-slate">
                      {formatDateHeure(mouvement.dateHeure)}
                    </span>
                  </Cellule>
                  <Cellule>{LIBELLE_MOUVEMENT[mouvement.type]}</Cellule>
                  <Cellule alignement="droite">{mouvement.quantite}</Cellule>
                  <Cellule alignement="droite">
                    <span
                      className={
                        signe < 0
                          ? 'font-semibold text-alfa-redDark'
                          : signe > 0
                            ? 'font-semibold text-etat-succes'
                            : 'text-alfa-muted'
                      }
                    >
                      {signe > 0 ? '+' : ''}
                      {signe !== 0 ? signe : '—'}
                    </span>
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">{mouvement.emplacementSource ?? '—'}</span>
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">{mouvement.emplacementDestination ?? '—'}</span>
                  </Cellule>
                  <Cellule>
                    <span className="text-alfa-slate">{mouvement.documentRef ?? '—'}</span>
                    {mouvement.motif && (
                      <span className="block text-xs text-alfa-muted">{mouvement.motif}</span>
                    )}
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">
                      {reference.nomUtilisateur(mouvement.utilisateurId)}
                    </span>
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        )}
      </Section>

      <ModaleAjustement
        ouverte={ajustementOuvert}
        onFermer={() => setAjustementOuvert(false)}
        valeurActuelle={stock.physique}
        nomProduit={produit.nom}
        onValider={(nouvelle, motif) => {
          const resultat = ajusterStock(donnees, produit.id, nouvelle, motif, {
            utilisateurId: utilisateur.id,
            appareil: 'Poste web',
          });
          if (appliquer(resultat, `Stock ajuste : ${stock.physique} → ${nouvelle} unites.`)) {
            setAjustementOuvert(false);
          }
        }}
      />
    </Page>
  );
}

/** SEC-005 : motif, valeur avant, valeur apres, auteur, horodatage et confirmation. */
function ModaleAjustement({
  ouverte,
  onFermer,
  valeurActuelle,
  nomProduit,
  onValider,
}: {
  ouverte: boolean;
  onFermer: () => void;
  valeurActuelle: number;
  nomProduit: string;
  onValider: (nouvelle: number, motif: string) => void;
}) {
  const [valeur, setValeur] = useState(String(valeurActuelle));
  const [motif, setMotif] = useState('');
  const [erreur, setErreur] = useState<string | null>(null);

  const MOTIFS = [
    'Inventaire tournant',
    'Erreur de saisie constatee',
    'Materiel retrouve en cour',
    'Materiel mis au rebut',
    'Correction apres comptage physique',
  ];

  const valider = () => {
    const nouvelle = Number(valeur);
    if (!Number.isInteger(nouvelle) || nouvelle < 0) {
      setErreur('La quantite apres ajustement doit etre un entier positif ou nul.');
      return;
    }
    if (!motif.trim()) {
      setErreur('Le motif est obligatoire : il est inscrit au journal avec votre nom.');
      return;
    }
    setErreur(null);
    onValider(nouvelle, motif.trim());
  };

  return (
    <Modale
      ouverte={ouverte}
      titre="Ajustement manuel du stock"
      description={nomProduit}
      onFermer={onFermer}
      actions={
        <>
          <Bouton onClick={onFermer}>Annuler</Bouton>
          <Bouton variante="principal" onClick={valider}>
            Confirmer l'ajustement
          </Bouton>
        </>
      }
    >
      <div className="space-y-4">
        <Message
          ton="attention"
          titre="Cette operation cree une ecriture au registre."
          details={[
            'Le mouvement d origine n est jamais modifie : une ecriture compensatoire est ajoutee.',
            'Valeur avant, valeur apres, auteur, date et motif sont conserves au journal.',
          ]}
        />

        <div className="grid grid-cols-2 gap-3">
          <Donnee terme="Stock physique actuel" valeur={`${valeurActuelle} unites`} accent />
          <Champ
            etiquette="Stock physique apres ajustement"
            type="number"
            min={0}
            inputMode="numeric"
            value={valeur}
            onChange={(e) => setValeur(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="motif-predefini" className="etiquette-champ">
            Motif
          </label>
          <select
            id="motif-predefini"
            value={MOTIFS.includes(motif) ? motif : ''}
            onChange={(e) => setMotif(e.target.value)}
            className="champ mt-1.5"
          >
            <option value="">Choisir un motif…</option>
            {MOTIFS.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>

        <ChampTexte
          etiquette="Precision (facultative mais recommandee)"
          value={MOTIFS.includes(motif) ? '' : motif}
          onChange={(e) => setMotif(e.target.value)}
          aide="Exemple : comptage du 12 mai, 4 barres retrouvees derriere la rangee 2."
        />

        {erreur && <Message ton="erreur" titre={erreur} />}
      </div>
    </Modale>
  );
}
