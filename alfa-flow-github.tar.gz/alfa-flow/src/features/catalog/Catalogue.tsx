import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, Grid2x2, ImageOff, List, Search, SlidersHorizontal } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useStocks } from '../../state/selecteurs';
import { Bouton, Cellule, EtatVide, Page, Section, Statut, Tableau } from '../../components/ui/primitives';
import { telechargerCsv } from '../../services/csv';
import { contient, formatNombre } from '../../utils';
import type { EtatStock, Produit } from '../../models/types';

type Affichage = 'tableau' | 'galerie';
type Tri = 'nom' | 'disponible' | 'famille' | 'code';

/**
 * ECRAN 2 — catalogue et stock.
 * Recherche par nom, reference, categorie ou dimension (BF-011),
 * affichage dense ou galerie photo au choix de l'utilisateur (BF-010).
 */
export function Catalogue() {
  const donnees = useBoutique((e) => e.donnees);
  const stocks = useStocks();

  const [requete, setRequete] = useState('');
  const [famille, setFamille] = useState('');
  const [couleur, setCouleur] = useState('');
  const [emplacement, setEmplacement] = useState('');
  const [disponibilite, setDisponibilite] = useState('');
  const [affichage, setAffichage] = useState<Affichage>('tableau');
  const [tri, setTri] = useState<Tri>('nom');
  const [filtresOuverts, setFiltresOuverts] = useState(false);

  const familles = useMemo(
    () => [...new Set(donnees.produits.map((p) => p.famille))].sort(),
    [donnees.produits],
  );
  const couleurs = useMemo(
    () => [...new Set(donnees.produits.map((p) => p.couleur).filter(Boolean))].sort(),
    [donnees.produits],
  );
  const emplacements = useMemo(
    () => [...new Set(donnees.produits.map((p) => p.emplacement))].sort(),
    [donnees.produits],
  );

  const resultats = useMemo(() => {
    const filtres = donnees.produits.filter((produit) => {
      const stock = stocks.get(produit.id);
      if (famille && produit.famille !== famille) return false;
      if (couleur && produit.couleur !== couleur) return false;
      if (emplacement && produit.emplacement !== emplacement) return false;
      if (disponibilite === 'disponible' && (stock?.disponible ?? 0) <= 0) return false;
      if (disponibilite === 'seuil' && (stock?.disponible ?? 0) >= produit.seuilAlerte) return false;
      if (disponibilite === 'circulation' && (stock?.enCirculation ?? 0) <= 0) return false;
      return contient(
        `${produit.nom} ${produit.sku} ${produit.codeItem} ${produit.famille} ${produit.sousFamille} ${produit.dimensions} ${produit.couleur}`,
        requete,
      );
    });

    return filtres.sort((a, b) => {
      if (tri === 'disponible') {
        return (stocks.get(b.id)?.disponible ?? 0) - (stocks.get(a.id)?.disponible ?? 0);
      }
      if (tri === 'famille') return a.famille.localeCompare(b.famille) || a.nom.localeCompare(b.nom);
      if (tri === 'code') return a.codeItem.localeCompare(b.codeItem);
      return a.nom.localeCompare(b.nom);
    });
  }, [donnees.produits, stocks, requete, famille, couleur, emplacement, disponibilite, tri]);

  const exporter = () => {
    telechargerCsv(
      'catalogue-alfa-flow',
      [
        'Code article',
        'SKU',
        'Nom',
        'Famille',
        'Sous-famille',
        'Dimensions',
        'Couleur',
        'Emplacement',
        'Total physique',
        'Disponible',
        'Reserve',
        'En preparation',
        'Chez les clients',
        'Endommage',
        'Seuil',
      ],
      resultats.map((produit) => {
        const stock = stocks.get(produit.id);
        return [
          produit.codeItem,
          produit.sku,
          produit.nom,
          produit.famille,
          produit.sousFamille,
          produit.dimensions,
          produit.couleur,
          produit.emplacement,
          stock?.physique ?? 0,
          stock?.disponible ?? 0,
          stock?.reserve ?? 0,
          stock?.enPreparation ?? 0,
          stock?.enCirculation ?? 0,
          stock?.endommage ?? 0,
          produit.seuilAlerte,
        ];
      }),
    );
  };

  const reinitialiser = () => {
    setRequete('');
    setFamille('');
    setCouleur('');
    setEmplacement('');
    setDisponibilite('');
  };

  const filtresActifs = [famille, couleur, emplacement, disponibilite].filter(Boolean).length;

  return (
    <Page
      titre="Catalogue"
      description={`${formatNombre(donnees.produits.length)} articles issus de la liste produits de Groupe Alfa. Extraction a valider : il ne s'agit pas de l'inventaire definitif.`}
      actions={
        <>
          <div className="flex rounded-alfa border border-alfa-line" role="group" aria-label="Type d'affichage">
            <button
              type="button"
              onClick={() => setAffichage('tableau')}
              aria-pressed={affichage === 'tableau'}
              className={`flex min-h-[44px] items-center gap-1.5 rounded-l-alfa px-3 text-sm ${
                affichage === 'tableau' ? 'bg-alfa-surface font-medium text-alfa-ink' : 'text-alfa-slate'
              }`}
            >
              <List aria-hidden="true" className="h-4 w-4" />
              Liste
            </button>
            <button
              type="button"
              onClick={() => setAffichage('galerie')}
              aria-pressed={affichage === 'galerie'}
              className={`flex min-h-[44px] items-center gap-1.5 rounded-r-alfa border-l border-alfa-line px-3 text-sm ${
                affichage === 'galerie' ? 'bg-alfa-surface font-medium text-alfa-ink' : 'text-alfa-slate'
              }`}
            >
              <Grid2x2 aria-hidden="true" className="h-4 w-4" />
              Galerie
            </button>
          </div>
          <Bouton onClick={exporter} icone={<Download aria-hidden="true" className="h-4 w-4" />}>
            Exporter CSV
          </Bouton>
        </>
      }
    >
      {/* ------------------------------------------------------------ Filtres */}
      <Section className="mb-4">
        <div className="flex flex-wrap items-end gap-3 p-3">
          <div className="min-w-[220px] flex-1">
            <label htmlFor="recherche-catalogue" className="etiquette-champ">
              Rechercher
            </label>
            <div className="relative mt-1.5">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-alfa-muted"
              />
              <input
                id="recherche-catalogue"
                type="search"
                value={requete}
                onChange={(e) => setRequete(e.target.value)}
                placeholder="Nom, code article, dimension, couleur…"
                className="champ pl-9"
              />
            </div>
          </div>

          <Bouton
            onClick={() => setFiltresOuverts((v) => !v)}
            aria-expanded={filtresOuverts}
            icone={<SlidersHorizontal aria-hidden="true" className="h-4 w-4" />}
          >
            Filtres{filtresActifs > 0 ? ` (${filtresActifs})` : ''}
          </Bouton>

          <div>
            <label htmlFor="tri-catalogue" className="etiquette-champ">
              Trier par
            </label>
            <select
              id="tri-catalogue"
              value={tri}
              onChange={(e) => setTri(e.target.value as Tri)}
              className="champ mt-1.5 w-44"
            >
              <option value="nom">Nom</option>
              <option value="code">Code article</option>
              <option value="famille">Famille</option>
              <option value="disponible">Disponible</option>
            </select>
          </div>
        </div>

        {filtresOuverts && (
          <div className="grid gap-3 border-t border-alfa-line p-3 sm:grid-cols-2 lg:grid-cols-4">
            <FiltreSelection
              etiquette="Famille"
              valeur={famille}
              onChange={setFamille}
              options={familles}
            />
            <FiltreSelection
              etiquette="Couleur"
              valeur={couleur}
              onChange={setCouleur}
              options={couleurs}
            />
            <FiltreSelection
              etiquette="Emplacement"
              valeur={emplacement}
              onChange={setEmplacement}
              options={emplacements}
            />
            <div>
              <label htmlFor="filtre-dispo" className="etiquette-champ">
                Disponibilite
              </label>
              <select
                id="filtre-dispo"
                value={disponibilite}
                onChange={(e) => setDisponibilite(e.target.value)}
                className="champ mt-1.5"
              >
                <option value="">Toutes</option>
                <option value="disponible">Disponible en cour</option>
                <option value="seuil">Sous le seuil d'alerte</option>
                <option value="circulation">Chez les clients</option>
              </select>
            </div>
            {filtresActifs > 0 && (
              <div className="sm:col-span-2 lg:col-span-4">
                <Bouton compact variante="discret" onClick={reinitialiser}>
                  Reinitialiser les filtres
                </Bouton>
              </div>
            )}
          </div>
        )}
      </Section>

      <p className="mb-2 text-sm text-alfa-slate" role="status">
        {formatNombre(resultats.length)} article{resultats.length > 1 ? 's' : ''} affiché
        {resultats.length > 1 ? 's' : ''}
      </p>

      {resultats.length === 0 ? (
        <Section>
          <EtatVide
            titre="Aucun article ne correspond"
            texte="Elargissez la recherche ou retirez un filtre. Aucun resultat approximatif n'est propose."
            action={<Bouton onClick={reinitialiser}>Reinitialiser les filtres</Bouton>}
          />
        </Section>
      ) : affichage === 'tableau' ? (
        <VueTableau produits={resultats} stocks={stocks} />
      ) : (
        <VueGalerie produits={resultats} stocks={stocks} />
      )}
    </Page>
  );
}

function FiltreSelection({
  etiquette,
  valeur,
  onChange,
  options,
}: {
  etiquette: string;
  valeur: string;
  onChange: (valeur: string) => void;
  options: string[];
}) {
  const identifiant = `filtre-${etiquette.toLowerCase()}`;
  return (
    <div>
      <label htmlFor={identifiant} className="etiquette-champ">
        {etiquette}
      </label>
      <select
        id={identifiant}
        value={valeur}
        onChange={(e) => onChange(e.target.value)}
        className="champ mt-1.5"
      >
        <option value="">Toutes</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}

/** Distinction visuelle nette entre les compartiments de stock. */
function VueTableau({ produits, stocks }: { produits: Produit[]; stocks: Map<string, EtatStock> }) {
  return (
    <Section>
      <Tableau
        legende="Catalogue des articles avec leur etat de stock"
        entetes={[
          { libelle: 'Article' },
          { libelle: 'Famille', discret: true },
          { libelle: 'Emplacement', discret: true },
          { libelle: 'Total', alignement: 'droite' },
          { libelle: 'Disponible', alignement: 'droite' },
          { libelle: 'Reserve', alignement: 'droite', discret: true },
          { libelle: 'En prep.', alignement: 'droite', discret: true },
          { libelle: 'Chez clients', alignement: 'droite' },
          { libelle: 'Endommage', alignement: 'droite', discret: true },
          { libelle: '' },
        ]}
      >
        {produits.slice(0, 120).map((produit) => {
          const stock = stocks.get(produit.id);
          const sousSeuil = (stock?.disponible ?? 0) < produit.seuilAlerte;
          return (
            <tr key={produit.id} className="hover:bg-alfa-surface">
              <Cellule>
                <Link
                  to={`/catalogue/${produit.id}`}
                  className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                >
                  {produit.nom}
                </Link>
                <span className="block text-xs text-alfa-muted">
                  {produit.codeItem}
                  {produit.dimensions ? ` · ${produit.dimensions}` : ''}
                  {produit.couleur ? ` · ${produit.couleur}` : ''}
                </span>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-slate">{produit.famille}</span>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-slate">{produit.emplacement}</span>
              </Cellule>
              <Cellule alignement="droite">{stock?.physique ?? 0}</Cellule>
              <Cellule alignement="droite">
                <span className={sousSeuil ? 'font-semibold text-alfa-redDark' : 'font-semibold text-alfa-ink'}>
                  {stock?.disponible ?? 0}
                </span>
                {sousSeuil && (
                  <span className="ml-1 text-xs text-alfa-redDark" title="Sous le seuil d'alerte">
                    ▲
                  </span>
                )}
              </Cellule>
              <Cellule alignement="droite" discret>
                {stock?.reserve ?? 0}
              </Cellule>
              <Cellule alignement="droite" discret>
                {stock?.enPreparation ?? 0}
              </Cellule>
              <Cellule alignement="droite">{stock?.enCirculation ?? 0}</Cellule>
              <Cellule alignement="droite" discret>
                {stock?.endommage ?? 0}
              </Cellule>
              <Cellule alignement="droite">
                <Link
                  to={`/catalogue/${produit.id}`}
                  className="text-sm font-medium text-alfa-redDark hover:underline"
                >
                  Consulter
                </Link>
              </Cellule>
            </tr>
          );
        })}
      </Tableau>
      {produits.length > 120 && (
        <p className="border-t border-alfa-line px-4 py-2.5 text-sm text-alfa-slate">
          120 premiers articles affiches sur {formatNombre(produits.length)}. Affinez la recherche
          pour reduire la liste.
        </p>
      )}
    </Section>
  );
}

function VueGalerie({ produits, stocks }: { produits: Produit[]; stocks: Map<string, EtatStock> }) {
  return (
    <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {produits.slice(0, 60).map((produit) => {
        const stock = stocks.get(produit.id);
        const sousSeuil = (stock?.disponible ?? 0) < produit.seuilAlerte;
        return (
          <li key={produit.id}>
            <Link
              to={`/catalogue/${produit.id}`}
              className="flex h-full flex-col overflow-hidden rounded-alfa border border-alfa-line transition-colors hover:border-alfa-slate"
            >
              <VignetteProduit produit={produit} />
              <div className="flex flex-1 flex-col gap-1.5 p-2.5">
                <span className="line-clamp-2 text-sm font-medium text-alfa-ink">{produit.nom}</span>
                <span className="text-xs text-alfa-muted">{produit.codeItem}</span>
                <span className="mt-auto pt-1">
                  <Statut ton={sousSeuil ? 'critique' : (stock?.disponible ?? 0) > 0 ? 'succes' : 'neutre'}>
                    {stock?.disponible ?? 0} disponible(s)
                  </Statut>
                </span>
              </div>
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

/**
 * DATA-007 : une photo manquante n'est jamais remplacee par une fausse image.
 * L'article est marque « photo a valider » ou « photo a completer ».
 */
export function VignetteProduit({ produit, grande }: { produit: Produit; grande?: boolean }) {
  const hauteur = grande ? 'h-56' : 'h-28';
  if (!produit.image) {
    return (
      <div
        className={`${hauteur} flex flex-col items-center justify-center gap-1 border-b border-alfa-line bg-alfa-surface text-alfa-muted`}
      >
        <ImageOff aria-hidden="true" className="h-5 w-5" />
        <span className="text-xs">Photo a completer</span>
      </div>
    );
  }
  return (
    <div className={`${hauteur} relative border-b border-alfa-line bg-alfa-surface`}>
      <img
        src={produit.image}
        alt={produit.nom}
        loading="lazy"
        className="h-full w-full object-contain"
      />
      {produit.photoAValider && (
        <span className="absolute left-1.5 top-1.5 rounded-alfa bg-white/90 px-1.5 py-0.5 text-[10px] font-medium text-alfa-slate">
          Photo a valider
        </span>
      )}
    </div>
  );
}
