import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { BellOff, Check, Download } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useAlertes, useDroit, useIndicateurs, useReferentiel, useStocks } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  ChampSelection,
  ChampTexte,
  Donnee,
  EtatVide,
  Message,
  Modale,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { DecisionEcartBadge } from '../../components/ui/statuts';
import { deciderEcart } from '../../services/operations';
import { quantiteSignee } from '../../services/stock';
import {
  LIBELLE_DECISION_ECART,
  LIBELLE_MOUVEMENT,
  LIBELLE_TYPE_ECART,
} from '../../models/referentiel';
import { telechargerCsv } from '../../services/csv';
import { formatDate, formatDateHeure, formatNombre } from '../../utils';
import type { DecisionEcart } from '../../models/types';

/* ==================================================== ECRAN 10 — Ecarts */

export function Ecarts() {
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutDecider = useDroit('ecart.decider');

  const [ecartId, setEcartId] = useState<string | null>(null);
  const [decision, setDecision] = useState<DecisionEcart>('A_FACTURER');
  const [motif, setMotif] = useState('');
  const [filtre, setFiltre] = useState<'ouverts' | 'tous'>('ouverts');

  const ecarts = useMemo(
    () =>
      donnees.ecarts
        .filter((e) =>
          filtre === 'ouverts' ? e.decision !== 'RESOLU' && e.decision !== 'ABANDONNE' : true,
        )
        .sort((a, b) => b.dateCreation.localeCompare(a.dateCreation)),
    [donnees.ecarts, filtre],
  );

  const ecartCourant = donnees.ecarts.find((e) => e.id === ecartId);

  return (
    <Page
      titre="Gestion des ecarts"
      description="Le systeme calcule, l'humain decide. Toute decision exige un motif et cree une entree au journal."
      actions={
        <ChampSelection
          etiquette=""
          value={filtre}
          onChange={(e) => setFiltre(e.target.value as 'ouverts' | 'tous')}
          className="w-48"
        >
          <option value="ouverts">Ecarts ouverts</option>
          <option value="tous">Tous les ecarts</option>
        </ChampSelection>
      }
    >
      <Section>
        {ecarts.length === 0 ? (
          <EtatVide titre="Aucun ecart" texte="Tous les rapprochements sont soldes." />
        ) : (
          <Tableau
            legende="Ecarts detectes au rapprochement"
            entetes={[
              { libelle: 'Constat' },
              { libelle: 'Client' },
              { libelle: 'Chantier', discret: true },
              { libelle: 'Article' },
              { libelle: 'Quantite', alignement: 'droite' },
              { libelle: 'Type' },
              { libelle: 'Preuves', discret: true },
              { libelle: 'Decision' },
              { libelle: '' },
            ]}
          >
            {ecarts.map((ecart) => (
              <tr key={ecart.id} className="hover:bg-alfa-surface">
                <Cellule>
                  <span className="font-medium text-alfa-ink">{ecart.numero}</span>
                  <span className="block text-xs text-alfa-muted">{formatDate(ecart.dateCreation)}</span>
                </Cellule>
                <Cellule>
                  <Link to={`/clients/${ecart.clientId}`} className="text-alfa-ink hover:underline">
                    {reference.nomClient(ecart.clientId)}
                  </Link>
                </Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">{reference.nomChantier(ecart.chantierId)}</span>
                </Cellule>
                <Cellule>
                  <Link to={`/catalogue/${ecart.produitId}`} className="text-alfa-ink hover:underline">
                    {reference.nomProduit(ecart.produitId)}
                  </Link>
                </Cellule>
                <Cellule alignement="droite">
                  <strong>{ecart.quantite}</strong>
                </Cellule>
                <Cellule>
                  <Statut ton={ecart.type === 'ENDOMMAGE' ? 'critique' : 'attention'}>
                    {LIBELLE_TYPE_ECART[ecart.type]}
                  </Statut>
                </Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">{ecart.photos.length} photo(s)</span>
                </Cellule>
                <Cellule>
                  <DecisionEcartBadge decision={ecart.decision} />
                  {ecart.motif && <span className="block text-xs text-alfa-muted">{ecart.motif}</span>}
                </Cellule>
                <Cellule alignement="droite">
                  {peutDecider && ecart.decision !== 'RESOLU' && (
                    <Bouton
                      compact
                      onClick={() => {
                        setEcartId(ecart.id);
                        setDecision('A_FACTURER');
                        setMotif('');
                      }}
                    >
                      Decider
                    </Bouton>
                  )}
                </Cellule>
              </tr>
            ))}
          </Tableau>
        )}
      </Section>

      <Modale
        ouverte={Boolean(ecartCourant)}
        titre="Decision sur l'ecart"
        description={ecartCourant ? `${ecartCourant.numero} — ${ecartCourant.quantite} unites` : ''}
        onFermer={() => setEcartId(null)}
        actions={
          <>
            <Bouton onClick={() => setEcartId(null)}>Annuler</Bouton>
            <Bouton
              variante="principal"
              onClick={() => {
                if (!ecartCourant) return;
                const resultat = deciderEcart(donnees, ecartCourant.id, decision, motif, {
                  utilisateurId: utilisateur.id,
                  appareil: 'Poste web',
                });
                if (appliquer(resultat, `Decision enregistree pour ${ecartCourant.numero}.`)) {
                  setEcartId(null);
                }
              }}
            >
              Enregistrer la decision
            </Bouton>
          </>
        }
      >
        {ecartCourant && (
          <div className="space-y-4">
            <dl className="grid grid-cols-2 gap-3">
              <Donnee terme="Article" valeur={reference.nomProduit(ecartCourant.produitId)} />
              <Donnee terme="Type" valeur={LIBELLE_TYPE_ECART[ecartCourant.type]} />
              <Donnee terme="Client" valeur={reference.nomClient(ecartCourant.clientId)} />
              <Donnee terme="Quantite" valeur={ecartCourant.quantite} accent />
            </dl>

            <ChampSelection
              etiquette="Decision"
              value={decision}
              onChange={(e) => setDecision(e.target.value as DecisionEcart)}
            >
              {(Object.keys(LIBELLE_DECISION_ECART) as DecisionEcart[]).map((valeur) => (
                <option key={valeur} value={valeur}>
                  {LIBELLE_DECISION_ECART[valeur]}
                </option>
              ))}
            </ChampSelection>

            <ChampTexte
              etiquette="Motif"
              value={motif}
              onChange={(e) => setMotif(e.target.value)}
              aide="Obligatoire. La decision, le motif, l auteur et l horodatage sont conserves."
            />

            <Message
              ton="info"
              titre="Aucune comparaison automatique ne decide seule d'une consequence financiere."
            />
          </div>
        )}
      </Modale>
    </Page>
  );
}

/* =================================================== ECRAN 11 — Alertes */

export function Alertes() {
  const alertes = useAlertes();
  const marquer = useBoutique((e) => e.marquerAlerte);
  const [filtre, setFiltre] = useState<'actives' | 'toutes'>('actives');

  const visibles = alertes.filter((a) => (filtre === 'actives' ? !a.resolue : true));

  return (
    <Page
      titre="Alertes"
      description="Les alertes sont derivees de l'etat courant : un meme evenement ne genere jamais deux alertes."
      actions={
        <ChampSelection
          etiquette=""
          value={filtre}
          onChange={(e) => setFiltre(e.target.value as 'actives' | 'toutes')}
          className="w-48"
        >
          <option value="actives">Alertes actives</option>
          <option value="toutes">Toutes les alertes</option>
        </ChampSelection>
      }
    >
      <Section>
        {visibles.length === 0 ? (
          <EtatVide titre="Aucune alerte active" texte="Les dossiers en cours sont a jour." />
        ) : (
          <ul className="divide-y divide-alfa-line">
            {visibles.map((alerte) => (
              <li key={alerte.id} className="flex flex-wrap items-start gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Statut
                      ton={
                        alerte.severite === 'CRITIQUE'
                          ? 'critique'
                          : alerte.severite === 'ATTENTION'
                            ? 'attention'
                            : 'info'
                      }
                    >
                      {alerte.titre}
                    </Statut>
                    {alerte.acquittee && !alerte.resolue && <Statut ton="neutre">Acquittee</Statut>}
                    {alerte.resolue && <Statut ton="succes">Resolue</Statut>}
                  </div>
                  <p className="mt-1 text-sm text-alfa-slate">{alerte.message}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Link
                    to={alerte.lien}
                    className="inline-flex min-h-[36px] items-center rounded-alfa border border-alfa-line px-3 text-sm text-alfa-ink hover:bg-alfa-surface"
                  >
                    Ouvrir le dossier
                  </Link>
                  {!alerte.acquittee && !alerte.resolue && (
                    <Bouton
                      compact
                      onClick={() => marquer(alerte.id, 'acquittee', true)}
                      icone={<BellOff aria-hidden="true" className="h-4 w-4" />}
                    >
                      Acquitter
                    </Bouton>
                  )}
                  {!alerte.resolue && (
                    <Bouton
                      compact
                      onClick={() => marquer(alerte.id, 'resolue', true)}
                      icone={<Check aria-hidden="true" className="h-4 w-4" />}
                    >
                      Marquer resolue
                    </Bouton>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Section>
    </Page>
  );
}

/* ============================================ Stock — vue consolidee */

export function Stock() {
  const donnees = useBoutique((e) => e.donnees);
  const stocks = useStocks();
  const indicateurs = useIndicateurs();
  const reference = useReferentiel();

  const mouvements = useMemo(
    () => [...donnees.mouvements].sort((a, b) => b.dateHeure.localeCompare(a.dateHeure)).slice(0, 150),
    [donnees.mouvements],
  );

  const exporter = () => {
    telechargerCsv(
      'mouvements-de-stock',
      ['Date', 'Article', 'Code', 'Type', 'Quantite', 'Effet physique', 'Source', 'Destination', 'Document', 'Utilisateur', 'Appareil', 'Motif'],
      donnees.mouvements.map((m) => {
        const produit = reference.produit(m.produitId);
        return [
          m.dateHeure,
          produit?.nom ?? m.produitId,
          produit?.codeItem ?? '',
          LIBELLE_MOUVEMENT[m.type],
          m.quantite,
          quantiteSignee(m),
          m.emplacementSource ?? '',
          m.emplacementDestination ?? '',
          m.documentRef ?? '',
          reference.nomUtilisateur(m.utilisateurId),
          m.appareil ?? '',
          m.motif ?? '',
        ];
      }),
    );
  };

  return (
    <Page
      titre="Stock"
      description="Vue consolidee du parc et registre des mouvements."
      actions={
        <Bouton onClick={exporter} icone={<Download aria-hidden="true" className="h-4 w-4" />}>
          Exporter le registre
        </Bouton>
      }
    >
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { libelle: 'Disponible', valeur: indicateurs.agregat.disponible },
          { libelle: 'Reserve et en preparation', valeur: indicateurs.agregat.reserve + indicateurs.agregat.enPreparation },
          { libelle: 'Chez les clients', valeur: indicateurs.agregat.enCirculation },
          { libelle: 'Quarantaine', valeur: indicateurs.agregat.endommage },
        ].map((element) => (
          <div key={element.libelle} className="carte p-3">
            <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
              {element.libelle}
            </p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-alfa-ink">
              {formatNombre(element.valeur)}
            </p>
          </div>
        ))}
      </div>

      {indicateurs.sousSeuil.length > 0 && (
        <Section titre="Articles sous le seuil d'alerte" className="mb-4">
          <Tableau
            legende="Articles dont le disponible est inferieur au seuil"
            entetes={[
              { libelle: 'Article' },
              { libelle: 'Emplacement', discret: true },
              { libelle: 'Disponible', alignement: 'droite' },
              { libelle: 'Seuil', alignement: 'droite' },
              { libelle: 'Chez les clients', alignement: 'droite', discret: true },
            ]}
          >
            {indicateurs.sousSeuil.map((produit) => {
              const stock = stocks.get(produit.id);
              return (
                <tr key={produit.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link to={`/catalogue/${produit.id}`} className="text-alfa-ink hover:underline">
                      {produit.nom}
                    </Link>
                    <span className="block text-xs text-alfa-muted">{produit.codeItem}</span>
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">{produit.emplacement}</span>
                  </Cellule>
                  <Cellule alignement="droite">
                    <strong className="text-alfa-redDark">{stock?.disponible ?? 0}</strong>
                  </Cellule>
                  <Cellule alignement="droite">{produit.seuilAlerte}</Cellule>
                  <Cellule alignement="droite" discret>
                    {stock?.enCirculation ?? 0}
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        </Section>
      )}

      <Section titre={`Registre des mouvements (${formatNombre(donnees.mouvements.length)} ecritures)`}>
        <Tableau
          legende="Derniers mouvements de stock"
          entetes={[
            { libelle: 'Date' },
            { libelle: 'Article' },
            { libelle: 'Type' },
            { libelle: 'Quantite', alignement: 'droite' },
            { libelle: 'Effet', alignement: 'droite' },
            { libelle: 'Document', discret: true },
            { libelle: 'Utilisateur', discret: true },
          ]}
        >
          {mouvements.map((mouvement) => {
            const signe = quantiteSignee(mouvement);
            return (
              <tr key={mouvement.id} className="hover:bg-alfa-surface">
                <Cellule>
                  <span className="whitespace-nowrap text-alfa-slate">
                    {formatDateHeure(mouvement.dateHeure)}
                  </span>
                </Cellule>
                <Cellule>
                  <Link
                    to={`/catalogue/${mouvement.produitId}`}
                    className="text-alfa-ink hover:underline"
                  >
                    {reference.nomProduit(mouvement.produitId)}
                  </Link>
                </Cellule>
                <Cellule>{LIBELLE_MOUVEMENT[mouvement.type]}</Cellule>
                <Cellule alignement="droite">{mouvement.quantite}</Cellule>
                <Cellule alignement="droite">
                  <span
                    className={
                      signe < 0
                        ? 'font-semibold text-alfa-redDark'
                        : signe > 0
                          ? 'font-semibold text-etat-succes'
                          : 'text-alfa-muted'
                    }
                  >
                    {signe > 0 ? '+' : ''}
                    {signe !== 0 ? signe : '—'}
                  </span>
                </Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">{mouvement.documentRef ?? '—'}</span>
                </Cellule>
                <Cellule discret>
                  <span className="text-alfa-slate">
                    {reference.nomUtilisateur(mouvement.utilisateurId)}
                  </span>
                </Cellule>
              </tr>
            );
          })}
        </Tableau>
      </Section>
    </Page>
  );
}
