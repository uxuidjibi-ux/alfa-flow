import { useMemo, useState } from 'react';
import { Download, RotateCcw, ShieldCheck } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useIndicateurs, useReferentiel, useStocks } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  ChampSelection,
  Confirmation,
  Donnee,
  EtatVide,
  Message,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { telechargerCsv } from '../../services/csv';
import { quantiteRestante } from '../../services/operations';
import { quantiteSignee } from '../../services/stock';
import {
  LIBELLE_MOUVEMENT,
  LIBELLE_ROLE,
  ORGANISATION,
  PERMISSIONS_PAR_ROLE,
  SEUIL_STOCK_DORMANT_JOURS,
} from '../../models/referentiel';
import { aujourdHui, ecartJours, formatDate, formatDateHeure, formatNombre, somme } from '../../utils';
import type { Role } from '../../models/types';

type Rapport =
  | 'mouvements'
  | 'stock'
  | 'circulation'
  | 'retards'
  | 'ecarts'
  | 'client'
  | 'dormant';

const RAPPORTS: Array<{ valeur: Rapport; libelle: string }> = [
  { valeur: 'mouvements', libelle: 'Mouvements de stock' },
  { valeur: 'stock', libelle: 'Stock actuel' },
  { valeur: 'circulation', libelle: 'Materiel en circulation' },
  { valeur: 'retards', libelle: 'Retours en retard' },
  { valeur: 'ecarts', libelle: 'Ecarts' },
  { valeur: 'client', libelle: 'Historique par client' },
  { valeur: 'dormant', libelle: 'Articles sans mouvement' },
];

/** ECRAN 12 — rapports et journal d'activite. */
export function Rapports() {
  const donnees = useBoutique((e) => e.donnees);
  const stocks = useStocks();
  const reference = useReferentiel();
  const indicateurs = useIndicateurs();
  const peutLireJournal = useDroit('journal.lire');

  const [rapport, setRapport] = useState<Rapport>('mouvements');
  const [clientId, setClientId] = useState('');
  const [depuis, setDepuis] = useState('');
  const [jusqua, setJusqua] = useState('');

  const dansPeriode = (date: string) => {
    const jour = date.slice(0, 10);
    if (depuis && jour < depuis) return false;
    if (jusqua && jour > jusqua) return false;
    return true;
  };

  const contenu = useMemo(() => {
    if (rapport === 'mouvements') {
      const lignes = donnees.mouvements
        .filter((m) => dansPeriode(m.dateHeure))
        .filter((m) => !clientId || m.clientId === clientId)
        .sort((a, b) => b.dateHeure.localeCompare(a.dateHeure));
      return {
        entetes: ['Date', 'Article', 'Code', 'Type', 'Quantite', 'Effet physique', 'Document', 'Utilisateur'],
        lignes: lignes.map((m) => {
          const produit = reference.produit(m.produitId);
          return [
            formatDateHeure(m.dateHeure),
            produit?.nom ?? m.produitId,
            produit?.codeItem ?? '',
            LIBELLE_MOUVEMENT[m.type],
            m.quantite,
            quantiteSignee(m),
            m.documentRef ?? '',
            reference.nomUtilisateur(m.utilisateurId),
          ];
        }),
      };
    }

    if (rapport === 'stock') {
      return {
        entetes: ['Article', 'Code', 'Famille', 'Emplacement', 'Physique', 'Disponible', 'Reserve', 'Chez clients', 'Endommage', 'Seuil'],
        lignes: donnees.produits.map((produit) => {
          const stock = stocks.get(produit.id);
          return [
            produit.nom,
            produit.codeItem,
            produit.famille,
            produit.emplacement,
            stock?.physique ?? 0,
            stock?.disponible ?? 0,
            stock?.reserve ?? 0,
            stock?.enCirculation ?? 0,
            stock?.endommage ?? 0,
            produit.seuilAlerte,
          ];
        }),
      };
    }

    if (rapport === 'circulation') {
      const lignes: Array<Array<string | number>> = [];
      for (const location of donnees.locations) {
        if (location.statut === 'CLOTUREE') continue;
        if (clientId && location.clientId !== clientId) continue;
        for (const ligne of location.lignes) {
          const reste = quantiteRestante(ligne);
          if (reste <= 0) continue;
          lignes.push([
            location.numero,
            reference.nomClient(location.clientId),
            reference.nomChantier(location.chantierId),
            reference.nomProduit(ligne.produitId),
            ligne.quantiteSortie,
            ligne.quantiteRetournee,
            reste,
            formatDate(location.retourAttendu),
          ]);
        }
      }
      return {
        entetes: ['Location', 'Client', 'Chantier', 'Article', 'Sortie', 'Retournee', 'Reste', 'Retour attendu'],
        lignes,
      };
    }

    if (rapport === 'retards') {
      return {
        entetes: ['Location', 'Client', 'Chantier', 'Retour attendu', 'Jours de retard', 'Unites restantes'],
        lignes: indicateurs.retoursEnRetard
          .filter((l) => !clientId || l.clientId === clientId)
          .map((location) => [
            location.numero,
            reference.nomClient(location.clientId),
            reference.nomChantier(location.chantierId),
            formatDate(location.retourAttendu),
            Math.abs(ecartJours(location.retourAttendu, aujourdHui())),
            somme(location.lignes, quantiteRestante),
          ]),
      };
    }

    if (rapport === 'ecarts') {
      return {
        entetes: ['Constat', 'Date', 'Client', 'Article', 'Quantite', 'Type', 'Decision', 'Motif'],
        lignes: donnees.ecarts
          .filter((e) => dansPeriode(e.dateCreation))
          .filter((e) => !clientId || e.clientId === clientId)
          .map((ecart) => [
            ecart.numero,
            formatDate(ecart.dateCreation),
            reference.nomClient(ecart.clientId),
            reference.nomProduit(ecart.produitId),
            ecart.quantite,
            ecart.type,
            ecart.decision,
            ecart.motif,
          ]),
      };
    }

    if (rapport === 'client') {
      const lignes: Array<Array<string | number>> = [];
      for (const sortie of donnees.sorties) {
        if (clientId && sortie.clientId !== clientId) continue;
        if (!dansPeriode(sortie.dateSortie)) continue;
        lignes.push([
          sortie.numero,
          formatDate(sortie.dateSortie),
          reference.nomClient(sortie.clientId),
          reference.nomChantier(sortie.chantierId),
          somme(sortie.lignes, (l) => l.quantite),
          somme(sortie.lignes, (l) => l.quantiteAVenir),
          sortie.statut,
        ]);
      }
      return {
        entetes: ['Bon', 'Date', 'Client', 'Chantier', 'Expedie', 'A venir', 'Statut'],
        lignes,
      };
    }

    // Articles sans mouvement depuis le seuil dormant.
    const dernier = new Map<string, string>();
    for (const mouvement of donnees.mouvements) {
      const precedent = dernier.get(mouvement.produitId);
      if (!precedent || mouvement.dateHeure > precedent) {
        dernier.set(mouvement.produitId, mouvement.dateHeure);
      }
    }
    return {
      entetes: ['Article', 'Code', 'Dernier mouvement', 'Jours sans mouvement', 'Disponible'],
      lignes: donnees.produits
        .map((produit) => {
          const derniere = dernier.get(produit.id);
          const jours = derniere ? ecartJours(aujourdHui(), derniere.slice(0, 10)) : 9999;
          return { produit, derniere, jours };
        })
        .filter((element) => element.jours >= SEUIL_STOCK_DORMANT_JOURS)
        .map((element) => [
          element.produit.nom,
          element.produit.codeItem,
          element.derniere ? formatDate(element.derniere) : 'Aucun',
          element.jours,
          stocks.get(element.produit.id)?.disponible ?? 0,
        ]),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rapport, clientId, depuis, jusqua, donnees, stocks, reference, indicateurs]);

  const exporter = () => {
    const libelle = RAPPORTS.find((r) => r.valeur === rapport)?.libelle ?? 'rapport';
    // RF-050 : l'export porte l'auteur, la date et les filtres appliques.
    telechargerCsv(
      `rapport-${rapport}`,
      contenu.entetes,
      [
        ...contenu.lignes,
        [],
        [`Rapport : ${libelle}`],
        [`Genere le : ${formatDateHeure(new Date().toISOString())}`],
        [`Client : ${clientId ? reference.nomClient(clientId) : 'tous'}`],
        [`Periode : ${depuis || 'debut'} au ${jusqua || 'aujourd hui'}`],
        [`Lignes : ${contenu.lignes.length}`],
      ] as Array<Array<string | number>>,
    );
  };

  return (
    <Page
      titre="Rapports et journal"
      description="Chaque rapport est recalculable depuis le registre. Les exports portent l'auteur, la date et les filtres."
      actions={
        <Bouton
          variante="principal"
          onClick={exporter}
          icone={<Download aria-hidden="true" className="h-4 w-4" />}
        >
          Exporter en CSV
        </Bouton>
      }
    >
      <Section className="mb-4">
        <div className="grid gap-3 p-3 sm:grid-cols-2 lg:grid-cols-4">
          <ChampSelection
            etiquette="Rapport"
            value={rapport}
            onChange={(e) => setRapport(e.target.value as Rapport)}
          >
            {RAPPORTS.map((element) => (
              <option key={element.valeur} value={element.valeur}>
                {element.libelle}
              </option>
            ))}
          </ChampSelection>
          <ChampSelection
            etiquette="Client"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
          >
            <option value="">Tous les clients</option>
            {donnees.clients.map((client) => (
              <option key={client.id} value={client.id}>
                {client.nom}
              </option>
            ))}
          </ChampSelection>
          <div>
            <label htmlFor="periode-debut" className="etiquette-champ">
              Du
            </label>
            <input
              id="periode-debut"
              type="date"
              value={depuis}
              onChange={(e) => setDepuis(e.target.value)}
              className="champ mt-1.5"
            />
          </div>
          <div>
            <label htmlFor="periode-fin" className="etiquette-champ">
              Au
            </label>
            <input
              id="periode-fin"
              type="date"
              value={jusqua}
              onChange={(e) => setJusqua(e.target.value)}
              className="champ mt-1.5"
            />
          </div>
        </div>
      </Section>

      <Section titre={`${formatNombre(contenu.lignes.length)} ligne(s)`}>
        {contenu.lignes.length === 0 ? (
          <EtatVide titre="Aucune donnee pour ces filtres" texte="Elargissez la periode ou changez de client." />
        ) : (
          <Tableau
            legende="Resultat du rapport"
            entetes={contenu.entetes.map((libelle, index) => ({
              libelle,
              alignement: index >= 4 && !Number.isNaN(Number(contenu.lignes[0]?.[index])) ? 'droite' : 'gauche',
            }))}
          >
            {contenu.lignes.slice(0, 100).map((ligne, index) => (
              <tr key={index} className="hover:bg-alfa-surface">
                {ligne.map((cellule, position) => (
                  <Cellule
                    key={position}
                    alignement={typeof cellule === 'number' ? 'droite' : 'gauche'}
                  >
                    {cellule}
                  </Cellule>
                ))}
              </tr>
            ))}
          </Tableau>
        )}
        {contenu.lignes.length > 100 && (
          <p className="border-t border-alfa-line px-4 py-2.5 text-sm text-alfa-slate">
            100 premieres lignes affichees. L'export CSV contient l'integralite.
          </p>
        )}
      </Section>

      {peutLireJournal && <JournalActivite />}
    </Page>
  );
}

function JournalActivite() {
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();

  return (
    <Section titre="Journal d'activite" className="mt-4">
      {donnees.journal.length === 0 ? (
        <EtatVide titre="Journal vide" />
      ) : (
        <Tableau
          legende="Journal d'activite en ajout seul"
          entetes={[
            { libelle: 'Date et heure' },
            { libelle: 'Utilisateur' },
            { libelle: 'Action' },
            { libelle: 'Entite' },
            { libelle: 'Avant', discret: true },
            { libelle: 'Apres', discret: true },
            { libelle: 'Motif', discret: true },
          ]}
        >
          {donnees.journal.slice(0, 60).map((entree) => (
            <tr key={entree.id} className="hover:bg-alfa-surface">
              <Cellule>
                <span className="whitespace-nowrap text-alfa-slate">
                  {formatDateHeure(entree.dateHeure)}
                </span>
              </Cellule>
              <Cellule>{reference.nomUtilisateur(entree.utilisateurId)}</Cellule>
              <Cellule>{entree.action}</Cellule>
              <Cellule>
                <span className="text-alfa-slate">
                  {entree.entiteType} · {entree.entiteId}
                </span>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-muted">{entree.valeurAvant ?? '—'}</span>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-muted">{entree.valeurApres ?? '—'}</span>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-muted">{entree.motif ?? '—'}</span>
              </Cellule>
            </tr>
          ))}
        </Tableau>
      )}
    </Section>
  );
}

/* ============================================ Administration */

export function Administration() {
  const donnees = useBoutique((e) => e.donnees);
  const reinitialiser = useBoutique((e) => e.reinitialiser);
  const roleActif = useBoutique((e) => e.roleActif);
  const [confirmation, setConfirmation] = useState(false);

  return (
    <Page
      titre="Administration"
      description="Parametres du demonstrateur, comptes simules et remise a zero des donnees."
      actions={
        <Bouton
          variante="danger"
          onClick={() => setConfirmation(true)}
          icone={<RotateCcw aria-hidden="true" className="h-4 w-4" />}
        >
          Reinitialiser les donnees de demonstration
        </Bouton>
      }
    >
      <div className="grid gap-4 lg:grid-cols-2">
        <Section titre="Organisation emettrice">
          <dl className="grid grid-cols-2 gap-4 p-4">
            <Donnee terme="Marque" valeur={ORGANISATION.marque} accent />
            <Donnee terme="Entite legale" valeur={ORGANISATION.raisonSociale} />
            <Donnee terme="Adresse" valeur={`${ORGANISATION.adresse}, ${ORGANISATION.ville}`} />
            <Donnee terme="Telephone" valeur={ORGANISATION.telephone} />
            <Donnee terme="Telecopieur" valeur={ORGANISATION.telecopieur} />
            <Donnee terme="Depot" valeur="Sainte-Sophie (un seul depot au MVP)" />
          </dl>
        </Section>

        <Section titre="Etat des donnees">
          <dl className="grid grid-cols-2 gap-4 p-4 sm:grid-cols-3">
            <Donnee terme="Articles" valeur={formatNombre(donnees.produits.length)} accent />
            <Donnee terme="Mouvements" valeur={formatNombre(donnees.mouvements.length)} accent />
            <Donnee terme="Clients" valeur={donnees.clients.length} />
            <Donnee terme="Chantiers" valeur={donnees.chantiers.length} />
            <Donnee terme="Demandes" valeur={donnees.demandes.length} />
            <Donnee terme="Bons" valeur={donnees.sorties.length} />
            <Donnee terme="Locations" valeur={donnees.locations.length} />
            <Donnee terme="Retours" valeur={donnees.retours.length} />
            <Donnee terme="Ecarts" valeur={donnees.ecarts.length} />
          </dl>
          <p className="border-t border-alfa-line px-4 py-3 text-sm text-alfa-slate">
            Les donnees sont conservees dans le navigateur et survivent a une actualisation. La
            reinitialisation les remet toutes dans leur etat initial.
          </p>
        </Section>
      </div>

      <Section titre="Comptes et permissions simules" className="mt-4">
        <Tableau
          legende="Utilisateurs de demonstration et leurs droits"
          entetes={[
            { libelle: 'Utilisateur' },
            { libelle: 'Role' },
            { libelle: 'Fonction', discret: true },
            { libelle: 'Droits' },
            { libelle: 'Actif' },
          ]}
        >
          {donnees.utilisateurs.map((utilisateur) => (
            <tr key={utilisateur.id} className="hover:bg-alfa-surface">
              <Cellule>
                <span className="font-medium text-alfa-ink">{utilisateur.nom}</span>
              </Cellule>
              <Cellule>
                <Statut ton={utilisateur.role === roleActif ? 'info' : 'neutre'}>
                  {LIBELLE_ROLE[utilisateur.role]}
                </Statut>
              </Cellule>
              <Cellule discret>
                <span className="text-alfa-slate">{utilisateur.fonction}</span>
              </Cellule>
              <Cellule>
                <span className="text-alfa-slate">
                  {PERMISSIONS_PAR_ROLE[utilisateur.role as Role].length} permissions
                </span>
              </Cellule>
              <Cellule>
                {utilisateur.actif ? <Statut ton="succes">Actif</Statut> : <Statut>Suspendu</Statut>}
              </Cellule>
            </tr>
          ))}
        </Tableau>
      </Section>

      <Section titre="Limites du demonstrateur" className="mt-4">
        <div className="space-y-3 p-4">
          <Message
            ton="attention"
            titre="Fonctions simulees — a ne pas presenter comme securisees"
            details={[
              "Authentification : absente. Le selecteur de role n'est pas un controle d'acces.",
              'Signature electronique : simulation sans valeur juridique.',
              "Journal d'audit : non infalsifiable, conserve dans le navigateur.",
              'Envoi de courriels : simule, aucun message reel expedie.',
              'Liens client : ni signes, ni expirables, ni revocables.',
              'Sauvegarde serveur et separation des organisations : absentes.',
            ]}
          />
          <p className="flex items-center gap-2 text-sm text-alfa-slate">
            <ShieldCheck aria-hidden="true" className="h-4 w-4 flex-none text-alfa-muted" />
            Le detail figure dans MVP_VS_PRODUCTION.md, livre avec le projet.
          </p>
        </div>
      </Section>

      <Confirmation
        ouverte={confirmation}
        titre="Reinitialiser les donnees de demonstration"
        description="Toutes les modifications faites pendant la demonstration seront perdues et les donnees reviendront a leur etat initial."
        libelleAction="Reinitialiser"
        onAnnuler={() => setConfirmation(false)}
        onConfirmer={() => {
          void reinitialiser();
          setConfirmation(false);
        }}
      />
    </Page>
  );
}
