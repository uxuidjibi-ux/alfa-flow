import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Camera, Check, Lock } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  ChampSelection,
  ChampTexte,
  CompteurQuantite,
  Donnee,
  EtatVide,
  Message,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutRetourBadge } from '../../components/ui/statuts';
import {
  apercuRetour,
  cloturerRetour,
  majLigneRetour,
  validerRetour,
} from '../../services/operations';
import { LIBELLE_ETAT_ARTICLE } from '../../models/referentiel';
import { formatDate, maintenant, somme } from '../../utils';
import type { EtatArticle, PhotoRef } from '../../models/types';

/** ECRAN 9 — liste des retours. */
export function Retours() {
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();

  const retours = [...donnees.retours].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <Page
      titre="Retours et rapprochement"
      description="Le systeme calcule l'ecart entre l'attendu et l'accepte ; la decision reste humaine."
    >
      <ul className="space-y-2 lg:hidden">
        {retours.map((retour) => {
          const location = donnees.locations.find((l) => l.id === retour.locationId);
          const attendue = somme(retour.lignes, (l) => l.quantiteAttendue);
          const acceptee = somme(retour.lignes, (l) => l.quantiteAcceptee);
          return (
            <li key={retour.id}>
              <Link
                to={`/retours/${retour.id}`}
                className="flex flex-col gap-2 rounded-alfa border border-alfa-line p-3 hover:bg-alfa-surface"
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="min-w-0">
                    <span className="block font-medium text-alfa-ink">{retour.numero}</span>
                    <span className="block truncate text-xs text-alfa-muted">
                      {location ? reference.nomClient(location.clientId) : '—'}
                    </span>
                  </span>
                  <StatutRetourBadge statut={retour.statut} />
                </span>
                <span className="flex items-center justify-between text-sm text-alfa-slate">
                  <span>Attendu {attendue} · accepte {acceptee}</span>
                  <span className={attendue - acceptee > 0 ? 'font-semibold text-alfa-redDark' : ''}>
                    Ecart {attendue - acceptee}
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      <Section className="hidden lg:block">
        {retours.length === 0 ? (
          <EtatVide
            titre="Aucun retour en cours"
            texte="Ouvrez un retour depuis la fiche d'une location."
            action={
              <Link to="/locations" className="text-alfa-redDark underline">
                Voir les locations
              </Link>
            }
          />
        ) : (
          <Tableau
            legende="Retours enregistres"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Location' },
              { libelle: 'Client', discret: true },
              { libelle: 'Date' },
              { libelle: 'Attendue', alignement: 'droite' },
              { libelle: 'Acceptee', alignement: 'droite' },
              { libelle: 'Ecart', alignement: 'droite' },
              { libelle: 'Statut' },
            ]}
          >
            {retours.map((retour) => {
              const location = donnees.locations.find((l) => l.id === retour.locationId);
              const attendue = somme(retour.lignes, (l) => l.quantiteAttendue);
              const acceptee = somme(retour.lignes, (l) => l.quantiteAcceptee);
              const ecart = attendue - acceptee;
              return (
                <tr key={retour.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link
                      to={`/retours/${retour.id}`}
                      className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                    >
                      {retour.numero}
                    </Link>
                  </Cellule>
                  <Cellule>
                    {location && (
                      <Link to={`/locations/${location.id}`} className="text-alfa-slate hover:underline">
                        {location.numero}
                      </Link>
                    )}
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">
                      {location ? reference.nomClient(location.clientId) : '—'}
                    </span>
                  </Cellule>
                  <Cellule>
                    <span className="whitespace-nowrap text-alfa-slate">{formatDate(retour.date)}</span>
                  </Cellule>
                  <Cellule alignement="droite">{attendue}</Cellule>
                  <Cellule alignement="droite">{acceptee}</Cellule>
                  <Cellule alignement="droite">
                    <span className={ecart > 0 ? 'font-semibold text-alfa-redDark' : 'text-alfa-muted'}>
                      {ecart}
                    </span>
                  </Cellule>
                  <Cellule>
                    <StatutRetourBadge statut={retour.statut} />
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        )}
      </Section>
    </Page>
  );
}

/**
 * Assistant de retour, optimise pour le responsable de cour.
 * US-023 : l'ecart est calcule et presente AVANT toute decision.
 * Une ligne sans saisie est « non comptee », jamais interpretee comme zero.
 */
export function FicheRetour() {
  const { retourId } = useParams<{ retourId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutRetourner = useDroit('retour.executer');
  const [notes, setNotes] = useState('');

  const retour = donnees.retours.find((r) => r.id === retourId);
  if (!retour) {
    return (
      <Page titre="Retour introuvable">
        <Section>
          <EtatVide
            titre="Ce retour n'existe pas"
            action={
              <Link to="/retours" className="text-alfa-redDark underline">
                Retour a la liste
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const contexte = { utilisateurId: utilisateur.id, appareil: 'Tablette de cour' };
  const location = donnees.locations.find((l) => l.id === retour.locationId);
  const apercu = apercuRetour(donnees, retour.id);
  const modifiable = peutRetourner && (retour.statut === 'COMMENCE' || retour.statut === 'COMPTAGE');
  const ecartsLies = donnees.ecarts.filter((e) => e.retourId === retour.id);

  const majLigne = (ligneId: string, patch: Parameters<typeof majLigneRetour>[3]) => {
    appliquer(majLigneRetour(donnees, retour.id, ligneId, patch), '');
  };

  const ajouterPhoto = (ligneId: string, photos: PhotoRef[], categorie: PhotoRef['categorie']) => {
    const ligne = retour.lignes.find((l) => l.id === ligneId);
    const produit = ligne ? reference.produit(ligne.produitId) : undefined;
    majLigne(ligneId, {
      photos: [
        ...photos,
        {
          id: `photo_${Date.now()}`,
          cle: produit?.image ?? '',
          legende: `Constat au retour — ${produit?.nom ?? ''}`,
          dateHeure: maintenant(),
          categorie,
          utilisateurId: utilisateur.id,
          version: photos.length + 1,
          remplacePhotoId: null,
        },
      ],
    });
  };

  const totalEcart = apercu.reduce((t, l) => t + l.ecart, 0);
  const lignesNonComptees = apercu.filter((l) => !l.compte);

  return (
    <Page
      titre={`Retour ${retour.numero}`}
      fil={[{ libelle: 'Retours', lien: '/retours' }, { libelle: retour.numero }]}
      actions={
        <>
          {modifiable && (
            <Bouton
              variante="principal"
              onClick={() =>
                appliquer(
                  validerRetour(donnees, retour.id, contexte),
                  'Comptage soumis. Les stocks et les ecarts sont a jour.',
                )
              }
              icone={<Check aria-hidden="true" className="h-4 w-4" />}
            >
              Soumettre le comptage
            </Bouton>
          )}
          {(retour.statut === 'ECART_DETECTE' ||
            retour.statut === 'VERIFICATION' ||
            retour.statut === 'ACCEPTE') && (
            <Bouton
              onClick={() =>
                appliquer(cloturerRetour(donnees, retour.id, contexte), 'Retour cloture.')
              }
              icone={<Lock aria-hidden="true" className="h-4 w-4" />}
            >
              Cloturer le retour
            </Bouton>
          )}
        </>
      }
    >
      <div className="mb-4 grid gap-4 lg:grid-cols-4">
        <Section titre="Dossier">
          <dl className="space-y-3.5 p-4">
            <Donnee terme="Statut" valeur={<StatutRetourBadge statut={retour.statut} />} />
            <Donnee
              terme="Location"
              valeur={
                location ? (
                  <Link to={`/locations/${location.id}`} className="text-alfa-ink hover:underline">
                    {location.numero}
                  </Link>
                ) : (
                  '—'
                )
              }
            />
            <Donnee terme="Client" valeur={location ? reference.nomClient(location.clientId) : '—'} />
            <Donnee terme="Chantier" valeur={location ? reference.nomChantier(location.chantierId) : '—'} />
            <Donnee terme="Date du retour" valeur={formatDate(retour.date)} accent />
            <Donnee terme="Receptionnaire" valeur={reference.nomUtilisateur(retour.receptionnaireId)} />
          </dl>
        </Section>

        {/* L'ecart est presente avant toute decision. */}
        <Section titre="Ecart calcule par le systeme" className="lg:col-span-3">
          <div className="p-4">
            <div className="flex flex-wrap items-end gap-6">
              <div>
                <p className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
                  Ecart total du retour
                </p>
                <p
                  className={
                    totalEcart > 0
                      ? 'text-3xl font-semibold tabular-nums text-alfa-red'
                      : 'text-3xl font-semibold tabular-nums text-etat-succes'
                  }
                >
                  {totalEcart}
                </p>
                <p className="text-xs text-alfa-muted">
                  Quantite attendue moins quantite acceptee
                </p>
              </div>
              <Donnee terme="Attendue" valeur={apercu.reduce((t, l) => t + l.attendue, 0)} />
              <Donnee terme="Acceptee" valeur={apercu.reduce((t, l) => t + l.acceptee, 0)} accent />
              <Donnee terme="Endommagee" valeur={apercu.reduce((t, l) => t + l.endommagee, 0)} />
              <Donnee terme="Manquante" valeur={apercu.reduce((t, l) => t + l.manquante, 0)} />
              <Donnee terme="Excedent" valeur={apercu.reduce((t, l) => t + l.excedent, 0)} />
            </div>

            {modifiable && lignesNonComptees.length > 0 && (
              <div className="mt-4">
                <Message
                  ton="attention"
                  titre={`${lignesNonComptees.length} ligne(s) ne sont pas encore comptees.`}
                  details={lignesNonComptees.map(
                    (l) => `${l.nom} : aucune quantite saisie. Une ligne non comptee n est pas un zero.`,
                  )}
                />
              </div>
            )}
          </div>
        </Section>
      </div>

      <ul className="space-y-3">
        {retour.lignes.map((ligne) => {
          const produit = reference.produit(ligne.produitId);
          const qualifie =
            ligne.quantiteAcceptee +
            ligne.quantiteEndommagee +
            ligne.quantiteManquante +
            ligne.quantiteContestee;
          const restant = ligne.quantiteAttendue - qualifie;

          return (
            <li key={ligne.id} className="carte p-3 sm:p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <Link
                    to={`/catalogue/${ligne.produitId}`}
                    className="font-medium text-alfa-ink hover:underline"
                  >
                    {produit?.nom ?? ligne.produitId}
                  </Link>
                  <p className="mt-0.5 text-xs text-alfa-muted">
                    {produit?.codeItem} · attendu pour ce retour : {ligne.quantiteAttendue} unites
                  </p>
                </div>
                <div className="flex gap-4 text-right">
                  <Donnee terme="Qualifie" valeur={qualifie} accent />
                  <Donnee
                    terme="A qualifier"
                    valeur={
                      <span className={restant > 0 ? 'font-semibold text-alfa-redDark' : ''}>
                        {restant}
                      </span>
                    }
                  />
                </div>
              </div>

              {modifiable ? (
                <div className="mt-3 space-y-4 border-t border-alfa-line pt-3">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <ChampQuantiteRetour
                      etiquette="Acceptee en bon etat"
                      valeur={ligne.quantiteAcceptee}
                      max={ligne.quantiteAttendue}
                      onChange={(v) => majLigne(ligne.id, { quantiteAcceptee: v })}
                    />
                    <ChampQuantiteRetour
                      etiquette="Endommagee (quarantaine)"
                      valeur={ligne.quantiteEndommagee}
                      max={ligne.quantiteAttendue}
                      onChange={(v) => majLigne(ligne.id, { quantiteEndommagee: v })}
                    />
                    <ChampQuantiteRetour
                      etiquette="Manquante (due par le client)"
                      valeur={ligne.quantiteManquante}
                      max={ligne.quantiteAttendue}
                      onChange={(v) => majLigne(ligne.id, { quantiteManquante: v })}
                    />
                    <ChampQuantiteRetour
                      etiquette="Contestee"
                      valeur={ligne.quantiteContestee}
                      max={ligne.quantiteAttendue}
                      onChange={(v) => majLigne(ligne.id, { quantiteContestee: v })}
                    />
                    <ChampQuantiteRetour
                      etiquette="Excedent recu (non attribue)"
                      valeur={ligne.quantiteExcedent}
                      onChange={(v) => majLigne(ligne.id, { quantiteExcedent: v })}
                    />
                    <ChampSelection
                      etiquette="Qualification du materiel"
                      value={ligne.etat}
                      onChange={(e) => majLigne(ligne.id, { etat: e.target.value as EtatArticle })}
                    >
                      {(Object.keys(LIBELLE_ETAT_ARTICLE) as EtatArticle[]).map((etat) => (
                        <option key={etat} value={etat}>
                          {LIBELLE_ETAT_ARTICLE[etat]}
                        </option>
                      ))}
                    </ChampSelection>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <Bouton
                      compact
                      onClick={() =>
                        ajouterPhoto(
                          ligne.id,
                          ligne.photos,
                          ligne.quantiteEndommagee > 0 ? 'DOMMAGE' : 'RETOUR',
                        )
                      }
                      icone={<Camera aria-hidden="true" className="h-4 w-4" />}
                    >
                      Ajouter une photo
                    </Bouton>
                    {ligne.photos.map((photo) => (
                      <span key={photo.id} className="text-xs text-alfa-muted">
                        {photo.legende}
                      </span>
                    ))}
                  </div>

                  <ChampTexte
                    etiquette="Commentaire"
                    value={ligne.commentaire}
                    onChange={(e) => majLigne(ligne.id, { commentaire: e.target.value })}
                    aide="Obligatoire pour tout dommage : une photo est egalement exigee."
                  />
                </div>
              ) : (
                <div className="mt-3 flex flex-wrap gap-4 border-t border-alfa-line pt-3 text-sm">
                  <Donnee terme="Acceptee" valeur={ligne.quantiteAcceptee} />
                  <Donnee terme="Endommagee" valeur={ligne.quantiteEndommagee} />
                  <Donnee terme="Manquante" valeur={ligne.quantiteManquante} />
                  <Donnee terme="Contestee" valeur={ligne.quantiteContestee} />
                  <Donnee terme="Etat" valeur={LIBELLE_ETAT_ARTICLE[ligne.etat]} />
                </div>
              )}
            </li>
          );
        })}
      </ul>

      {modifiable && (
        <Section titre="Note du retour" className="mt-4">
          <div className="p-4">
            <ChampTexte
              etiquette="Observations generales"
              value={notes || retour.notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </Section>
      )}

      {ecartsLies.length > 0 && (
        <Section titre="Ecarts generes" className="mt-4">
          <ul className="divide-y divide-alfa-line">
            {ecartsLies.map((ecart) => (
              <li key={ecart.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5">
                <span className="text-sm">
                  <strong className="text-alfa-ink">{ecart.numero}</strong> — {ecart.quantite} ×{' '}
                  {reference.nomProduit(ecart.produitId)}
                </span>
                <span className="flex items-center gap-2">
                  <Statut ton="attention">{ecart.type}</Statut>
                  <Link to="/ecarts" className="text-sm font-medium text-alfa-redDark hover:underline">
                    Traiter
                  </Link>
                </span>
              </li>
            ))}
          </ul>
        </Section>
      )}
    </Page>
  );
}

function ChampQuantiteRetour({
  etiquette,
  valeur,
  max,
  onChange,
}: {
  etiquette: string;
  valeur: number;
  max?: number;
  onChange: (valeur: number) => void;
}) {
  return (
    <div>
      <p className="mb-1.5 text-sm font-medium text-alfa-ink">{etiquette}</p>
      <CompteurQuantite etiquette={etiquette} valeur={valeur} max={max} onChange={onChange} />
    </div>
  );
}
