import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Camera, Check, CircleAlert, Trash2, Truck } from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useDroit, useReferentiel } from '../../state/selecteurs';
import {
  Bouton,
  Cellule,
  Champ,
  ChampTexte,
  CompteurQuantite,
  Donnee,
  EtatVide,
  Message,
  Modale,
  Page,
  Section,
  Statut,
  Tableau,
} from '../../components/ui/primitives';
import { StatutPreparationBadge, TypeItemBadge } from '../../components/ui/statuts';
import {
  confirmerSortie,
  controlerPreparation,
  majLignePreparation,
  marquerPreparationPrete,
} from '../../services/operations';
import { DUREE_LOCATION_MINIMALE_JOURS } from '../../models/referentiel';
import { formatDate, maintenant, somme } from '../../utils';
import type { PhotoRef } from '../../models/types';

/** ECRAN 5 — liste des preparations. */
export function Preparations() {
  const donnees = useBoutique((e) => e.donnees);
  const reference = useReferentiel();

  const preparations = useMemo(
    () =>
      [...donnees.preparations].sort((a, b) => {
        const rang = { BLOQUEE: 0, A_PREPARER: 1, EN_PREPARATION: 2, PARTIELLEMENT_PREPAREE: 3, PRETE: 4 };
        return rang[a.statut] - rang[b.statut] || a.numero.localeCompare(b.numero);
      }),
    [donnees.preparations],
  );

  return (
    <Page
      titre="Preparations"
      description="Fiches utilisables sur tablette et telephone dans la cour. Une preparation peut se faire en plusieurs vagues."
    >
      {/* Telephone : liste de cartes, aucun tableau a faire defiler. */}
      <ul className="space-y-2 lg:hidden">
        {preparations.map((preparation) => {
          const demande = reference.demande(preparation.demandeId);
          const prepare = somme(preparation.lignes, (l) => l.quantitePreparee);
          const confirme = somme(preparation.lignes, (l) => l.quantiteConfirmee);
          return (
            <li key={preparation.id}>
              <Link
                to={`/preparations/${preparation.id}`}
                className="flex flex-col gap-2 rounded-alfa border border-alfa-line p-3 hover:bg-alfa-surface"
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="min-w-0">
                    <span className="block font-medium text-alfa-ink">{preparation.numero}</span>
                    <span className="block truncate text-xs text-alfa-muted">
                      {demande ? reference.nomClient(demande.clientId) : '—'}
                    </span>
                  </span>
                  <StatutPreparationBadge statut={preparation.statut} />
                </span>
                <span className="flex items-center justify-between text-sm">
                  <span className="truncate text-alfa-slate">
                    {demande ? reference.nomChantier(demande.chantierId) : '—'}
                  </span>
                  <span className="flex-none font-semibold tabular-nums text-alfa-ink">
                    {prepare} / {confirme}
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      <Section className="hidden lg:block">
        {preparations.length === 0 ? (
          <EtatVide titre="Aucune preparation en cours" />
        ) : (
          <Tableau
            legende="Preparations en cours et terminees"
            entetes={[
              { libelle: 'Numero' },
              { libelle: 'Client' },
              { libelle: 'Chantier', discret: true },
              { libelle: 'Assignee a', discret: true },
              { libelle: 'Prepare', alignement: 'droite' },
              { libelle: 'Confirme', alignement: 'droite' },
              { libelle: 'Statut' },
            ]}
          >
            {preparations.map((preparation) => {
              const demande = reference.demande(preparation.demandeId);
              const prepare = somme(preparation.lignes, (l) => l.quantitePreparee);
              const confirme = somme(preparation.lignes, (l) => l.quantiteConfirmee);
              return (
                <tr key={preparation.id} className="hover:bg-alfa-surface">
                  <Cellule>
                    <Link
                      to={`/preparations/${preparation.id}`}
                      className="font-medium text-alfa-ink hover:text-alfa-redDark hover:underline"
                    >
                      {preparation.numero}
                    </Link>
                    <span className="block text-xs text-alfa-muted">
                      Vague {preparation.vague} · {demande?.numero}
                    </span>
                  </Cellule>
                  <Cellule>{demande ? reference.nomClient(demande.clientId) : '—'}</Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">
                      {demande ? reference.nomChantier(demande.chantierId) : '—'}
                    </span>
                  </Cellule>
                  <Cellule discret>
                    <span className="text-alfa-slate">
                      {preparation.assigneAId ? reference.nomUtilisateur(preparation.assigneAId) : '—'}
                    </span>
                  </Cellule>
                  <Cellule alignement="droite">{prepare}</Cellule>
                  <Cellule alignement="droite">{confirme}</Cellule>
                  <Cellule>
                    <StatutPreparationBadge statut={preparation.statut} />
                  </Cellule>
                </tr>
              );
            })}
          </Tableau>
        )}
      </Section>
    </Page>
  );
}

/**
 * Fiche de preparation, concue pour la cour.
 * Zones tactiles larges, incrementes rapides, photo par ligne, controle final
 * qui explique chaque point bloquant (BF-012 a BF-019).
 */
export function FichePreparation() {
  const { preparationId } = useParams<{ preparationId: string }>();
  const donnees = useBoutique((e) => e.donnees);
  const appliquer = useBoutique((e) => e.appliquer);
  const notifier = useBoutique((e) => e.notifier);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const reference = useReferentiel();
  const peutPreparer = useDroit('preparation.executer');
  const peutSortir = useDroit('sortie.confirmer');
  const naviguer = useNavigate();

  const preparation = donnees.preparations.find((p) => p.id === preparationId);
  const [sortieOuverte, setSortieOuverte] = useState(false);
  const [livreur, setLivreur] = useState('');
  const [representant, setRepresentant] = useState('');
  const [bonCommande, setBonCommande] = useState('');
  const [jours, setJours] = useState(String(DUREE_LOCATION_MINIMALE_JOURS));
  const [controle, setControle] = useState<{ message: string; details: string[] } | null>(null);

  if (!preparation) {
    return (
      <Page titre="Preparation introuvable">
        <Section>
          <EtatVide
            titre="Cette preparation n'existe pas"
            action={
              <Link to="/preparations" className="text-alfa-redDark underline">
                Retour aux preparations
              </Link>
            }
          />
        </Section>
      </Page>
    );
  }

  const contexte = { utilisateurId: utilisateur.id, appareil: 'Tablette de cour' };
  const demande = reference.demande(preparation.demandeId);
  const modifiable = preparation.statut !== 'PRETE' && peutPreparer;
  const sortie = donnees.sorties.find((s) => s.preparationId === preparation.id);

  const majLigne = (ligneId: string, patch: Parameters<typeof majLignePreparation>[3]) => {
    const resultat = majLignePreparation(donnees, preparation.id, ligneId, patch);
    appliquer(resultat, '');
  };

  const ajouterPhoto = (ligneId: string, photos: PhotoRef[]) => {
    // Capture simulee : la photo de reference du produit sert d'illustration.
    const ligne = preparation.lignes.find((l) => l.id === ligneId);
    const produit = ligne ? reference.produit(ligne.produitId) : undefined;
    const photo: PhotoRef = {
      id: `photo_${Date.now()}`,
      cle: produit?.image ?? '',
      legende: `Photo avant depart — ${produit?.nom ?? ''}`,
      dateHeure: maintenant(),
      categorie: 'AVANT_DEPART',
      utilisateurId: utilisateur.id,
      version: photos.length + 1,
      remplacePhotoId: null,
    };
    majLigne(ligneId, { photos: [...photos, photo] });
  };

  const verifier = () => {
    const resultat = controlerPreparation(donnees, preparation.id);
    if (resultat.ok) {
      setControle(null);
      notifier('succes', 'Controle final reussi : la preparation peut passer a « Prete ».');
      return true;
    }
    setControle({
      message: resultat.message ?? 'Controle refuse.',
      details: resultat.details ?? [],
    });
    return false;
  };

  const declarerPrete = () => {
    if (!verifier()) return;
    appliquer(
      marquerPreparationPrete(donnees, preparation.id, contexte),
      `Preparation ${preparation.numero} declaree prete.`,
    );
  };

  const confirmer = () => {
    const resultat = confirmerSortie(
      donnees,
      preparation.id,
      {
        livreur,
        signataireNom: reference.contact(demande?.contactId ?? null)?.nom ?? '',
        joursLocation: Number(jours) || DUREE_LOCATION_MINIMALE_JOURS,
        representant,
        bonCommandeClient: bonCommande,
        expedieVia: 'Camion Groupe Alfa',
      },
      contexte,
    );
    if (appliquer(resultat, 'Sortie confirmee et bon de livraison genere.')) {
      setSortieOuverte(false);
      naviguer('/livraisons');
    }
  };

  const totalPrepare = somme(preparation.lignes, (l) => l.quantitePreparee);
  const totalConfirme = somme(preparation.lignes, (l) => l.quantiteConfirmee);

  return (
    <Page
      titre={preparation.numero}
      fil={[{ libelle: 'Preparations', lien: '/preparations' }, { libelle: preparation.numero }]}
      actions={
        <>
          {modifiable && (
            <>
              <Bouton onClick={verifier}>Controle final</Bouton>
              <Bouton
                variante="principal"
                onClick={declarerPrete}
                icone={<Check aria-hidden="true" className="h-4 w-4" />}
              >
                Declarer prete
              </Bouton>
            </>
          )}
          {preparation.statut === 'PRETE' && !sortie && peutSortir && (
            <Bouton
              variante="principal"
              onClick={() => setSortieOuverte(true)}
              icone={<Truck aria-hidden="true" className="h-4 w-4" />}
            >
              Confirmer la sortie
            </Bouton>
          )}
          {sortie && (
            <Bouton onClick={() => naviguer(`/livraisons/${sortie.id}`)}>
              Ouvrir le bon {sortie.numero}
            </Bouton>
          )}
        </>
      }
    >
      <div className="mb-4 grid gap-4 lg:grid-cols-4">
        <Section titre="Dossier">
          <dl className="space-y-3.5 p-4">
            <Donnee terme="Statut" valeur={<StatutPreparationBadge statut={preparation.statut} />} />
            <Donnee terme="Client" valeur={demande ? reference.nomClient(demande.clientId) : '—'} />
            <Donnee terme="Chantier" valeur={demande ? reference.nomChantier(demande.chantierId) : '—'} />
            <Donnee terme="Date souhaitee" valeur={demande ? formatDate(demande.dateSouhaitee) : '—'} accent />
            <Donnee
              terme="Preparateur"
              valeur={preparation.assigneAId ? reference.nomUtilisateur(preparation.assigneAId) : '—'}
            />
            <Donnee terme="Vague" valeur={preparation.vague} />
          </dl>
        </Section>

        <Section titre="Avancement" className="lg:col-span-3">
          <div className="p-4">
            <div className="flex items-end justify-between gap-3">
              <p className="text-3xl font-semibold tabular-nums text-alfa-ink">
                {totalPrepare}
                <span className="text-lg font-normal text-alfa-muted"> / {totalConfirme} unites</span>
              </p>
              <p className="text-sm text-alfa-slate">
                Reliquat :{' '}
                <strong className="tabular-nums">{Math.max(0, totalConfirme - totalPrepare)}</strong>
              </p>
            </div>
            <div
              className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-alfa-surface"
              role="progressbar"
              aria-valuenow={totalPrepare}
              aria-valuemin={0}
              aria-valuemax={totalConfirme}
              aria-label="Avancement de la preparation"
            >
              <div
                className="h-full bg-alfa-red"
                style={{ width: `${totalConfirme === 0 ? 0 : (totalPrepare / totalConfirme) * 100}%` }}
              />
            </div>

            {controle && (
              <div className="mt-4">
                <Message ton="erreur" titre={controle.message} details={controle.details} />
              </div>
            )}
          </div>
        </Section>
      </div>

      <ul className="space-y-3">
        {preparation.lignes.map((ligne) => {
          const produit = reference.produit(ligne.produitId);
          const reliquat = ligne.quantiteConfirmee - ligne.quantitePreparee;

          return (
            <li key={ligne.id} className="carte p-3 sm:p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <Link
                    to={`/catalogue/${ligne.produitId}`}
                    className="font-medium text-alfa-ink hover:underline"
                  >
                    {produit?.nom ?? ligne.produitId}
                  </Link>
                  <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-alfa-muted">
                    <span>{produit?.codeItem}</span>
                    <TypeItemBadge type={ligne.typeItem} />
                    <span className="font-medium text-alfa-slate">{produit?.emplacement}</span>
                  </p>
                </div>
                <div className="flex gap-5 text-right">
                  <Donnee terme="Confirme" valeur={ligne.quantiteConfirmee} />
                  <Donnee terme="Prepare" valeur={ligne.quantitePreparee} accent />
                  <Donnee
                    terme="Reliquat"
                    valeur={
                      <span className={reliquat > 0 ? 'font-semibold text-alfa-redDark' : ''}>
                        {reliquat}
                      </span>
                    }
                  />
                </div>
              </div>

              {modifiable ? (
                <div className="mt-3 space-y-3 border-t border-alfa-line pt-3">
                  <CompteurQuantite
                    etiquette={`Quantite preparee pour ${produit?.nom ?? ''}`}
                    valeur={ligne.quantitePreparee}
                    max={ligne.quantiteConfirmee}
                    onChange={(valeur) => majLigne(ligne.id, { quantitePreparee: valeur })}
                  />

                  <div className="flex flex-wrap items-center gap-2">
                    <Bouton
                      compact
                      onClick={() => ajouterPhoto(ligne.id, ligne.photos)}
                      icone={<Camera aria-hidden="true" className="h-4 w-4" />}
                    >
                      Ajouter une photo
                    </Bouton>
                    <Bouton
                      compact
                      variante={ligne.confirmee ? 'principal' : 'secondaire'}
                      onClick={() => majLigne(ligne.id, { confirmee: !ligne.confirmee })}
                      icone={<Check aria-hidden="true" className="h-4 w-4" />}
                    >
                      {ligne.confirmee ? 'Ligne confirmee' : 'Confirmer la ligne'}
                    </Bouton>
                    <Bouton
                      compact
                      variante={ligne.manquant ? 'danger' : 'secondaire'}
                      onClick={() => majLigne(ligne.id, { manquant: !ligne.manquant })}
                      icone={<CircleAlert aria-hidden="true" className="h-4 w-4" />}
                    >
                      {ligne.manquant ? 'Declare manquant' : 'Article manquant'}
                    </Bouton>
                  </div>

                  {ligne.photos.length > 0 && (
                    <ul className="flex flex-wrap gap-2">
                      {ligne.photos.map((photo) => (
                        <li key={photo.id} className="relative">
                          <div className="h-20 w-20 overflow-hidden rounded-alfa border border-alfa-line bg-alfa-surface">
                            {photo.cle ? (
                              <img
                                src={photo.cle}
                                alt={photo.legende}
                                className="h-full w-full object-contain"
                              />
                            ) : (
                              <span className="flex h-full items-center justify-center text-xs text-alfa-muted">
                                Photo
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            aria-label={`Retirer la photo ${photo.legende}`}
                            onClick={() =>
                              majLigne(ligne.id, {
                                photos: ligne.photos.filter((p) => p.id !== photo.id),
                              })
                            }
                            className="absolute -right-1.5 -top-1.5 flex h-7 w-7 items-center justify-center rounded-full border border-alfa-line bg-white text-alfa-slate shadow-panel"
                          >
                            <Trash2 aria-hidden="true" className="h-3.5 w-3.5" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}

                  <Champ
                    etiquette="Note interne (non visible par le client)"
                    value={ligne.noteInterne}
                    onChange={(e) => majLigne(ligne.id, { noteInterne: e.target.value })}
                    placeholder="Exemple : reliquat prevu a la prochaine vague."
                  />
                </div>
              ) : (
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-alfa-line pt-3">
                  {ligne.confirmee && <Statut ton="succes">Ligne confirmee</Statut>}
                  {ligne.manquant && <Statut ton="critique">Article manquant</Statut>}
                  {ligne.photos.length > 0 && (
                    <Statut ton="info">{ligne.photos.length} photo(s)</Statut>
                  )}
                  {ligne.noteInterne && (
                    <span className="text-sm text-alfa-slate">{ligne.noteInterne}</span>
                  )}
                </div>
              )}
            </li>
          );
        })}
      </ul>

      {/* ------------------------------------------------- Confirmation sortie */}
      <Modale
        ouverte={sortieOuverte}
        titre="Confirmer la sortie"
        description={`Preparation ${preparation.numero} — ${totalPrepare} unites`}
        onFermer={() => setSortieOuverte(false)}
        actions={
          <>
            <Bouton onClick={() => setSortieOuverte(false)}>Annuler</Bouton>
            <Bouton variante="principal" onClick={confirmer}>
              Confirmer et generer le bon
            </Bouton>
          </>
        }
      >
        <div className="space-y-4">
          <Message
            ton="attention"
            titre="Cette action est definitive."
            details={[
              'Le stock physique diminue et le materiel loue entre en circulation.',
              'Un retour arriere exige une ecriture compensatoire approuvee.',
            ]}
          />
          <Champ
            etiquette="Livreur"
            value={livreur}
            onChange={(e) => setLivreur(e.target.value)}
            placeholder="Camion 12 — R. Ouellet"
            aide="Obligatoire : le nom figure sur le bon de livraison."
          />
          <Champ
            etiquette="Representant Groupe Alfa"
            value={representant}
            onChange={(e) => setRepresentant(e.target.value)}
            placeholder="Melanie Dubois"
          />
          <Champ
            etiquette="Bon de commande client"
            value={bonCommande}
            onChange={(e) => setBonCommande(e.target.value)}
            placeholder="PO-2418"
          />
          <Champ
            etiquette="Duree de location (jours)"
            type="number"
            min={DUREE_LOCATION_MINIMALE_JOURS}
            value={jours}
            onChange={(e) => setJours(e.target.value)}
            aide={`Minimum ${DUREE_LOCATION_MINIMALE_JOURS} jours selon les conditions de location.`}
          />
        </div>
      </Modale>
    </Page>
  );
}
