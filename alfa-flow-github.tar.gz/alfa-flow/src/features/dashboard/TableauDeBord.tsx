import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  ClipboardList,
  Compass,
  PackageCheck,
  RotateCcw,
  ShieldQuestion,
  Truck,
} from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useIndicateurs, useReferentiel } from '../../state/selecteurs';
import { Bouton, Donnee, Page, Section, Statut } from '../../components/ui/primitives';
import { LIBELLE_MOUVEMENT } from '../../models/referentiel';
import { formatDate, formatDateHeure, formatNombre } from '../../utils';
import { quantiteSignee } from '../../services/stock';

/**
 * ECRAN 1 — tableau de bord.
 * Toutes les valeurs proviennent du registre des mouvements (section 14).
 * Aucune statistique n'est inventee : ce qui ne peut pas etre calcule n'est pas affiche.
 */
export function TableauDeBord() {
  const indicateurs = useIndicateurs();
  const reference = useReferentiel();
  const demarrerGuide = useBoutique((e) => e.demarrerGuide);
  const guideActif = useBoutique((e) => e.guideActif);

  const { agregat } = indicateurs;

  const aTraiter = [
    {
      libelle: 'Demandes a verifier',
      valeur: indicateurs.demandesAVerifier.length,
      lien: '/demandes',
      icone: ClipboardList,
    },
    {
      libelle: 'Preparations du jour',
      valeur: indicateurs.preparationsDuJour.length,
      lien: '/preparations',
      icone: PackageCheck,
    },
    {
      libelle: 'Sorties pretes',
      valeur: indicateurs.sortiesPretes.length,
      lien: '/preparations',
      icone: Truck,
    },
    {
      libelle: 'Bons non signes',
      valeur: indicateurs.bonsNonSignes.length,
      lien: '/livraisons',
      icone: Truck,
    },
    {
      libelle: 'Retours attendus',
      valeur: indicateurs.retoursAttendus.length,
      lien: '/locations',
      icone: RotateCcw,
    },
    {
      libelle: 'Retours en retard',
      valeur: indicateurs.retoursEnRetard.length,
      lien: '/locations',
      icone: AlertTriangle,
      critique: true,
    },
    {
      libelle: 'Ecarts non resolus',
      valeur: indicateurs.ecartsOuverts.length,
      lien: '/ecarts',
      icone: ShieldQuestion,
      critique: indicateurs.ecartsOuverts.length > 0,
    },
    {
      libelle: 'Articles sous le seuil',
      valeur: indicateurs.sousSeuil.length,
      lien: '/stock',
      icone: AlertTriangle,
      critique: indicateurs.sousSeuil.length > 0,
    },
  ];

  return (
    <Page
      titre="Tableau de bord"
      description="Etat des operations du jour. Chaque valeur est recalculee depuis le registre des mouvements."
      actions={
        !guideActif && (
          <Bouton
            variante="principal"
            onClick={demarrerGuide}
            icone={<Compass aria-hidden="true" className="h-4 w-4" />}
          >
            Lancer la demonstration guidee
          </Bouton>
        )
      }
    >
      {/* ------------------------------------------------ A traiter aujourd'hui */}
      <h2 className="mb-2 text-sm font-semibold text-alfa-ink">A traiter aujourd'hui</h2>
      <ul className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {aTraiter.map((element) => {
          const Icone = element.icone;
          return (
            <li key={element.libelle}>
              <Link
                to={element.lien}
                className="flex h-full flex-col justify-between gap-2 rounded-alfa border border-alfa-line p-3 transition-colors hover:border-alfa-slate hover:bg-alfa-surface"
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="text-xs text-alfa-slate">{element.libelle}</span>
                  <Icone
                    aria-hidden="true"
                    className={
                      element.critique && element.valeur > 0
                        ? 'h-4 w-4 flex-none text-alfa-red'
                        : 'h-4 w-4 flex-none text-alfa-muted'
                    }
                  />
                </span>
                <span
                  className={
                    element.critique && element.valeur > 0
                      ? 'text-2xl font-semibold tabular-nums text-alfa-red'
                      : 'text-2xl font-semibold tabular-nums text-alfa-ink'
                  }
                >
                  {element.valeur}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      {/* ------------------------------------------------------- Etat du parc */}
      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <Section titre="Repartition du stock theorique total" className="lg:col-span-2">
          <div className="p-4">
            <RepartitionStock agregat={agregat} />
            <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-alfa-line pt-4 sm:grid-cols-4">
              <Donnee terme="Stock disponible" valeur={formatNombre(agregat.disponible)} accent />
              <Donnee terme="Chez les clients" valeur={formatNombre(agregat.enCirculation)} accent />
              <Donnee terme="Stock physique" valeur={formatNombre(agregat.physique)} />
              <Donnee terme="Theorique total" valeur={formatNombre(agregat.theorique)} />
            </dl>
          </div>
        </Section>

        <Section titre="Actions prioritaires">
          {indicateurs.alertesNonResolues.length === 0 ? (
            <p className="px-4 py-6 text-sm text-alfa-slate">
              Aucune action prioritaire. Les dossiers en cours sont a jour.
            </p>
          ) : (
            <ul className="divide-y divide-alfa-line">
              {indicateurs.alertesNonResolues.slice(0, 6).map((alerte) => (
                <li key={alerte.id}>
                  <Link
                    to={alerte.lien}
                    className="flex items-start gap-2.5 px-4 py-2.5 hover:bg-alfa-surface"
                  >
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-1.5">
                        <Statut
                          ton={
                            alerte.severite === 'CRITIQUE'
                              ? 'critique'
                              : alerte.severite === 'ATTENTION'
                                ? 'attention'
                                : 'info'
                          }
                        >
                          {alerte.titre}
                        </Statut>
                      </span>
                      <span className="mt-1 block text-sm text-alfa-slate">{alerte.message}</span>
                    </span>
                    <ArrowRight aria-hidden="true" className="mt-1 h-4 w-4 flex-none text-alfa-muted" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
          <div className="border-t border-alfa-line px-4 py-2.5">
            <Link to="/alertes" className="text-sm font-medium text-alfa-redDark hover:underline">
              Voir toutes les alertes
            </Link>
          </div>
        </Section>
      </div>

      {/* -------------------------------------------------- Derniers mouvements */}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Section titre="Derniers mouvements de stock">
          <ul className="divide-y divide-alfa-line">
            {indicateurs.derniersMouvements.map((mouvement) => {
              const signe = quantiteSignee(mouvement);
              return (
                <li key={mouvement.id} className="flex items-start gap-3 px-4 py-2.5">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium text-alfa-ink">
                      {reference.nomProduit(mouvement.produitId)}
                    </span>
                    <span className="block text-xs text-alfa-muted">
                      {LIBELLE_MOUVEMENT[mouvement.type]} · {formatDateHeure(mouvement.dateHeure)}
                      {mouvement.documentRef ? ` · ${mouvement.documentRef}` : ''}
                    </span>
                  </span>
                  <span
                    className={
                      signe < 0
                        ? 'flex-none text-sm font-semibold tabular-nums text-alfa-redDark'
                        : signe > 0
                          ? 'flex-none text-sm font-semibold tabular-nums text-etat-succes'
                          : 'flex-none text-sm tabular-nums text-alfa-slate'
                    }
                  >
                    {signe > 0 ? '+' : ''}
                    {signe !== 0 ? signe : `(${mouvement.quantite})`}
                  </span>
                </li>
              );
            })}
          </ul>
        </Section>

        <Section titre="Locations en cours">
          {indicateurs.locationsActives.length === 0 ? (
            <p className="px-4 py-6 text-sm text-alfa-slate">Aucune location en cours.</p>
          ) : (
            <ul className="divide-y divide-alfa-line">
              {indicateurs.locationsActives.slice(0, 6).map((location) => (
                <li key={location.id}>
                  <Link
                    to={`/locations/${location.id}`}
                    className="flex items-center justify-between gap-3 px-4 py-2.5 hover:bg-alfa-surface"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-alfa-ink">
                        {location.numero} — {reference.nomClient(location.clientId)}
                      </span>
                      <span className="block truncate text-xs text-alfa-muted">
                        {reference.nomChantier(location.chantierId)} · retour attendu le{' '}
                        {formatDate(location.retourAttendu)}
                      </span>
                    </span>
                    <ArrowRight aria-hidden="true" className="h-4 w-4 flex-none text-alfa-muted" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Section>
      </div>
    </Page>
  );
}

/**
 * Un seul graphique, celui qui sert : la repartition du parc.
 * Barre empilee en SVG, sans dependance graphique, lisible en noir et blanc
 * grace au libelle chiffre de chaque segment (PERF-003).
 */
function RepartitionStock({
  agregat,
}: {
  agregat: {
    disponible: number;
    reserve: number;
    enPreparation: number;
    enCirculation: number;
    endommage: number;
    theorique: number;
  };
}) {
  const segments = [
    { libelle: 'Disponible', valeur: agregat.disponible, couleur: '#1B7F4B' },
    { libelle: 'Reserve et en preparation', valeur: agregat.reserve + agregat.enPreparation, couleur: '#1F5FA8' },
    { libelle: 'Chez les clients', valeur: agregat.enCirculation, couleur: '#B26A00' },
    { libelle: 'Quarantaine et litige', valeur: agregat.endommage, couleur: '#D2172A' },
  ];
  const total = segments.reduce((t, s) => t + s.valeur, 0) || 1;

  let position = 0;
  return (
    <div>
      <svg
        viewBox="0 0 100 6"
        preserveAspectRatio="none"
        className="h-6 w-full rounded-alfa"
        role="img"
        aria-label={segments
          .map((s) => `${s.libelle} : ${s.valeur} unites`)
          .join('. ')}
      >
        {segments.map((segment) => {
          const largeur = (segment.valeur / total) * 100;
          const x = position;
          position += largeur;
          return largeur > 0 ? (
            <rect key={segment.libelle} x={x} y={0} width={largeur} height={6} fill={segment.couleur} />
          ) : null;
        })}
      </svg>

      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5">
        {segments.map((segment) => (
          <li key={segment.libelle} className="flex items-center gap-1.5 text-sm">
            <span
              aria-hidden="true"
              className="h-2.5 w-2.5 flex-none rounded-sm"
              style={{ backgroundColor: segment.couleur }}
            />
            <span className="text-alfa-slate">{segment.libelle}</span>
            <span className="font-medium tabular-nums text-alfa-ink">
              {formatNombre(segment.valeur)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
