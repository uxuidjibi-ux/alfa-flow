import { describe, expect, it } from 'vitest';
import type { Mouvement, Produit } from '../models/types';
import {
  agregerStock,
  calculerStock,
  calculerStockProduit,
  produitsSousSeuil,
  quantiteSignee,
  simulerMouvements,
  verifierDisponibilite,
} from '../services/stock';

const produit: Produit = {
  id: 'p1',
  codeItem: '900001',
  sku: 'ALF-TEST-001',
  nom: 'Barre horizontale 2000',
  famille: 'Barres',
  sousFamille: 'Barre horizontale',
  dimensions: '2000',
  couleur: '',
  unite: 'unite',
  emplacement: 'Cour A - Rangee 1',
  seuilAlerte: 10,
  image: null,
  photoAValider: false,
  actif: true,
};

let sequence = 0;
function mvt(type: Mouvement['type'], quantite: number): Mouvement {
  sequence += 1;
  return {
    id: `m${sequence}`,
    produitId: 'p1',
    quantite,
    type,
    emplacementSource: null,
    emplacementDestination: null,
    clientId: null,
    chantierId: null,
    documentRef: null,
    utilisateurId: 'u_test',
    dateHeure: '2026-01-01T08:00:00.000Z',
    motif: null,
    appareil: 'Poste de test',
    mouvementLieId: null,
  };
}

describe('calcul du stock disponible', () => {
  it('applique la formule disponible = physique - reserve - preparation - endommage', () => {
    const mouvements = [
      mvt('STOCK_INITIAL', 100),
      mvt('RESERVATION', 20),
      mvt('PREPARATION', 5),
      mvt('QUARANTAINE', 3),
    ];
    const etat = calculerStockProduit('p1', mouvements);
    expect(etat.physique).toBe(100);
    expect(etat.reserve).toBe(15);
    expect(etat.enPreparation).toBe(5);
    expect(etat.endommage).toBe(3);
    expect(etat.disponible).toBe(100 - 15 - 5 - 3);
    expect(etat.theorique).toBe(100);
  });

  it('calcule le stock en circulation apres une sortie', () => {
    const etat = calculerStockProduit('p1', [
      mvt('STOCK_INITIAL', 50),
      mvt('RESERVATION', 20),
      mvt('PREPARATION', 20),
      mvt('SORTIE', 20),
    ]);
    expect(etat.physique).toBe(30);
    expect(etat.enCirculation).toBe(20);
    expect(etat.enPreparation).toBe(0);
    expect(etat.disponible).toBe(30);
    expect(etat.theorique).toBe(50);
  });

  it('expose une quantite signee coherente pour le registre', () => {
    expect(quantiteSignee(mvt('SORTIE', 12))).toBe(-12);
    expect(quantiteSignee(mvt('RETOUR_ACCEPTE', 12))).toBe(12);
    expect(quantiteSignee(mvt('RESERVATION', 12))).toBe(0);
  });

  it('sort le rebut du patrimoine et bloque l excedent en quarantaine', () => {
    const rebut = calculerStockProduit('p1', [
      mvt('STOCK_INITIAL', 20),
      mvt('QUARANTAINE', 5),
      mvt('REBUT', 5),
    ]);
    expect(rebut.physique).toBe(15);
    expect(rebut.endommage).toBe(0);
    expect(rebut.disponible).toBe(15);

    const excedent = calculerStockProduit('p1', [mvt('STOCK_INITIAL', 10), mvt('EXCEDENT_QUARANTAINE', 6)]);
    expect(excedent.physique).toBe(16);
    expect(excedent.endommage).toBe(6);
    expect(excedent.disponible).toBe(10);
  });

  it('agrege et detecte les articles sous le seuil', () => {
    const etats = calculerStock([produit], [mvt('STOCK_INITIAL', 12), mvt('RESERVATION', 8)]);
    expect(agregerStock(etats).disponible).toBe(4);
    expect(produitsSousSeuil([produit], etats)).toHaveLength(1);
  });
});

describe('refus des operations impossibles', () => {
  it('refuse une reservation superieure au disponible avec un message explicite', () => {
    const etats = calculerStock([produit], [mvt('STOCK_INITIAL', 10)]);
    const resultat = verifierDisponibilite(
      [{ produitId: 'p1', nom: produit.nom, quantite: 12 }],
      etats,
    );
    expect(resultat.ok).toBe(false);
    expect(resultat.details?.[0]).toContain('12 unite(s) demandee(s)');
    expect(resultat.details?.[0]).toContain('10 unite(s) sont disponibles');
  });

  it('empeche la generation silencieuse d un stock negatif', () => {
    const existants = [mvt('STOCK_INITIAL', 5)];
    const resultat = simulerMouvements(
      existants,
      [mvt('RESERVATION', 5), mvt('PREPARATION', 5), mvt('SORTIE', 8)],
      [produit],
    );
    expect(resultat.ok).toBe(false);
    expect(resultat.message).toContain('stock negatif');
  });

  it('accepte une sequence coherente', () => {
    const resultat = simulerMouvements(
      [mvt('STOCK_INITIAL', 20)],
      [mvt('RESERVATION', 6), mvt('PREPARATION', 6), mvt('SORTIE', 6)],
      [produit],
    );
    expect(resultat.ok).toBe(true);
    expect(resultat.valeur?.get('p1')?.enCirculation).toBe(6);
  });
});
