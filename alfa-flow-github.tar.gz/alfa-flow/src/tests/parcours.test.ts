import { beforeEach, describe, expect, it } from 'vitest';
import type { EtatDonnees } from '../models/types';
import { construireEtatInitial } from '../data/demo';
import { calculerStock, calculerStockProduit } from '../services/stock';
import { deriverAlertes } from '../services/alertes';
import { peut } from '../models/referentiel';
import { DepotMemoire } from '../services/persistance';
import type { PhotoRef } from '../models/types';
import {
  ajusterStock,
  cloturerRetour,
  approuverDemande,
  changerStatutSortie,
  confirmerSortie,
  controlerPreparation,
  demarrerRetour,
  majLignePreparation,
  majLigneRetour,
  marquerPreparationPrete,
  quantiteRestante,
  validerRetour,
} from '../services/operations';

const ctx = { utilisateurId: 'u_cour', appareil: 'Tablette de test' };

function photo(id: string, categorie: PhotoRef['categorie'] = 'AVANT_DEPART'): PhotoRef {
  return {
    id,
    cle: 'demo',
    legende: 'Photo',
    dateHeure: '2026-01-01T09:00:00.000Z',
    categorie,
    utilisateurId: 'u_cour',
    version: 1,
    remplacePhotoId: null,
  };
}

function preparerToutesLesLignes(etat: EtatDonnees, preparationId: string): EtatDonnees {
  let courant = etat;
  const preparation = courant.preparations.find((p) => p.id === preparationId)!;
  for (const ligne of preparation.lignes) {
    const resultat = majLignePreparation(courant, preparationId, ligne.id, {
      quantitePreparee: ligne.quantiteConfirmee,
      confirmee: true,
      photos: [photo(`ph_${ligne.id}`)],
    });
    expect(resultat.ok).toBe(true);
    courant = resultat.valeur!;
  }
  return courant;
}

describe('donnees de demonstration', () => {
  const etat = construireEtatInitial();

  it('produit un catalogue et un registre coherents', () => {
    expect(etat.produits.length).toBeGreaterThan(100);
    expect(new Set(etat.produits.map((p) => p.id)).size).toBe(etat.produits.length);
    expect(new Set(etat.produits.map((p) => p.sku)).size).toBe(etat.produits.length);
  });

  it('ne genere aucun compartiment negatif', () => {
    for (const stock of calculerStock(etat.produits, etat.mouvements).values()) {
      expect(stock.physique).toBeGreaterThanOrEqual(0);
      expect(stock.reserve).toBeGreaterThanOrEqual(0);
      expect(stock.enCirculation).toBeGreaterThanOrEqual(0);
      expect(stock.disponible).toBeGreaterThanOrEqual(0);
    }
  });

  it('fournit les dossiers attendus par la demonstration', () => {
    expect(etat.clients).toHaveLength(4);
    expect(etat.chantiers).toHaveLength(6);
    expect(etat.locations.filter((l) => l.statut !== 'CLOTUREE').length).toBeGreaterThanOrEqual(3);
    expect(etat.retours.length).toBeGreaterThanOrEqual(2);
    expect(etat.ecarts.some((e) => e.type === 'MANQUANT')).toBe(true);
    expect(etat.ecarts.some((e) => e.type === 'ENDOMMAGE')).toBe(true);
    expect(deriverAlertes(etat, calculerStock(etat.produits, etat.mouvements)).length).toBeGreaterThan(3);
  });

  it('ne cree jamais deux alertes pour le meme evenement', () => {
    const alertes = deriverAlertes(etat, calculerStock(etat.produits, etat.mouvements));
    expect(new Set(alertes.map((a) => a.id)).size).toBe(alertes.length);
  });
});

describe('parcours complet demande -> retour -> ecart', () => {
  let etat: EtatDonnees;

  beforeEach(() => {
    etat = construireEtatInitial();
  });

  it('refuse une approbation superieure au stock disponible', () => {
    const demande = etat.demandes.find((d) => d.statut === 'A_VERIFIER')!;
    const quantites = Object.fromEntries(demande.lignes.map((l) => [l.id, l.quantiteDemandee]));
    const resultat = approuverDemande(etat, demande.id, quantites, ctx);
    expect(resultat.ok).toBe(false);
    expect(resultat.details?.[0]).toMatch(/disponible/);
  });

  it('approuve une quantite reduite et reserve le stock', () => {
    const demande = etat.demandes.find((d) => d.statut === 'A_VERIFIER')!;
    const quantites = Object.fromEntries(demande.lignes.map((l) => [l.id, 5]));
    const resultat = approuverDemande(etat, demande.id, quantites, ctx);
    expect(resultat.ok).toBe(true);
    const apres = resultat.valeur!;
    const produitId = demande.lignes[0].produitId;
    const avantReserve = calculerStockProduit(produitId, etat.mouvements).reserve;
    expect(calculerStockProduit(produitId, apres.mouvements).reserve).toBe(avantReserve + 5);
  });

  it('bloque le controle final quand une ligne n est pas traitee', () => {
    const preparation = etat.preparations.find((p) => p.statut === 'A_PREPARER')!;
    const controle = controlerPreparation(etat, preparation.id);
    expect(controle.ok).toBe(false);
    expect(controle.details?.join(' ')).toContain('non traitee');
  });

  it('refuse une quantite preparee superieure a la quantite approuvee', () => {
    const preparation = etat.preparations.find((p) => p.statut === 'A_PREPARER')!;
    const ligne = preparation.lignes[0];
    const maj = majLignePreparation(etat, preparation.id, ligne.id, {
      quantitePreparee: ligne.quantiteConfirmee + 2,
      confirmee: true,
      photos: [photo('ph')],
    });
    const controle = controlerPreparation(maj.valeur!, preparation.id);
    expect(controle.ok).toBe(false);
    expect(controle.details?.join(' ')).toContain('ont ete approuvees');
  });

  it('accepte une preparation partielle justifiee', () => {
    const preparation = etat.preparations.find((p) => p.statut === 'A_PREPARER')!;
    let courant = etat;
    for (const ligne of preparation.lignes) {
      courant = majLignePreparation(courant, preparation.id, ligne.id, {
        quantitePreparee: Math.max(1, ligne.quantiteConfirmee - 3),
        noteInterne: 'Reliquat prevu a la prochaine vague.',
        confirmee: true,
        photos: [photo(`p_${ligne.id}`)],
      }).valeur!;
    }
    expect(controlerPreparation(courant, preparation.id).ok).toBe(true);
    const prete = marquerPreparationPrete(courant, preparation.id, ctx);
    expect(prete.ok).toBe(true);
  });

  it('deroule sortie, bon de livraison, retour partiel, ecart et mise a jour du stock', () => {
    const preparation = etat.preparations.find((p) => p.statut === 'A_PREPARER')!;
    const produitId = preparation.lignes[0].produitId;
    const quantiteLigne = preparation.lignes[0].quantiteConfirmee;
    const stockAvant = calculerStockProduit(produitId, etat.mouvements);

    let courant = preparerToutesLesLignes(etat, preparation.id);
    courant = marquerPreparationPrete(courant, preparation.id, ctx).valeur!;

    const sortie = confirmerSortie(
      courant,
      preparation.id,
      { livreur: 'Camion 12', signataireNom: 'Sophie Nadeau', joursLocation: 14 },
      ctx,
    );
    expect(sortie.ok).toBe(true);
    courant = sortie.valeur!;

    const bon = courant.sorties[courant.sorties.length - 1];
    const location = courant.locations[courant.locations.length - 1];
    // QV-004 : la numerotation poursuit la sequence papier existante (L-18203...).
    expect(bon.numero).toMatch(/^L-\d{5}$/);
    expect(Number(bon.numero.slice(2))).toBeGreaterThan(18203);
    expect(bon.lignes[0].quantiteCommandee).toBe(quantiteLigne);
    expect(bon.lignes[0].quantiteAVenir).toBe(0);
    expect(bon.termes).toContain('Net 30');
    expect(location.lignes[0].quantiteSortie).toBe(quantiteLigne);

    const apresSortie = calculerStockProduit(produitId, courant.mouvements);
    expect(apresSortie.physique).toBe(stockAvant.physique - quantiteLigne);
    expect(apresSortie.enCirculation).toBe(stockAvant.enCirculation + quantiteLigne);

    // Transition invalide refusee.
    const transition = changerStatutSortie(courant, bon.id, 'SIGNEE', ctx);
    expect(transition.ok).toBe(false);
    expect(transition.message).toContain('Transition refusee');

    // Premier retour partiel.
    courant = demarrerRetour(courant, location.id, ctx).valeur!;
    const retour = courant.retours[courant.retours.length - 1];
    const ligneRetour = retour.lignes[0];
    const sansPhoto = majLigneRetour(courant, retour.id, ligneRetour.id, {
      quantiteAcceptee: ligneRetour.quantiteAttendue - 5,
      quantiteEndommagee: 2,
      quantiteManquante: 3,
    });
    expect(sansPhoto.ok).toBe(true);
    courant = sansPhoto.valeur!;
    expect(validerRetour(courant, retour.id, ctx).ok).toBe(false);

    courant = majLigneRetour(courant, retour.id, ligneRetour.id, {
      photos: [photo('preuve_dommage', 'DOMMAGE')],
    }).valeur!;

    const surQualification = majLigneRetour(courant, retour.id, ligneRetour.id, {
      quantiteAcceptee: ligneRetour.quantiteAttendue + 1,
      quantiteEndommagee: 2,
      quantiteManquante: 3,
    });
    expect(surQualification.ok).toBe(false);
    expect(surQualification.message).toContain('excedent recu');

    const nombreEcartsAvant = courant.ecarts.length;
    courant = validerRetour(courant, retour.id, ctx).valeur!;

    const locationApres = courant.locations.find((l) => l.id === location.id)!;
    expect(locationApres.statut).toBe('RETOUR_PARTIEL');
    expect(courant.ecarts.length).toBe(nombreEcartsAvant + 2);
    expect(quantiteRestante(locationApres.lignes[0])).toBe(0);

    const apresRetour = calculerStockProduit(produitId, courant.mouvements);
    expect(apresRetour.endommage).toBe(apresSortie.endommage + 2);
    expect(apresRetour.physique).toBe(apresSortie.physique + quantiteLigne - 5 + 2);

    // Deuxieme retour sur la meme sortie : le reliquat des autres lignes.
    const second = demarrerRetour(courant, location.id, ctx);
    expect(second.ok).toBe(true);
    courant = second.valeur!;
    const retour2 = courant.retours[courant.retours.length - 1];
    expect(retour2.lignes.every((l) => l.quantiteAttendue > 0)).toBe(true);
    for (const ligne of retour2.lignes) {
      courant = majLigneRetour(courant, retour2.id, ligne.id, {
        quantiteAcceptee: ligne.quantiteAttendue,
      }).valeur!;
    }
    courant = validerRetour(courant, retour2.id, ctx).valeur!;
    const locationFinale = courant.locations.find((l) => l.id === location.id)!;
    expect(locationFinale.statut).toBe('CLOTUREE');

    // RG-040 : la cloture est refusee tant qu'un ecart attend une decision.
    const premierRetour = courant.retours.find((r) => r.id === retour.id)!;
    expect(premierRetour.statut).toBe('ECART_DETECTE');
    const clotureRefusee = cloturerRetour(courant, retour.id, ctx);
    expect(clotureRefusee.ok).toBe(false);
    expect(clotureRefusee.details?.length).toBeGreaterThan(0);
  });

  it('distingue une ligne vendue d une ligne louee sur un meme bon', () => {
    // Un bon Groupe Alfa peut mêler location et achat (bon papier L-18203).
    const preparation = etat.preparations.find((p) => p.statut === 'A_PREPARER')!;
    const ligneAchat = preparation.lignes.find((l) => l.typeItem === 'ACHAT')!;
    const ligneLocation = preparation.lignes.find((l) => l.typeItem === 'LOCATION')!;
    expect(ligneAchat).toBeTruthy();

    const avantAchat = calculerStockProduit(ligneAchat.produitId, etat.mouvements);

    let courant = preparerToutesLesLignes(etat, preparation.id);
    courant = marquerPreparationPrete(courant, preparation.id, ctx).valeur!;
    courant = confirmerSortie(
      courant,
      preparation.id,
      { livreur: 'Camion 12', signataireNom: 'Sophie Nadeau', joursLocation: 14 },
      ctx,
    ).valeur!;

    const bon = courant.sorties[courant.sorties.length - 1];
    const location = courant.locations[courant.locations.length - 1];

    // Le bon porte les deux types de lignes.
    expect(bon.lignes.some((l) => l.typeItem === 'ACHAT')).toBe(true);
    expect(bon.lignes.some((l) => l.typeItem === 'LOCATION')).toBe(true);

    // La quantite vendue quitte le parc sans entrer en circulation.
    const apresAchat = calculerStockProduit(ligneAchat.produitId, courant.mouvements);
    expect(apresAchat.physique).toBe(avantAchat.physique - ligneAchat.quantiteConfirmee);
    expect(apresAchat.enCirculation).toBe(avantAchat.enCirculation);

    // La location ne suit que les lignes louees : aucun retour n'est attendu sur l'achat.
    expect(location.lignes.some((l) => l.produitId === ligneAchat.produitId)).toBe(false);
    expect(location.lignes.some((l) => l.produitId === ligneLocation.produitId)).toBe(true);

    courant = demarrerRetour(courant, location.id, ctx).valeur!;
    const retour = courant.retours[courant.retours.length - 1];
    expect(retour.lignes.some((l) => l.produitId === ligneAchat.produitId)).toBe(false);
  });

  it('exige un motif pour tout ajustement et trace la valeur avant / apres', () => {
    const produitId = etat.produits[0].id;
    const avant = calculerStockProduit(produitId, etat.mouvements).physique;
    expect(ajusterStock(etat, produitId, avant - 4, '', ctx).ok).toBe(false);

    const resultat = ajusterStock(etat, produitId, avant - 4, 'Inventaire tournant du 12 mai', ctx);
    expect(resultat.ok).toBe(true);
    const journal = resultat.valeur!.journal[0];
    expect(journal.valeurAvant).toBe(String(avant));
    expect(journal.valeurApres).toBe(String(avant - 4));
    expect(journal.motif).toContain('Inventaire tournant');
    expect(calculerStockProduit(produitId, resultat.valeur!.mouvements).physique).toBe(avant - 4);
  });
});

describe('permissions par role', () => {
  it('limite les actions selon le role selectionne', () => {
    expect(peut('COUR', 'preparation.executer')).toBe(true);
    expect(peut('COUR', 'demande.approuver')).toBe(false);
    expect(peut('SECRETARIAT', 'demande.creer')).toBe(true);
    expect(peut('SECRETARIAT', 'preparation.executer')).toBe(false);
    expect(peut('DIRECTION', 'ecart.decider')).toBe(true);
    expect(peut('DIRECTION', 'preparation.executer')).toBe(false);
    expect(peut('ADMIN', 'admin.gerer')).toBe(true);
  });
});

describe('persistance et reinitialisation', () => {
  it('recharge l etat enregistre puis revient a l etat initial apres effacement', async () => {
    const depot = new DepotMemoire();
    const initial = construireEtatInitial();
    const modifie: EtatDonnees = { ...initial, demandes: initial.demandes.slice(0, 1) };

    await depot.enregistrer(modifie);
    const recharge = await depot.charger();
    expect(recharge?.demandes).toHaveLength(1);

    await depot.effacer();
    expect(await depot.charger()).toBeNull();
    expect(construireEtatInitial().demandes.length).toBe(initial.demandes.length);
  });
});
