import { useMemo } from 'react';
import type { EtatDonnees, EtatStock, Permission } from '../models/types';
import { calculerStock, agregerStock, produitsSousSeuil } from '../services/stock';
import { deriverAlertes } from '../services/alertes';
import { quantiteRestante } from '../services/operations';
import { peut } from '../models/referentiel';
import { aujourdHui, contient, ecartJours, somme } from '../utils';
import { useBoutique } from './store';

/**
 * Tout ce qui est affiche est recalcule depuis le registre (DATA-001).
 * Aucun solde n'est lu dans un champ stocke.
 */

export function useStocks(): Map<string, EtatStock> {
  const donnees = useBoutique((e) => e.donnees);
  return useMemo(
    () => calculerStock(donnees.produits, donnees.mouvements),
    [donnees.produits, donnees.mouvements],
  );
}

export function useStockProduit(produitId: string): EtatStock | undefined {
  return useStocks().get(produitId);
}

export function useAlertes() {
  const donnees = useBoutique((e) => e.donnees);
  const stocks = useStocks();
  return useMemo(() => {
    const alertes = deriverAlertes(donnees, stocks);
    return alertes.map((alerte) => ({
      ...alerte,
      acquittee: donnees.etatsAlertes[alerte.id]?.acquittee ?? false,
      resolue: donnees.etatsAlertes[alerte.id]?.resolue ?? false,
    }));
  }, [donnees, stocks]);
}

export function useDroit(permission: Permission): boolean {
  const role = useBoutique((e) => e.roleActif);
  return peut(role, permission);
}

/** Indicateurs du tableau de bord (section 14.1). */
export function useIndicateurs() {
  const donnees = useBoutique((e) => e.donnees);
  const stocks = useStocks();
  const alertes = useAlertes();

  return useMemo(() => {
    const date = aujourdHui();
    const agregat = agregerStock(stocks);

    const demandesAVerifier = donnees.demandes.filter(
      (d) => d.statut === 'A_VERIFIER' || d.statut === 'SOUMISE',
    );
    const preparationsDuJour = donnees.preparations.filter((p) => p.statut !== 'PRETE');
    const preparationsIncompletes = donnees.preparations.filter(
      (p) => p.statut === 'PARTIELLEMENT_PREPAREE' || p.statut === 'BLOQUEE',
    );
    const sortiesPretes = donnees.preparations.filter((p) => p.statut === 'PRETE');
    const locationsActives = donnees.locations.filter((l) => l.statut !== 'CLOTUREE');
    const retoursEnRetard = locationsActives.filter(
      (l) => ecartJours(l.retourAttendu, date) < 0 && somme(l.lignes, quantiteRestante) > 0,
    );
    const retoursAttendus = locationsActives.filter((l) => {
      const jours = ecartJours(l.retourAttendu, date);
      return jours >= 0 && jours <= 7;
    });
    const bonsNonSignes = donnees.sorties.filter(
      (s) => s.statut === 'LIVREE' || s.statut === 'SIGNATURE_EN_ATTENTE',
    );
    const ecartsOuverts = donnees.ecarts.filter(
      (e) => e.decision !== 'RESOLU' && e.decision !== 'ABANDONNE',
    );
    const ageMoyenEcarts =
      ecartsOuverts.length === 0
        ? 0
        : Math.round(
            somme(ecartsOuverts, (e) => Math.abs(ecartJours(date, e.dateCreation.slice(0, 10)))) /
              ecartsOuverts.length,
          );

    return {
      agregat,
      demandesAVerifier,
      preparationsDuJour,
      preparationsIncompletes,
      sortiesPretes,
      locationsActives,
      retoursAttendus,
      retoursEnRetard,
      bonsNonSignes,
      ecartsOuverts,
      ageMoyenEcarts,
      sousSeuil: produitsSousSeuil(donnees.produits, stocks),
      alertesNonResolues: alertes.filter((a) => !a.resolue),
      derniersMouvements: [...donnees.mouvements]
        .sort((a, b) => b.dateHeure.localeCompare(a.dateHeure))
        .slice(0, 8),
    };
  }, [donnees, stocks, alertes]);
}

/* --------------------------------------------------- Recherche globale */

export interface ResultatRecherche {
  type: 'Article' | 'Client' | 'Chantier' | 'Demande' | 'Preparation' | 'Bon' | 'Location';
  titre: string;
  sousTitre: string;
  lien: string;
}

export function chercherPartout(donnees: EtatDonnees, requete: string): ResultatRecherche[] {
  if (requete.trim().length < 2) return [];
  const resultats: ResultatRecherche[] = [];

  for (const produit of donnees.produits) {
    if (
      contient(
        `${produit.nom} ${produit.sku} ${produit.codeItem} ${produit.famille} ${produit.dimensions} ${produit.couleur}`,
        requete,
      )
    ) {
      resultats.push({
        type: 'Article',
        titre: produit.nom,
        sousTitre: `${produit.codeItem} · ${produit.famille}`,
        lien: `/catalogue/${produit.id}`,
      });
    }
  }

  for (const client of donnees.clients) {
    if (contient(`${client.nom} ${client.code} ${client.ville}`, requete)) {
      resultats.push({
        type: 'Client',
        titre: client.nom,
        sousTitre: `${client.code} · ${client.ville}`,
        lien: `/clients/${client.id}`,
      });
    }
  }

  for (const chantier of donnees.chantiers) {
    if (contient(`${chantier.nom} ${chantier.code} ${chantier.ville}`, requete)) {
      const client = donnees.clients.find((c) => c.id === chantier.clientId);
      resultats.push({
        type: 'Chantier',
        titre: chantier.nom,
        sousTitre: `${chantier.code} · ${client?.nom ?? ''}`,
        lien: `/clients/${chantier.clientId}`,
      });
    }
  }

  for (const demande of donnees.demandes) {
    if (contient(demande.numero, requete)) {
      resultats.push({
        type: 'Demande',
        titre: demande.numero,
        sousTitre: donnees.clients.find((c) => c.id === demande.clientId)?.nom ?? '',
        lien: `/demandes/${demande.id}`,
      });
    }
  }

  for (const preparation of donnees.preparations) {
    if (contient(preparation.numero, requete)) {
      resultats.push({
        type: 'Preparation',
        titre: preparation.numero,
        sousTitre: `Statut : ${preparation.statut}`,
        lien: `/preparations/${preparation.id}`,
      });
    }
  }

  for (const sortie of donnees.sorties) {
    if (contient(`${sortie.numero} ${sortie.signataireNom} ${sortie.representant}`, requete)) {
      resultats.push({
        type: 'Bon',
        titre: sortie.numero,
        sousTitre: donnees.clients.find((c) => c.id === sortie.clientId)?.nom ?? '',
        lien: `/livraisons/${sortie.id}`,
      });
    }
  }

  for (const location of donnees.locations) {
    if (contient(location.numero, requete)) {
      resultats.push({
        type: 'Location',
        titre: location.numero,
        sousTitre: donnees.clients.find((c) => c.id === location.clientId)?.nom ?? '',
        lien: `/locations/${location.id}`,
      });
    }
  }

  return resultats.slice(0, 12);
}

export function useRechercheGlobale(requete: string): ResultatRecherche[] {
  const donnees = useBoutique((e) => e.donnees);
  return useMemo(() => chercherPartout(donnees, requete), [donnees, requete]);
}

/* ------------------------------------------------------- Aides d'affichage */

export function useReferentiel() {
  const donnees = useBoutique((e) => e.donnees);
  return useMemo(
    () => ({
      produit: (id: string) => donnees.produits.find((p) => p.id === id),
      client: (id: string) => donnees.clients.find((c) => c.id === id),
      chantier: (id: string) => donnees.chantiers.find((c) => c.id === id),
      contact: (id: string | null) => donnees.contacts.find((c) => c.id === id),
      utilisateur: (id: string) => donnees.utilisateurs.find((u) => u.id === id),
      demande: (id: string) => donnees.demandes.find((d) => d.id === id),
      nomProduit: (id: string) => donnees.produits.find((p) => p.id === id)?.nom ?? id,
      nomClient: (id: string) => donnees.clients.find((c) => c.id === id)?.nom ?? '—',
      nomChantier: (id: string) => donnees.chantiers.find((c) => c.id === id)?.nom ?? '—',
      nomUtilisateur: (id: string) => donnees.utilisateurs.find((u) => u.id === id)?.nom ?? '—',
    }),
    [donnees],
  );
}
