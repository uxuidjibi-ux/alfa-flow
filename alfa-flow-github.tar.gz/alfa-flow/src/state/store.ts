import { create } from 'zustand';
import type { EtatDonnees, ResultatRegle, Role, Utilisateur } from '../models/types';
import { construireEtatInitial } from '../data/demo';
import { depotDonnees, depotPhotos } from '../services/persistance';

export interface Message {
  id: string;
  type: 'succes' | 'erreur' | 'info';
  texte: string;
  details?: string[];
}

export interface EtapeGuide {
  titre: string;
  texte: string;
  chemin: string;
  action: string;
}

/** Scenario « Demonstration client » : 8 a 10 minutes, du besoin au rapprochement. */
export const ETAPES_GUIDE: EtapeGuide[] = [
  {
    titre: '1. Le besoin arrive au secretariat',
    texte:
      'Le client appelle : il lui faut des barres pour son chantier. Ouvrez la demande du jour et verifiez les quantites approuvees.',
    chemin: '/demandes',
    action: 'Ouvrir la demande DEM du chantier Entrepot Logipro',
  },
  {
    titre: '2. Verifier la disponibilite reelle',
    texte:
      'Le catalogue affiche le disponible, le reserve, ce qui est en preparation et ce qui est deja chez les clients. Aucune promesse n est faite sur du stock inexistant.',
    chemin: '/catalogue',
    action: 'Rechercher « barre horizontale » et ouvrir une fiche article',
  },
  {
    titre: '3. Preparer dans la cour',
    texte:
      'Passez en role « Responsable de cour ». Sur tablette, saisissez les quantites, ajoutez une photo, confirmez chaque ligne.',
    chemin: '/preparations',
    action: 'Ouvrir la preparation a faire et confirmer les lignes',
  },
  {
    titre: '4. Controle final et sortie',
    texte:
      'Le systeme bloque toute sortie incoherente et explique pourquoi. Une fois le controle passe, confirmez la sortie.',
    chemin: '/preparations',
    action: 'Declarer la preparation prete puis confirmer la sortie',
  },
  {
    titre: '5. Bon de livraison et signature',
    texte:
      'Le bon PDF est genere avec le numero unique, les articles et l espace de signature. Le lien client simule permet de confirmer la reception.',
    chemin: '/livraisons',
    action: 'Ouvrir le bon, telecharger le PDF, ouvrir le lien client',
  },
  {
    titre: '6. Suivre le materiel chez le client',
    texte:
      'La location devient active : quantites sorties, retour attendu, niveau d alerte. Rien ne se perd entre la cour et la facturation.',
    chemin: '/locations',
    action: 'Ouvrir la location creee',
  },
  {
    titre: '7. Retour partiel et rapprochement',
    texte:
      'Le client renvoie une partie du materiel. Saisissez ce qui est accepte, endommage ou manquant : l ecart est calcule avant toute decision.',
    chemin: '/retours',
    action: 'Demarrer un retour et enregistrer les quantites',
  },
  {
    titre: '8. Ecarts, stock et tableau de bord',
    texte:
      'Les ecarts partent en decision, le materiel endommage passe en quarantaine, les stocks et les indicateurs sont recalcules immediatement.',
    chemin: '/',
    action: 'Revenir au tableau de bord et constater la mise a jour',
  },
];

interface Boutique {
  donnees: EtatDonnees;
  pret: boolean;
  roleActif: Role;
  messages: Message[];
  guideActif: boolean;
  etapeGuide: number;
  barreReduite: boolean;
  profilChoisi: boolean;

  initialiser: () => Promise<void>;
  utilisateurActif: () => Utilisateur;
  changerRole: (role: Role) => void;
  choisirProfil: (role: Role) => void;
  changerProfil: () => void;
  basculerBarre: () => void;
  appliquer: (resultat: ResultatRegle<EtatDonnees>, messageSucces: string) => boolean;
  modifier: (transformation: (donnees: EtatDonnees) => EtatDonnees) => void;
  reinitialiser: () => Promise<void>;
  notifier: (type: Message['type'], texte: string, details?: string[]) => void;
  fermerMessage: (id: string) => void;
  marquerAlerte: (id: string, champ: 'acquittee' | 'resolue', valeur: boolean) => void;
  demarrerGuide: () => void;
  allerEtape: (index: number) => void;
  quitterGuide: () => void;
}

let compteurMessage = 0;

/**
 * Le role de demonstration et l'etat de la barre laterale survivent a une
 * actualisation : sans cela, une demonstration interrompue reprend au mauvais role.
 */
const CLE_PREFERENCES = 'alfa-flow.preferences.v1';

interface Preferences {
  roleActif: Role;
  barreReduite: boolean;
  /** Le profil a-t-il deja ete choisi sur cet appareil ? */
  profilChoisi: boolean;
}

function lirePreferences(): Preferences {
  const defaut: Preferences = { roleActif: 'SECRETARIAT', barreReduite: false, profilChoisi: false };
  try {
    const brut = window.localStorage.getItem(CLE_PREFERENCES);
    if (!brut) return defaut;
    return { ...defaut, ...(JSON.parse(brut) as Partial<Preferences>) };
  } catch {
    return defaut;
  }
}

function ecrirePreferences(preferences: Preferences): void {
  try {
    window.localStorage.setItem(CLE_PREFERENCES, JSON.stringify(preferences));
  } catch {
    /* stockage indisponible : la demonstration reste utilisable */
  }
}

async function persister(donnees: EtatDonnees) {
  await depotDonnees.enregistrer(donnees);
}

export const useBoutique = create<Boutique>((set, get) => ({
  donnees: construireEtatInitial(),
  pret: false,
  roleActif: lirePreferences().roleActif,
  messages: [],
  guideActif: false,
  etapeGuide: 0,
  barreReduite: lirePreferences().barreReduite,
  profilChoisi: lirePreferences().profilChoisi,

  async initialiser() {
    const enregistre = await depotDonnees.charger();
    set({ donnees: enregistre ?? construireEtatInitial(), pret: true });
    if (!enregistre) await persister(get().donnees);
  },

  utilisateurActif() {
    const { donnees, roleActif } = get();
    return (
      donnees.utilisateurs.find((u) => u.role === roleActif) ?? donnees.utilisateurs[0]
    );
  },

  changerRole(role) {
    set({ roleActif: role });
    ecrirePreferences({
      roleActif: role,
      barreReduite: get().barreReduite,
      profilChoisi: get().profilChoisi,
    });
  },

  /** Entree dans l'application apres selection du profil. */
  choisirProfil(role) {
    set({ roleActif: role, profilChoisi: true });
    ecrirePreferences({ roleActif: role, barreReduite: get().barreReduite, profilChoisi: true });
  },

  /** Retour a l'ecran de choix, sans effacer les donnees. */
  changerProfil() {
    set({ profilChoisi: false, guideActif: false });
    ecrirePreferences({
      roleActif: get().roleActif,
      barreReduite: get().barreReduite,
      profilChoisi: false,
    });
  },

  basculerBarre() {
    const barreReduite = !get().barreReduite;
    set({ barreReduite });
    ecrirePreferences({
      roleActif: get().roleActif,
      barreReduite,
      profilChoisi: get().profilChoisi,
    });
  },

  appliquer(resultat, messageSucces) {
    if (!resultat.ok || !resultat.valeur) {
      get().notifier('erreur', resultat.message ?? 'Operation refusee.', resultat.details);
      return false;
    }
    set({ donnees: resultat.valeur });
    void persister(resultat.valeur);
    if (messageSucces) get().notifier('succes', messageSucces);
    return true;
  },

  modifier(transformation) {
    const donnees = transformation(get().donnees);
    set({ donnees });
    void persister(donnees);
  },

  async reinitialiser() {
    await depotDonnees.effacer();
    await depotPhotos.vider();
    const donnees = construireEtatInitial();
    set({ donnees, guideActif: false, etapeGuide: 0 });
    await persister(donnees);
    get().notifier('succes', 'Donnees de demonstration reinitialisees.');
  },

  notifier(type, texte, details) {
    compteurMessage += 1;
    const message: Message = { id: `msg_${compteurMessage}`, type, texte, details };
    set((etat) => ({ messages: [...etat.messages, message] }));
    if (type !== 'erreur') {
      setTimeout(() => get().fermerMessage(message.id), 4500);
    }
  },

  fermerMessage(id) {
    set((etat) => ({ messages: etat.messages.filter((m) => m.id !== id) }));
  },

  marquerAlerte(id, champ, valeur) {
    get().modifier((donnees) => ({
      ...donnees,
      etatsAlertes: {
        ...donnees.etatsAlertes,
        [id]: {
          acquittee: donnees.etatsAlertes[id]?.acquittee ?? false,
          resolue: donnees.etatsAlertes[id]?.resolue ?? false,
          [champ]: valeur,
        },
      },
    }));
  },

  demarrerGuide() {
    set({ guideActif: true, etapeGuide: 0 });
  },

  allerEtape(index) {
    set({ etapeGuide: Math.max(0, Math.min(ETAPES_GUIDE.length - 1, index)) });
  },

  quitterGuide() {
    set({ guideActif: false });
  },
}));
