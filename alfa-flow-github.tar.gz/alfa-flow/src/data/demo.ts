/**
 * Donnees de demonstration ALFA Flow.
 *
 * IMPORTANT : clients, chantiers, contacts et dossiers sont FICTIFS et servent
 * uniquement a la demonstration commerciale. Le catalogue provient de
 * « LISTE PRODUIT.pdf » et ne constitue pas l'inventaire definitif de Groupe Alfa.
 *
 * Tout le registre de mouvements est DERIVE des dossiers ci-dessous : les
 * quantites affichees sur chaque ecran sont donc coherentes par construction.
 */
import type {
  Chantier,
  Client,
  Contact,
  Demande,
  Ecart,
  EtatDonnees,
  Location,
  Mouvement,
  PhotoRef,
  Preparation,
  Retour,
  Sortie,
  Utilisateur,
} from '../models/types';
import { PRODUITS } from './produits';
import { DERNIER_BON_PAPIER, PREFIXE_BON, TERMES_DEFAUT } from '../models/referentiel';
import { jourPlus } from '../utils';

/* ---------------------------------------------------------- Utilisateurs */

export const UTILISATEURS: Utilisateur[] = [
  { id: 'u_admin', nom: 'Sylvain Cote', role: 'ADMIN', fonction: 'Administrateur principal', actif: true },
  { id: 'u_cour', nom: 'Patrick Lemieux', role: 'COUR', fonction: 'Responsable de cour', actif: true },
  { id: 'u_secr', nom: 'Julie Tremblay', role: 'SECRETARIAT', fonction: 'Secretariat', actif: true },
  { id: 'u_dir', nom: 'Nadia Bergeron', role: 'DIRECTION', fonction: 'Direction des operations', actif: true },
  { id: 'u_cour2', nom: 'Ahmed Belkacem', role: 'COUR', fonction: 'Preparateur', actif: true },
];

/* --------------------------------------------------- Clients et chantiers */

export const CLIENTS: Client[] = [
  {
    id: 'cl_1',
    code: 'CLI-001',
    nom: 'Constructions Rivard inc. (demo)',
    ville: 'Trois-Rivieres',
    telephone: '819 555-0142',
    courriel: 'projets@rivard-demo.ca',
    notes: 'Client de demonstration. Facturation mensuelle.',
  },
  {
    id: 'cl_2',
    code: 'CLI-002',
    nom: 'Evenements Saint-Laurent (demo)',
    ville: 'Montreal',
    telephone: '514 555-0198',
    courriel: 'logistique@esl-demo.ca',
    notes: 'Client de demonstration. Montages evenementiels courts.',
  },
  {
    id: 'cl_3',
    code: 'CLI-003',
    nom: 'Batiment Nord-Ouest ltee (demo)',
    ville: 'Becancour',
    telephone: '819 555-0177',
    courriel: 'achats@bno-demo.ca',
    notes: 'Client de demonstration. Chantiers longue duree.',
  },
  {
    id: 'cl_4',
    code: 'CLI-004',
    nom: 'Scene et Structure Quebec (demo)',
    ville: 'Quebec',
    telephone: '418 555-0163',
    courriel: 'operations@ssq-demo.ca',
    notes: 'Client de demonstration. Gradins et scenes.',
  },
];

export const CONTACTS: Contact[] = [
  { id: 'ct_1', clientId: 'cl_1', nom: 'Martin Rivard', fonction: 'Surintendant', courriel: 'm.rivard@rivard-demo.ca', telephone: '819 555-0143', signataire: true },
  { id: 'ct_2', clientId: 'cl_1', nom: 'Chantal Gauthier', fonction: 'Coordonnatrice', courriel: 'c.gauthier@rivard-demo.ca', telephone: '819 555-0144', signataire: false },
  { id: 'ct_3', clientId: 'cl_2', nom: 'Louis Perron', fonction: 'Chef de site', courriel: 'l.perron@esl-demo.ca', telephone: '514 555-0199', signataire: true },
  { id: 'ct_4', clientId: 'cl_3', nom: 'Sophie Nadeau', fonction: 'Chargee de projet', courriel: 's.nadeau@bno-demo.ca', telephone: '819 555-0178', signataire: true },
  { id: 'ct_5', clientId: 'cl_3', nom: 'Eric Dufresne', fonction: 'Contremaitre', courriel: 'e.dufresne@bno-demo.ca', telephone: '819 555-0179', signataire: true },
  { id: 'ct_6', clientId: 'cl_4', nom: 'Karine Simard', fonction: 'Directrice technique', courriel: 'k.simard@ssq-demo.ca', telephone: '418 555-0164', signataire: true },
];

export const CHANTIERS: Chantier[] = [
  { id: 'ch_1', clientId: 'cl_1', code: 'CH-101', nom: 'Residence Les Terrasses', adresse: '1450 rue Notre-Dame', ville: 'Trois-Rivieres', contactId: 'ct_1', actif: true },
  { id: 'ch_2', clientId: 'cl_1', code: 'CH-102', nom: 'Viaduc boulevard des Forges', adresse: '3200 boul. des Forges', ville: 'Trois-Rivieres', contactId: 'ct_2', actif: true },
  { id: 'ch_3', clientId: 'cl_2', code: 'CH-201', nom: 'Scene du Port', adresse: '333 rue de la Commune', ville: 'Montreal', contactId: 'ct_3', actif: true },
  { id: 'ch_4', clientId: 'cl_3', code: 'CH-301', nom: 'Entrepot Logipro', adresse: '75 rue Industrielle', ville: 'Becancour', contactId: 'ct_4', actif: true },
  { id: 'ch_5', clientId: 'cl_3', code: 'CH-302', nom: 'Tour Grande-Allee', adresse: '1080 Grande Allee Ouest', ville: 'Quebec', contactId: 'ct_5', actif: true },
  { id: 'ch_6', clientId: 'cl_4', code: 'CH-401', nom: 'Gradins Amphitheatre', adresse: '1600 rue Saint-Roch', ville: 'Quebec', contactId: 'ct_6', actif: true },
];

/* ----------------------------------------------------------- Scenarios */

interface LigneScenario {
  produitId: string;
  /** Location par defaut ; « ACHAT » pour les consommables vendus fermes. */
  type?: 'LOCATION' | 'ACHAT';
  demandee: number;
  approuvee?: number;
  preparee?: number;
  /** Retour deja enregistre (dossiers historiques). */
  acceptee?: number;
  endommagee?: number;
  manquante?: number;
}

interface Scenario {
  ref: string;
  /** Representant Groupe Alfa au dossier (colonne « Representant » du bon). */
  representant: string;
  clientId: string;
  chantierId: string;
  contactId: string;
  creeParId: string;
  statutDemande: Demande['statut'];
  dateSouhaitee: string;
  notes: string;
  lignes: LigneScenario[];
  preparation?: {
    statut: Preparation['statut'];
    assigneAId: string;
    photos?: boolean;
  };
  sortie?: {
    statut: Sortie['statut'];
    livreur: string;
    signataire: string;
    joursEcoules: number;
    dureeLocation: number;
    signe: boolean;
  };
  retour?: { joursEcoules: number; notes: string };
}

const J = (n: number) => jourPlus(n);

/**
 * Quelques articles sont volontairement en stock bas pour illustrer les alertes
 * de seuil et le refus d'une reservation superieure au disponible.
 */
export const STOCK_BAS: Record<string, number> = {
  prod_012: 60,
  prod_047: 22,
  prod_148: 44,
  prod_197: 70,
};

export const SCENARIOS: Scenario[] = [
  {
    ref: '001',
    representant: 'Melanie Dubois',
    clientId: 'cl_1',
    chantierId: 'ch_1',
    contactId: 'ct_1',
    creeParId: 'u_secr',
    statutDemande: 'APPROUVEE',
    dateSouhaitee: J(-12),
    notes: 'Montage de la facade nord. Livraison a la barriere de chantier.',
    lignes: [
      { produitId: 'prod_005', demandee: 60, approuvee: 60, preparee: 60 },
      { produitId: 'prod_027', demandee: 24, approuvee: 24, preparee: 24 },
      { produitId: 'prod_126', demandee: 40, approuvee: 40, preparee: 40 },
      { produitId: 'prod_148', demandee: 30, approuvee: 30, preparee: 30 },
      { produitId: 'prod_045', type: 'ACHAT', demandee: 16, approuvee: 16, preparee: 16 },
    ],
    preparation: { statut: 'PRETE', assigneAId: 'u_cour', photos: true },
    sortie: { statut: 'SIGNEE', livreur: 'Camion 12 — R. Ouellet', signataire: 'Martin Rivard', joursEcoules: 12, dureeLocation: 21, signe: true },
  },
  {
    ref: '002',
    representant: 'Melanie Dubois',
    clientId: 'cl_2',
    chantierId: 'ch_3',
    contactId: 'ct_3',
    creeParId: 'u_secr',
    statutDemande: 'APPROUVEE',
    dateSouhaitee: J(-18),
    notes: 'Montage de scene. Retour prevu apres l evenement.',
    lignes: [
      { produitId: 'prod_006', demandee: 48, approuvee: 48, preparee: 48, acceptee: 30, endommagee: 2, manquante: 4 },
      { produitId: 'prod_028', demandee: 20, approuvee: 20, preparee: 20, acceptee: 14 },
      { produitId: 'prod_123', demandee: 24, approuvee: 24, preparee: 24, acceptee: 24 },
      { produitId: 'prod_043', type: 'ACHAT', demandee: 30, approuvee: 30, preparee: 30 },
    ],
    preparation: { statut: 'PRETE', assigneAId: 'u_cour2', photos: true },
    sortie: { statut: 'SIGNEE', livreur: 'Camion 08 — S. Michaud', signataire: 'Louis Perron', joursEcoules: 18, dureeLocation: 14, signe: true },
    retour: { joursEcoules: 3, notes: 'Retour partiel apres demontage. Deux barres tordues, quatre non retrouvees.' },
  },
  {
    ref: '003',
    representant: 'Karim Haddad',
    clientId: 'cl_1',
    chantierId: 'ch_2',
    contactId: 'ct_2',
    creeParId: 'u_secr',
    statutDemande: 'APPROUVEE',
    dateSouhaitee: J(-30),
    notes: 'Passerelle sous viaduc. Acces limite entre 9 h et 15 h.',
    lignes: [
      { produitId: 'prod_015', demandee: 36, approuvee: 36, preparee: 36, acceptee: 20, manquante: 3 },
      { produitId: 'prod_047', demandee: 18, approuvee: 18, preparee: 18, acceptee: 18 },
      { produitId: 'prod_221', demandee: 40, approuvee: 40, preparee: 40, acceptee: 40 },
    ],
    preparation: { statut: 'PRETE', assigneAId: 'u_cour', photos: true },
    sortie: { statut: 'SIGNEE', livreur: 'Camion 12 — R. Ouellet', signataire: 'Chantal Gauthier', joursEcoules: 30, dureeLocation: 40, signe: true },
    retour: { joursEcoules: 6, notes: 'Recuperation partielle. Trois barres de 10 pieds introuvables sur le site.' },
  },
  {
    ref: '004',
    representant: 'Melanie Dubois',
    clientId: 'cl_3',
    chantierId: 'ch_4',
    contactId: 'ct_4',
    creeParId: 'u_secr',
    statutDemande: 'APPROUVEE',
    dateSouhaitee: J(0),
    notes: 'Demande du jour — a preparer pour livraison en fin de journee.',
    lignes: [
      { produitId: 'prod_004', demandee: 40, approuvee: 40 },
      { produitId: 'prod_012', demandee: 24, approuvee: 24 },
      { produitId: 'prod_197', demandee: 60, approuvee: 60 },
      { produitId: 'prod_043', type: 'ACHAT', demandee: 45, approuvee: 45 },
    ],
    preparation: { statut: 'A_PREPARER', assigneAId: 'u_cour' },
  },
  {
    ref: '007',
    representant: 'Karim Haddad',
    clientId: 'cl_4',
    chantierId: 'ch_6',
    contactId: 'ct_6',
    creeParId: 'u_secr',
    statutDemande: 'APPROUVEE',
    dateSouhaitee: J(-26),
    notes: 'Gradins temporaires — dossier complet, materiel entierement retourne.',
    lignes: [
      { produitId: 'prod_148', demandee: 12, approuvee: 12, preparee: 12, acceptee: 12 },
      { produitId: 'prod_221', demandee: 25, approuvee: 25, preparee: 25, acceptee: 25 },
    ],
    preparation: { statut: 'PRETE', assigneAId: 'u_cour2', photos: true },
    sortie: { statut: 'SIGNEE', livreur: 'Camion 08 — S. Michaud', signataire: 'Karine Simard', joursEcoules: 26, dureeLocation: 20, signe: true },
    retour: { joursEcoules: 4, notes: 'Retour complet, materiel conforme.' },
  },
  {
    ref: '005',
    representant: 'Karim Haddad',
    clientId: 'cl_3',
    chantierId: 'ch_5',
    contactId: 'ct_5',
    creeParId: 'u_secr',
    statutDemande: 'A_VERIFIER',
    dateSouhaitee: J(2),
    notes: 'Quantites a valider avec la direction avant approbation.',
    lignes: [
      { produitId: 'prod_014', demandee: 400 },
      { produitId: 'prod_007', demandee: 30 },
    ],
  },
  {
    ref: '006',
    representant: 'Melanie Dubois',
    clientId: 'cl_4',
    chantierId: 'ch_6',
    contactId: 'ct_6',
    creeParId: 'u_secr',
    statutDemande: 'BROUILLON',
    dateSouhaitee: J(6),
    notes: 'Brouillon en cours de saisie pour le montage des gradins.',
    lignes: [{ produitId: 'prod_134', demandee: 32 }],
  },
];

/* ------------------------------------------------- Construction de l'etat */

let sequence = 0;
const uid = (prefixe: string) => `${prefixe}_seed_${(sequence += 1)}`;

function horodatage(joursEcoules: number, heure = 9): string {
  return `${jourPlus(-joursEcoules)}T${String(heure).padStart(2, '0')}:15:00.000Z`;
}

function photoDemo(
  cle: string,
  legende: string,
  joursEcoules: number,
  categorie: PhotoRef['categorie'],
  utilisateurId: string,
): PhotoRef {
  return {
    id: uid('photo'),
    cle,
    legende,
    dateHeure: horodatage(joursEcoules, 10),
    categorie,
    utilisateurId,
    version: 1,
    remplacePhotoId: null,
  };
}

export function construireEtatInitial(): EtatDonnees {
  sequence = 0;
  const mouvements: Mouvement[] = [];
  const demandes: Demande[] = [];
  const preparations: Preparation[] = [];
  const sorties: Sortie[] = [];
  const locations: Location[] = [];
  const retours: Retour[] = [];
  const ecarts: Ecart[] = [];
  const journal: EtatDonnees['journal'] = [];
  const compteurs: Record<string, number> = {};
  const annee = new Date().getFullYear();

  const numero = (prefixe: string, valeur: number) => {
    compteurs[`${prefixe}-${annee}`] = valeur;
    return `${prefixe}-${annee}-${String(valeur).padStart(3, '0')}`;
  };

  /** Les bons poursuivent la sequence papier existante (dernier observe : L-18203). */
  const numeroBonLivraison = (rang: number) => {
    const valeur = DERNIER_BON_PAPIER + rang;
    compteurs[PREFIXE_BON] = valeur;
    return `${PREFIXE_BON}-${valeur}`;
  };

  const ajouterMouvement = (m: Omit<Mouvement, 'id' | 'appareil' | 'mouvementLieId'>) => {
    mouvements.push({ ...m, id: uid('mvt'), appareil: 'Poste de demonstration', mouvementLieId: null });
  };

  // 1. Inventaire initial.
  for (const produit of PRODUITS) {
    ajouterMouvement({
      produitId: produit.id,
      quantite: STOCK_BAS[produit.id] ?? produit.quantiteInitiale,
      type: 'STOCK_INITIAL',
      emplacementSource: null,
      emplacementDestination: produit.emplacement,
      clientId: null,
      chantierId: null,
      documentRef: 'Inventaire initial de demonstration',
      utilisateurId: 'u_admin',
      dateHeure: horodatage(45, 7),
      motif: 'Chargement du catalogue de demonstration',
    });
  }

  // 2. Dossiers.
  SCENARIOS.forEach((scenario, index) => {
    const numeroDemande = numero('DEM', index + 1);
    const demandeId = uid('dem');
    const lignesDemande = scenario.lignes.map((ligne) => ({
      id: uid('ldem'),
      produitId: ligne.produitId,
      typeItem: ligne.type ?? ('LOCATION' as const),
      quantiteDemandee: ligne.demandee,
      quantiteApprouvee: ligne.approuvee ?? null,
      note: '',
    }));

    demandes.push({
      id: demandeId,
      numero: numeroDemande,
      clientId: scenario.clientId,
      chantierId: scenario.chantierId,
      contactId: scenario.contactId,
      dateSouhaitee: scenario.dateSouhaitee,
      dateCreation: horodatage(index + 4, 8),
      statut: scenario.statutDemande,
      lignes: lignesDemande,
      notes: scenario.notes,
      piecesJointes: [],
      creeParId: scenario.creeParId,
    });

    journal.push({
      id: uid('log'),
      utilisateurId: scenario.creeParId,
      action: 'Creation de la demande',
      dateHeure: horodatage(index + 4, 8),
      entiteType: 'demande',
      entiteId: numeroDemande,
      valeurAvant: null,
      valeurApres: 'BROUILLON',
      motif: null,
      appareil: 'Poste secretariat',
    });

    // Reservation a l'approbation.
    if (scenario.statutDemande === 'APPROUVEE') {
      for (const ligne of scenario.lignes) {
        ajouterMouvement({
          produitId: ligne.produitId,
          quantite: ligne.approuvee ?? ligne.demandee,
          type: 'RESERVATION',
          emplacementSource: null,
          emplacementDestination: null,
          clientId: scenario.clientId,
          chantierId: scenario.chantierId,
          documentRef: numeroDemande,
          utilisateurId: 'u_secr',
          dateHeure: horodatage(index + 3, 9),
          motif: 'Reservation a l approbation de la demande',
        });
      }
      journal.push({
        id: uid('log'),
        utilisateurId: 'u_secr',
        action: 'Approbation de la demande et reservation du stock',
        dateHeure: horodatage(index + 3, 9),
        entiteType: 'demande',
        entiteId: numeroDemande,
        valeurAvant: 'A_VERIFIER',
        valeurApres: 'APPROUVEE',
        motif: null,
        appareil: 'Poste secretariat',
      });
    }

    if (!scenario.preparation) return;

    const numeroPreparation = numero('PREP', preparations.length + 1);
    const preparationId = uid('prep');
    const lignesPreparation = scenario.lignes.map((ligne, i) => ({
      id: uid('lprep'),
      ligneDemandeId: lignesDemande[i].id,
      produitId: ligne.produitId,
      typeItem: ligne.type ?? ('LOCATION' as const),
      quantiteConfirmee: ligne.approuvee ?? ligne.demandee,
      quantitePreparee: ligne.preparee ?? 0,
      photos:
        scenario.preparation?.photos && (ligne.preparee ?? 0) > 0
          ? [
              photoDemo(
                PRODUITS.find((p) => p.id === ligne.produitId)?.image ?? '',
                'Photo de preparation avant depart',
                index + 2,
                'AVANT_DEPART',
                scenario.preparation.assigneAId,
              ),
            ]
          : [],
      noteInterne: '',
      manquant: false,
      substitutionProduitId: null,
      substitutionMotif: '',
      confirmee: (ligne.preparee ?? 0) > 0,
    }));

    preparations.push({
      id: preparationId,
      numero: numeroPreparation,
      demandeId,
      statut: scenario.preparation.statut,
      assigneAId: scenario.preparation.assigneAId,
      vague: 1,
      dateCreation: horodatage(index + 2, 8),
      lignes: lignesPreparation,
      notes: '',
    });

    if (scenario.preparation.statut === 'PRETE') {
      for (const ligne of scenario.lignes) {
        if (!ligne.preparee) continue;
        ajouterMouvement({
          produitId: ligne.produitId,
          quantite: ligne.preparee,
          type: 'PREPARATION',
          emplacementSource: PRODUITS.find((p) => p.id === ligne.produitId)?.emplacement ?? null,
          emplacementDestination: 'Zone de preparation',
          clientId: scenario.clientId,
          chantierId: scenario.chantierId,
          documentRef: numeroPreparation,
          utilisateurId: scenario.preparation.assigneAId,
          dateHeure: horodatage(index + 2, 10),
          motif: null,
        });
      }
    }

    if (!scenario.sortie) return;

    const numeroBon = numeroBonLivraison(sorties.length + 1);
    const sortieId = uid('sortie');
    const lignesSortie = scenario.lignes
      .filter((l) => (l.preparee ?? 0) > 0)
      .map((l) => {
        const commandee = l.approuvee ?? l.demandee;
        const expediee = l.preparee ?? 0;
        return {
          id: uid('lsortie'),
          produitId: l.produitId,
          typeItem: l.type ?? ('LOCATION' as const),
          quantiteCommandee: commandee,
          quantite: expediee,
          quantiteAVenir: Math.max(0, commandee - expediee),
          note: '',
        };
      });

    sorties.push({
      id: sortieId,
      numero: numeroBon,
      version: 1,
      preparationId,
      demandeId,
      clientId: scenario.clientId,
      chantierId: scenario.chantierId,
      statut: scenario.sortie.statut,
      lignes: lignesSortie,
      dateSortie: horodatage(scenario.sortie.joursEcoules, 11),
      preparateurId: scenario.preparation.assigneAId,
      livreur: scenario.sortie.livreur,
      bonCommandeClient: `PO-${2400 + index * 7}`,
      commandeAlfa: String(329400 + index * 11),
      representant: scenario.representant,
      expedieVia: 'Camion Groupe Alfa',
      termes: TERMES_DEFAUT,
      expedieA: '',
      heureArrivee: '07:45',
      heureCommencee: '08:00',
      heureTerminee: '09:20',
      representantSignatureNom: scenario.representant,
      representantSignatureDataUrl: null,
      signataireNom: scenario.sortie.signataire,
      signataireLettresMoulees: scenario.sortie.signataire.toUpperCase(),
      signatureDataUrl: null,
      dateSignature: scenario.sortie.signe ? horodatage(scenario.sortie.joursEcoules, 15) : null,
      photoDocumentSigne: null,
      receptionClient: [],
      jetonPublic: `demo${index + 1}${scenario.ref}`,
      envoiSimule: true,
    });

    for (const ligne of lignesSortie) {
      ajouterMouvement({
        produitId: ligne.produitId,
        quantite: ligne.quantite,
        type: ligne.typeItem === 'ACHAT' ? 'VENTE' : 'SORTIE',
        emplacementSource: 'Zone de preparation',
        emplacementDestination: ligne.typeItem === 'ACHAT' ? null : 'Sur le chantier',
        clientId: scenario.clientId,
        chantierId: scenario.chantierId,
        documentRef: numeroBon,
        utilisateurId: scenario.preparation.assigneAId,
        dateHeure: horodatage(scenario.sortie.joursEcoules, 11),
        motif: null,
      });
    }

    journal.push({
      id: uid('log'),
      utilisateurId: scenario.preparation.assigneAId,
      action: `Sortie confirmee et bon de livraison ${numeroBon} genere`,
      dateHeure: horodatage(scenario.sortie.joursEcoules, 11),
      entiteType: 'sortie',
      entiteId: numeroBon,
      valeurAvant: 'PRETE_A_SORTIR',
      valeurApres: 'SORTIE_CONFIRMEE',
      motif: null,
      appareil: 'Tablette de cour',
    });

    // Location.
    const numeroLocation = numero('LOC', locations.length + 1);
    const locationId = uid('loc');
    const lignesLocation = lignesSortie
      .filter((ls) => ls.typeItem === 'LOCATION')
      .map((ls) => {
      const source = scenario.lignes.find((l) => l.produitId === ls.produitId);
      return {
        id: uid('lloc'),
        produitId: ls.produitId,
        quantiteSortie: ls.quantite,
        quantiteRetournee: source?.acceptee ?? 0,
        quantiteEndommagee: source?.endommagee ?? 0,
        quantiteManquante: source?.manquante ?? 0,
        quantiteContestee: 0,
      };
    });

    const retourAttendu = jourPlus(-scenario.sortie.joursEcoules + scenario.sortie.dureeLocation);
    const reste = lignesLocation.reduce(
      (t, l) => t + l.quantiteSortie - l.quantiteRetournee - l.quantiteEndommagee - l.quantiteManquante,
      0,
    );
    const enRetard = new Date(retourAttendu) < new Date(jourPlus(0));
    const statutLocation: Location['statut'] = scenario.retour
      ? reste === 0
        ? 'CLOTUREE'
        : enRetard
          ? 'EN_RETARD'
          : 'RETOUR_PARTIEL'
      : enRetard
        ? 'EN_RETARD'
        : 'ACTIVE';

    locations.push({
      id: locationId,
      numero: numeroLocation,
      sortieId,
      clientId: scenario.clientId,
      chantierId: scenario.chantierId,
      dateSortie: jourPlus(-scenario.sortie.joursEcoules),
      retourAttendu,
      statut: statutLocation,
      lignes: lignesLocation,
    });

    if (!scenario.retour) return;

    // Retour deja rapproche.
    const numeroRetour = numero('RET', retours.length + 1);
    const retourId = uid('ret');
    const lignesRetour = scenario.lignes
      .filter((l) => (l.preparee ?? 0) > 0 && (l.type ?? 'LOCATION') === 'LOCATION')
      .map((l, i) => {
        const acceptee = l.acceptee ?? 0;
        const endommagee = l.endommagee ?? 0;
        const manquante = l.manquante ?? 0;
        return {
          id: uid('lret'),
          produitId: l.produitId,
          ligneLocationId: lignesLocation[i].id,
          quantiteAttendue: l.preparee ?? 0,
          quantiteRecue: acceptee + endommagee,
          quantiteAcceptee: acceptee,
          quantiteEndommagee: endommagee,
          quantiteManquante: manquante,
          quantiteContestee: 0,
          quantiteExcedent: 0,
          etat: endommagee > 0 ? ('ENDOMMAGE' as const) : ('BON' as const),
          photos:
            endommagee > 0 || manquante > 0
              ? [
                  photoDemo(
                    PRODUITS.find((p) => p.id === l.produitId)?.image ?? '',
                    endommagee > 0 ? 'Constat de dommage' : 'Constat d article manquant',
                    scenario.retour?.joursEcoules ?? 1,
                    endommagee > 0 ? 'DOMMAGE' : 'ARTICLE_MANQUANT',
                    'u_cour',
                  ),
                ]
              : [],
          commentaire: endommagee > 0 ? 'Extremites tordues, materiel place en quarantaine.' : '',
        };
      });

    retours.push({
      id: retourId,
      numero: numeroRetour,
      locationId,
      date: jourPlus(-scenario.retour.joursEcoules),
      statut: 'CLOTURE',
      lignes: lignesRetour,
      receptionnaireId: 'u_cour',
      notes: scenario.retour.notes,
    });

    for (const ligne of lignesRetour) {
      const commun = {
        emplacementSource: 'Sur le chantier',
        clientId: scenario.clientId,
        chantierId: scenario.chantierId,
        documentRef: numeroRetour,
        utilisateurId: 'u_cour',
        dateHeure: horodatage(scenario.retour.joursEcoules, 14),
      };
      if (ligne.quantiteAcceptee > 0) {
        ajouterMouvement({
          ...commun,
          produitId: ligne.produitId,
          quantite: ligne.quantiteAcceptee,
          type: 'RETOUR_ACCEPTE',
          emplacementDestination: PRODUITS.find((p) => p.id === ligne.produitId)?.emplacement ?? null,
          motif: 'Retour accepte en bon etat',
        });
      }
      if (ligne.quantiteEndommagee > 0) {
        ajouterMouvement({
          ...commun,
          produitId: ligne.produitId,
          quantite: ligne.quantiteEndommagee,
          type: 'DOMMAGE',
          emplacementDestination: 'Quarantaine',
          motif: 'Retour endommage mis en quarantaine',
        });
      }
      if (ligne.quantiteManquante > 0) {
        ajouterMouvement({
          ...commun,
          produitId: ligne.produitId,
          quantite: ligne.quantiteManquante,
          type: 'PERTE',
          emplacementDestination: null,
          motif: 'Quantite declaree manquante au retour',
        });
      }
    }

    journal.push({
      id: uid('log'),
      utilisateurId: 'u_cour',
      action: 'Retour valide',
      dateHeure: horodatage(scenario.retour.joursEcoules, 14),
      entiteType: 'retour',
      entiteId: numeroRetour,
      valeurAvant: 'COMPTAGE',
      valeurApres: 'CLOTURE',
      motif: null,
      appareil: 'Tablette de cour',
    });

    // Ecarts issus du rapprochement.
    for (const ligne of lignesRetour) {
      const creer = (quantite: number, type: Ecart['type']) => {
        if (quantite <= 0) return;
        const numeroEcart = numero('ECA', ecarts.length + 1);
        ecarts.push({
          id: uid('ecart'),
          numero: numeroEcart,
          retourId,
          locationId,
          clientId: scenario.clientId,
          chantierId: scenario.chantierId,
          produitId: ligne.produitId,
          quantite,
          type,
          photos: ligne.photos,
          responsableId: 'u_cour',
          decision: 'A_VERIFIER',
          motif: '',
          dateCreation: horodatage(scenario.retour?.joursEcoules ?? 1, 14),
          dateDecision: null,
        });
      };
      creer(ligne.quantiteManquante, 'MANQUANT');
      creer(ligne.quantiteEndommagee, 'ENDOMMAGE');
    }
  });

  return {
    produits: PRODUITS.map(({ quantiteInitiale: _quantiteInitiale, ...produit }) => produit),
    mouvements: mouvements.sort((a, b) => a.dateHeure.localeCompare(b.dateHeure)),
    clients: CLIENTS,
    contacts: CONTACTS,
    chantiers: CHANTIERS,
    utilisateurs: UTILISATEURS,
    demandes,
    preparations,
    sorties,
    locations,
    retours,
    ecarts,
    journal: journal.sort((a, b) => b.dateHeure.localeCompare(a.dateHeure)),
    etatsAlertes: {},
    compteurs,
  };
}
