import { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { useBoutique } from '../state/store';
import { Layout } from '../components/layout/Layout';
import { Chargement } from '../components/ui/primitives';
import { TableauDeBord } from '../features/dashboard/TableauDeBord';
import { Catalogue } from '../features/catalog/Catalogue';
import { FicheProduit } from '../features/catalog/FicheProduit';
import { Clients, FicheClient } from '../features/clients/Clients';
import { Demandes, FicheDemande } from '../features/requests/Demandes';
import { AssistantDemande } from '../features/requests/AssistantDemande';
import { FichePreparation, Preparations } from '../features/preparations/Preparations';
import { FicheLivraison, Livraisons } from '../features/deliveries/Livraisons';
import { FicheLocation, Locations } from '../features/rentals/Locations';
import { FicheRetour, Retours } from '../features/returns/Retours';
import { Alertes, Ecarts, Stock } from '../features/alerts/Ecarts';
import { Administration, Rapports } from '../features/reports/Rapports';
import { BonPublic } from '../features/public/BonPublic';
import { ChoixProfil } from '../features/auth/ChoixProfil';

/**
 * Routage de l'application.
 * La page publique du bon est volontairement hors de la mise en page
 * d'administration : aucun menu, aucun selecteur de role (ECRAN 7).
 */
/** Reconnait le lien client, que le routage soit par chemin ou par ancre. */
function estPageClient(): boolean {
  return (
    window.location.hash.startsWith('#/bon/') || window.location.pathname.startsWith('/bon/')
  );
}

export function App() {
  const initialiser = useBoutique((e) => e.initialiser);
  const pret = useBoutique((e) => e.pret);
  const profilChoisi = useBoutique((e) => e.profilChoisi);

  /**
   * La page client par lien reste accessible sans choix de profil.
   * L'adresse est surveillee : sans cela, un lien ouvert alors que l'ecran de
   * choix est affiche ne declencherait aucun rendu.
   */
  const [pageClient, setPageClient] = useState(estPageClient);
  useEffect(() => {
    const surChangement = () => setPageClient(estPageClient());
    window.addEventListener('hashchange', surChangement);
    window.addEventListener('popstate', surChangement);
    return () => {
      window.removeEventListener('hashchange', surChangement);
      window.removeEventListener('popstate', surChangement);
    };
  }, []);

  useEffect(() => {
    void initialiser();
  }, [initialiser]);

  if (!pret) return <Chargement texte="Chargement des donnees de demonstration" />;
  if (!profilChoisi && !pageClient) return <ChoixProfil />;

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/bon/:jeton" element={<BonPublic />} />

        <Route element={<Layout />}>
          <Route index element={<TableauDeBord />} />
          <Route path="catalogue" element={<Catalogue />} />
          <Route path="catalogue/:produitId" element={<FicheProduit />} />
          <Route path="clients" element={<Clients />} />
          <Route path="clients/:clientId" element={<FicheClient />} />
          <Route path="demandes" element={<Demandes />} />
          <Route path="demandes/nouvelle" element={<AssistantDemande />} />
          <Route path="demandes/:demandeId" element={<FicheDemande />} />
          <Route path="preparations" element={<Preparations />} />
          <Route path="preparations/:preparationId" element={<FichePreparation />} />
          <Route path="livraisons" element={<Livraisons />} />
          <Route path="livraisons/:sortieId" element={<FicheLivraison />} />
          <Route path="locations" element={<Locations />} />
          <Route path="locations/:locationId" element={<FicheLocation />} />
          <Route path="retours" element={<Retours />} />
          <Route path="retours/:retourId" element={<FicheRetour />} />
          <Route path="ecarts" element={<Ecarts />} />
          <Route path="alertes" element={<Alertes />} />
          <Route path="stock" element={<Stock />} />
          <Route path="rapports" element={<Rapports />} />
          <Route path="administration" element={<Administration />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
