import type {
  Demande,
  Ecart,
  EtatDonnees,
  LignePreparation,
  Location,
  Mouvement,
  Preparation,
  Retour,
  ResultatRegle,
  Sortie,
  StatutSortie,
  TypeMouvement,
} from '../models/types';
import {
  DERNIER_BON_PAPIER,
  DUREE_LOCATION_MINIMALE_JOURS,
  PREFIXE_BON,
  TERMES_DEFAUT,
  TRANSITIONS_SORTIE,
} from '../models/referentiel';
import { calculerStock, simulerMouvements, verifierDisponibilite } from './stock';
import {
  aujourdHui,
  id,
  jetonDemo,
  jourPlus,
  maintenant,
  numeroSequentiel,
  numeroSuivant,
  somme,
} from '../utils';

/* ------------------------------------------------------------- Fabriques */

export interface ContexteOperation {
  utilisateurId: string;
  /** SEC-011 : appareil ayant produit l'ecriture. */
  appareil?: string;
}

function mouvement(
  partiel: Pick<Mouvement, 'produitId' | 'quantite' | 'type'> & Partial<Mouvement>,
  ctx: ContexteOperation,
): Mouvement {
  return {
    id: id('mvt'),
    emplacementSource: null,
    emplacementDestination: null,
    clientId: null,
    chantierId: null,
    documentRef: null,
    motif: null,
    appareil: ctx.appareil ?? 'Navigateur',
    mouvementLieId: null,
    utilisateurId: ctx.utilisateurId,
    dateHeure: maintenant(),
    ...partiel,
  };
}

function journaliser(
  etat: EtatDonnees,
  entree: {
    action: string;
    entiteType: string;
    entiteId: string;
    valeurAvant?: string | null;
    valeurApres?: string | null;
    motif?: string | null;
  },
  ctx: ContexteOperation,
): EtatDonnees['journal'] {
  return [
    {
      id: id('log'),
      utilisateurId: ctx.utilisateurId,
      dateHeure: maintenant(),
      valeurAvant: entree.valeurAvant ?? null,
      valeurApres: entree.valeurApres ?? null,
      motif: entree.motif ?? null,
      appareil: ctx.appareil ?? 'Navigateur',
      action: entree.action,
      entiteType: entree.entiteType,
      entiteId: entree.entiteId,
    },
    ...etat.journal,
  ];
}

const echec = (message: string, details?: string[]): ResultatRegle<EtatDonnees> => ({
  ok: false,
  message,
  details,
});

/* -------------------------------------------------------------- Demandes */

export function soumettreDemande(
  etat: EtatDonnees,
  demandeId: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const demande = etat.demandes.find((d) => d.id === demandeId);
  if (!demande) return echec('Demande introuvable.');
  if (demande.statut !== 'BROUILLON') {
    return echec(
      `Une demande au statut « ${demande.statut} » ne peut pas etre soumise. Seul un brouillon peut l'etre.`,
    );
  }
  if (demande.lignes.length === 0) {
    return echec('La demande ne contient aucune ligne. Ajoutez au moins un article avant de soumettre.');
  }
  const demandes = etat.demandes.map((d) =>
    d.id === demandeId ? { ...d, statut: 'A_VERIFIER' as const } : d,
  );
  return {
    ok: true,
    valeur: {
      ...etat,
      demandes,
      journal: journaliser(
        etat,
        {
          action: 'Soumission de la demande',
          entiteType: 'demande',
          entiteId: demande.numero,
          valeurAvant: 'BROUILLON',
          valeurApres: 'A_VERIFIER',
        },
        ctx,
      ),
    },
  };
}

/**
 * Approbation : c'est le seul moment ou le stock est engage.
 * Avant approbation, une demande ne promet aucune quantite.
 */
export function approuverDemande(
  etat: EtatDonnees,
  demandeId: string,
  quantitesApprouvees: Record<string, number>,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const demande = etat.demandes.find((d) => d.id === demandeId);
  if (!demande) return echec('Demande introuvable.');
  if (demande.statut !== 'A_VERIFIER' && demande.statut !== 'SOUMISE') {
    return echec(
      `La demande ${demande.numero} ne peut pas etre approuvee depuis le statut « ${demande.statut} ».`,
    );
  }

  const etats = calculerStock(etat.produits, etat.mouvements);
  const lignesControle = demande.lignes.map((ligne) => ({
    produitId: ligne.produitId,
    nom: etat.produits.find((p) => p.id === ligne.produitId)?.nom ?? ligne.produitId,
    quantite: quantitesApprouvees[ligne.id] ?? ligne.quantiteDemandee,
  }));

  const negative = lignesControle.find((l) => l.quantite < 0 || !Number.isInteger(l.quantite));
  if (negative) {
    return echec(
      `Quantite approuvee invalide pour « ${negative.nom} » : saisissez un entier superieur ou egal a zero.`,
    );
  }

  const controle = verifierDisponibilite(
    lignesControle.filter((l) => l.quantite > 0),
    etats,
  );
  if (!controle.ok) return echec(controle.message ?? 'Stock insuffisant.', controle.details);

  const nouveauxMouvements = lignesControle
    .filter((l) => l.quantite > 0)
    .map((l) =>
      mouvement(
        {
          produitId: l.produitId,
          quantite: l.quantite,
          type: 'RESERVATION',
          clientId: demande.clientId,
          chantierId: demande.chantierId,
          documentRef: demande.numero,
          motif: 'Reservation a l approbation de la demande',
        },
        ctx,
      ),
    );

  const simulation = simulerMouvements(etat.mouvements, nouveauxMouvements, etat.produits);
  if (!simulation.ok) return echec(simulation.message ?? 'Operation refusee.', simulation.details);

  const demandes = etat.demandes.map((d) =>
    d.id === demandeId
      ? {
          ...d,
          statut: 'APPROUVEE' as const,
          lignes: d.lignes.map((ligne) => ({
            ...ligne,
            quantiteApprouvee: quantitesApprouvees[ligne.id] ?? ligne.quantiteDemandee,
          })),
        }
      : d,
  );

  return {
    ok: true,
    valeur: {
      ...etat,
      demandes,
      mouvements: [...etat.mouvements, ...nouveauxMouvements],
      journal: journaliser(
        etat,
        {
          action: 'Approbation de la demande et reservation du stock',
          entiteType: 'demande',
          entiteId: demande.numero,
          valeurAvant: demande.statut,
          valeurApres: 'APPROUVEE',
        },
        ctx,
      ),
    },
  };
}

export function refuserDemande(
  etat: EtatDonnees,
  demandeId: string,
  motif: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const demande = etat.demandes.find((d) => d.id === demandeId);
  if (!demande) return echec('Demande introuvable.');
  if (!motif.trim()) return echec('Un motif est obligatoire pour refuser une demande.');
  if (demande.statut === 'APPROUVEE') {
    return echec(
      'Une demande deja approuvee ne peut plus etre refusee. Annulez-la pour liberer les reservations.',
    );
  }
  return {
    ok: true,
    valeur: {
      ...etat,
      demandes: etat.demandes.map((d) =>
        d.id === demandeId ? { ...d, statut: 'REFUSEE' as const } : d,
      ),
      journal: journaliser(
        etat,
        {
          action: 'Refus de la demande',
          entiteType: 'demande',
          entiteId: demande.numero,
          valeurAvant: demande.statut,
          valeurApres: 'REFUSEE',
          motif,
        },
        ctx,
      ),
    },
  };
}

/* ----------------------------------------------------------- Preparations */

export function creerPreparation(
  etat: EtatDonnees,
  demandeId: string,
  assigneAId: string | null,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const demande = etat.demandes.find((d) => d.id === demandeId);
  if (!demande) return echec('Demande introuvable.');
  if (demande.statut !== 'APPROUVEE') {
    return echec(
      `La preparation ne peut etre creee que depuis une demande approuvee. Statut actuel : « ${demande.statut} ».`,
    );
  }
  const dejaOuverte = etat.preparations.find(
    (p) => p.demandeId === demandeId && p.statut !== 'PRETE',
  );
  if (dejaOuverte) {
    return echec(`Une preparation est deja en cours pour cette demande (${dejaOuverte.numero}).`);
  }

  const vague = etat.preparations.filter((p) => p.demandeId === demandeId).length + 1;
  const { numero, compteurs } = numeroSuivant(etat.compteurs, 'PREP', new Date().getFullYear());

  const lignes: LignePreparation[] = demande.lignes
    .filter((l) => (l.quantiteApprouvee ?? 0) > 0)
    .map((ligne) => ({
      id: id('lprep'),
      ligneDemandeId: ligne.id,
      produitId: ligne.produitId,
      typeItem: ligne.typeItem,
      quantiteConfirmee: ligne.quantiteApprouvee ?? 0,
      quantitePreparee: 0,
      photos: [],
      noteInterne: '',
      manquant: false,
      substitutionProduitId: null,
      substitutionMotif: '',
      confirmee: false,
    }));

  const preparation: Preparation = {
    id: id('prep'),
    numero,
    demandeId,
    statut: 'A_PREPARER',
    assigneAId,
    vague,
    dateCreation: maintenant(),
    lignes,
    notes: '',
  };

  return {
    ok: true,
    valeur: {
      ...etat,
      compteurs,
      preparations: [...etat.preparations, preparation],
      journal: journaliser(
        etat,
        {
          action: `Creation de la preparation (vague ${vague})`,
          entiteType: 'preparation',
          entiteId: numero,
          valeurApres: 'A_PREPARER',
        },
        ctx,
      ),
    },
  };
}

export function majLignePreparation(
  etat: EtatDonnees,
  preparationId: string,
  ligneId: string,
  patch: Partial<LignePreparation>,
): ResultatRegle<EtatDonnees> {
  const preparation = etat.preparations.find((p) => p.id === preparationId);
  if (!preparation) return echec('Preparation introuvable.');
  if (preparation.statut === 'PRETE') {
    return echec(
      'Cette preparation est deja prete. Repassez-la en preparation pour modifier les quantites.',
    );
  }
  if (patch.quantitePreparee !== undefined && patch.quantitePreparee < 0) {
    return echec('La quantite preparee ne peut pas etre negative.');
  }

  const preparations = etat.preparations.map((p) => {
    if (p.id !== preparationId) return p;
    const lignes = p.lignes.map((l) => (l.id === ligneId ? { ...l, ...patch } : l));
    const total = somme(lignes, (l) => l.quantitePreparee);
    const statut: Preparation['statut'] =
      p.statut === 'BLOQUEE' ? 'BLOQUEE' : total > 0 ? 'EN_PREPARATION' : 'A_PREPARER';
    return { ...p, lignes, statut };
  });

  return { ok: true, valeur: { ...etat, preparations } };
}

/** Controle final avant le passage au statut « Prete ». */
export function controlerPreparation(etat: EtatDonnees, preparationId: string): ResultatRegle {
  const preparation = etat.preparations.find((p) => p.id === preparationId);
  if (!preparation) return { ok: false, message: 'Preparation introuvable.' };
  const nomProduit = (produitId: string) =>
    etat.produits.find((p) => p.id === produitId)?.nom ?? produitId;

  const details: string[] = [];
  for (const ligne of preparation.lignes) {
    const nom = nomProduit(ligne.produitId);
    if (!ligne.confirmee && !ligne.manquant) {
      details.push(`${nom} : ligne non traitee. Confirmez la ligne ou declarez l'article manquant.`);
      continue;
    }
    if (ligne.quantitePreparee > ligne.quantiteConfirmee) {
      details.push(
        `${nom} : ${ligne.quantitePreparee} unites sont preparees alors que ${ligne.quantiteConfirmee} unites ont ete approuvees. Corrigez la quantite ou ajoutez une justification.`,
      );
    }
    if (
      ligne.quantitePreparee < ligne.quantiteConfirmee &&
      !ligne.noteInterne.trim() &&
      !ligne.manquant
    ) {
      details.push(
        `${nom} : quantite insuffisante (${ligne.quantitePreparee} sur ${ligne.quantiteConfirmee}). Ajoutez une note expliquant le reliquat ou declarez l'article manquant.`,
      );
    }
    if (ligne.quantitePreparee > 0 && ligne.photos.length === 0) {
      details.push(`${nom} : photo obligatoire manquante pour une ligne preparee.`);
    }
    if (ligne.substitutionProduitId && !ligne.substitutionMotif.trim()) {
      details.push(`${nom} : substitution non justifiee. Indiquez le motif de la substitution.`);
    }
    if (ligne.manquant && !ligne.noteInterne.trim()) {
      details.push(`${nom} : article declare manquant sans note. La note interne est obligatoire.`);
    }
  }

  if (somme(preparation.lignes, (l) => l.quantitePreparee) === 0) {
    details.push('Aucune quantite preparee : la preparation ne peut pas etre declaree prete.');
  }

  return details.length === 0
    ? { ok: true }
    : { ok: false, message: 'Le controle final a detecte des points bloquants.', details };
}

export function marquerPreparationPrete(
  etat: EtatDonnees,
  preparationId: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const controle = controlerPreparation(etat, preparationId);
  if (!controle.ok) return echec(controle.message ?? 'Controle refuse.', controle.details);

  const preparation = etat.preparations.find((p) => p.id === preparationId);
  if (!preparation) return echec('Preparation introuvable.');
  const demande = etat.demandes.find((d) => d.id === preparation.demandeId);

  const nouveauxMouvements = preparation.lignes
    .filter((l) => l.quantitePreparee > 0)
    .map((l) =>
      mouvement(
        {
          produitId: l.produitId,
          quantite: l.quantitePreparee,
          type: 'PREPARATION',
          clientId: demande?.clientId ?? null,
          chantierId: demande?.chantierId ?? null,
          documentRef: preparation.numero,
          emplacementSource: etat.produits.find((p) => p.id === l.produitId)?.emplacement ?? null,
          emplacementDestination: 'Zone de preparation',
        },
        ctx,
      ),
    );

  const simulation = simulerMouvements(etat.mouvements, nouveauxMouvements, etat.produits);
  if (!simulation.ok) return echec(simulation.message ?? 'Operation refusee.', simulation.details);

  return {
    ok: true,
    valeur: {
      ...etat,
      mouvements: [...etat.mouvements, ...nouveauxMouvements],
      preparations: etat.preparations.map((p) =>
        p.id === preparationId ? { ...p, statut: 'PRETE' as const } : p,
      ),
      journal: journaliser(
        etat,
        {
          action: 'Preparation declaree prete',
          entiteType: 'preparation',
          entiteId: preparation.numero,
          valeurAvant: preparation.statut,
          valeurApres: 'PRETE',
        },
        ctx,
      ),
    },
  };
}

/* ------------------------------------------- Sorties et bons de livraison */

export function confirmerSortie(
  etat: EtatDonnees,
  preparationId: string,
  infos: {
    livreur: string;
    signataireNom: string;
    joursLocation: number;
    representant?: string;
    bonCommandeClient?: string;
    expedieVia?: string;
    termes?: string;
    typeItem?: 'LOCATION' | 'ACHAT';
  },
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const preparation = etat.preparations.find((p) => p.id === preparationId);
  if (!preparation) return echec('Preparation introuvable.');
  if (preparation.statut !== 'PRETE') {
    return echec(
      `La sortie ne peut pas etre confirmee : la preparation ${preparation.numero} est au statut « ${preparation.statut} ». Terminez le controle final.`,
    );
  }
  const controle = controlerPreparation(etat, preparationId);
  if (!controle.ok) return echec(controle.message ?? 'Controle refuse.', controle.details);

  const demande = etat.demandes.find((d) => d.id === preparation.demandeId);
  if (!demande) return echec('Demande liee introuvable.');
  if (!infos.livreur.trim()) return echec('Le nom du livreur est obligatoire pour confirmer la sortie.');

  const annee = new Date().getFullYear();
  // Numerotation continue avec l'historique papier (QV-004).
  const bl = numeroSequentiel(etat.compteurs, PREFIXE_BON, DERNIER_BON_PAPIER);
  const loc = numeroSuivant(bl.compteurs, 'LOC', annee);
  const lignesSortie = preparation.lignes
    .filter((l) => l.quantitePreparee > 0)
    .map((l) => ({
      id: id('lsortie'),
      produitId: l.substitutionProduitId ?? l.produitId,
      // Un meme bon peut mêler location et achat : le type suit la ligne, pas le bon.
      typeItem: infos.typeItem ?? l.typeItem,
      quantiteCommandee: l.quantiteConfirmee,
      quantite: l.quantitePreparee,
      // RG-024 : le reliquat reste visible au dossier et sur le bon.
      quantiteAVenir: Math.max(0, l.quantiteConfirmee - l.quantitePreparee),
      note: l.substitutionProduitId ? `Substitution : ${l.substitutionMotif}` : l.noteInterne,
    }));

  const nouveauxMouvements = lignesSortie.map((l) =>
    mouvement(
      {
        produitId: l.produitId,
        quantite: l.quantite,
        // Une ligne vendue quitte le parc ; une ligne louee entre en circulation.
        type: l.typeItem === 'ACHAT' ? 'VENTE' : 'SORTIE',
        clientId: demande.clientId,
        chantierId: demande.chantierId,
        documentRef: bl.numero,
        emplacementSource: 'Zone de preparation',
        emplacementDestination: l.typeItem === 'ACHAT' ? null : 'Vehicule de livraison',
        motif: l.typeItem === 'ACHAT' ? 'Vente ferme — aucun retour attendu' : null,
      },
      ctx,
    ),
  );

  const simulation = simulerMouvements(etat.mouvements, nouveauxMouvements, etat.produits);
  if (!simulation.ok) return echec(simulation.message ?? 'Operation refusee.', simulation.details);

  const sortie: Sortie = {
    id: id('sortie'),
    numero: bl.numero,
    version: 1,
    preparationId,
    demandeId: demande.id,
    clientId: demande.clientId,
    chantierId: demande.chantierId,
    statut: 'SORTIE_CONFIRMEE',
    lignes: lignesSortie,
    dateSortie: maintenant(),
    preparateurId: preparation.assigneAId ?? ctx.utilisateurId,
    livreur: infos.livreur,
    bonCommandeClient: infos.bonCommandeClient ?? '',
    commandeAlfa: demande.numero,
    representant: infos.representant ?? '',
    expedieVia: infos.expedieVia ?? '',
    termes: infos.termes ?? TERMES_DEFAUT,
    expedieA: '',
    heureArrivee: '',
    heureCommencee: '',
    heureTerminee: '',
    representantSignatureNom: infos.representant ?? '',
    representantSignatureDataUrl: null,
    signataireNom: infos.signataireNom,
    signataireLettresMoulees: infos.signataireNom,
    signatureDataUrl: null,
    dateSignature: null,
    photoDocumentSigne: null,
    receptionClient: [],
    jetonPublic: jetonDemo(),
    envoiSimule: false,
  };

  const lignesLouees = lignesSortie.filter((l) => l.typeItem === 'LOCATION');

  const location: Location | null =
    lignesLouees.length === 0
      ? null
      : {
    id: id('loc'),
    numero: loc.numero,
    sortieId: sortie.id,
    clientId: demande.clientId,
    chantierId: demande.chantierId,
    dateSortie: aujourdHui(),
    // La duree minimale de location relevee sur le bon papier est de 28 jours.
    retourAttendu: jourPlus(Math.max(infos.joursLocation, DUREE_LOCATION_MINIMALE_JOURS)),
    statut: 'ACTIVE',
    lignes: lignesLouees.map((l) => ({
      id: id('lloc'),
      produitId: l.produitId,
      quantiteSortie: l.quantite,
      quantiteRetournee: 0,
      quantiteEndommagee: 0,
      quantiteManquante: 0,
      quantiteContestee: 0,
    })),
  };

  return {
    ok: true,
    valeur: {
      ...etat,
      compteurs: location ? loc.compteurs : bl.compteurs,
      mouvements: [...etat.mouvements, ...nouveauxMouvements],
      sorties: [...etat.sorties, sortie],
      locations: location ? [...etat.locations, location] : etat.locations,
      journal: journaliser(
        etat,
        {
          action: `Sortie confirmee et bon de livraison ${bl.numero} genere`,
          entiteType: 'sortie',
          entiteId: bl.numero,
          valeurApres: 'SORTIE_CONFIRMEE',
        },
        ctx,
      ),
    },
  };
}

export function changerStatutSortie(
  etat: EtatDonnees,
  sortieId: string,
  cible: StatutSortie,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const sortie = etat.sorties.find((s) => s.id === sortieId);
  if (!sortie) return echec('Bon de livraison introuvable.');
  if (!TRANSITIONS_SORTIE[sortie.statut].includes(cible)) {
    return echec(
      `Transition refusee : un bon au statut « ${sortie.statut} » ne peut pas passer a « ${cible} ».`,
    );
  }
  return {
    ok: true,
    valeur: {
      ...etat,
      sorties: etat.sorties.map((s) => (s.id === sortieId ? { ...s, statut: cible } : s)),
      journal: journaliser(
        etat,
        {
          action: 'Changement de statut du bon de livraison',
          entiteType: 'sortie',
          entiteId: sortie.numero,
          valeurAvant: sortie.statut,
          valeurApres: cible,
        },
        ctx,
      ),
    },
  };
}

/** Signature simulee via le lien client (voir MVP_VS_PRODUCTION.md). */
export function signerBon(
  etat: EtatDonnees,
  sortieId: string,
  signature: {
    nom: string;
    lettresMoulees?: string;
    dataUrl: string | null;
    reception?: Sortie['receptionClient'];
  },
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const sortie = etat.sorties.find((s) => s.id === sortieId);
  if (!sortie) return echec('Bon de livraison introuvable.');
  if (!signature.nom.trim()) return echec('Le nom du signataire est obligatoire.');
  if (!signature.dataUrl) return echec('Tracez la signature avant de confirmer la reception.');
  if (sortie.statut === 'SIGNEE') return echec('Ce bon est deja signe.');

  return {
    ok: true,
    valeur: {
      ...etat,
      sorties: etat.sorties.map((s) =>
        s.id === sortieId
          ? {
              ...s,
              statut: 'SIGNEE' as const,
              signataireNom: signature.nom,
              signataireLettresMoulees: signature.lettresMoulees ?? signature.nom,
              signatureDataUrl: signature.dataUrl,
              receptionClient: signature.reception ?? s.receptionClient,
              dateSignature: maintenant(),
            }
          : s,
      ),
      journal: journaliser(
        etat,
        {
          action: 'Reception confirmee et bon signe (simulation de demonstration)',
          entiteType: 'sortie',
          entiteId: sortie.numero,
          valeurAvant: sortie.statut,
          valeurApres: 'SIGNEE',
          motif: `Signataire : ${signature.nom}`,
        },
        ctx,
      ),
    },
  };
}

/* --------------------------------------------- Retours et rapprochement */

export function quantiteRestante(ligne: Location['lignes'][number]): number {
  return (
    ligne.quantiteSortie - ligne.quantiteRetournee - ligne.quantiteEndommagee - ligne.quantiteManquante
  );
}

export function demarrerRetour(
  etat: EtatDonnees,
  locationId: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const location = etat.locations.find((l) => l.id === locationId);
  if (!location) return echec('Location introuvable.');
  if (location.statut === 'CLOTUREE') {
    return echec('Cette location est cloturee : aucun retour supplementaire ne peut etre enregistre.');
  }
  // RG-041 : plusieurs retours peuvent se rattacher a une meme sortie.
  // Seul un comptage non soumis empeche l'ouverture d'un nouveau retour.
  const enCours = etat.retours.find(
    (r) => r.locationId === locationId && (r.statut === 'COMMENCE' || r.statut === 'COMPTAGE'),
  );
    if (enCours) {
    return echec(
      `Un comptage est deja en cours pour cette location (${enCours.numero}). Soumettez-le avant d ouvrir un nouveau retour.`,
    );
  }

  const { numero, compteurs } = numeroSuivant(etat.compteurs, 'RET', new Date().getFullYear());
  const retour: Retour = {
    id: id('ret'),
    numero,
    locationId,
    date: aujourdHui(),
    statut: 'COMMENCE',
    receptionnaireId: ctx.utilisateurId,
    notes: '',
    lignes: location.lignes
      .filter((l) => quantiteRestante(l) > 0)
      .map((l) => ({
        id: id('lret'),
        produitId: l.produitId,
        ligneLocationId: l.id,
        quantiteAttendue: quantiteRestante(l),
        quantiteRecue: 0,
        quantiteAcceptee: 0,
        quantiteEndommagee: 0,
        quantiteManquante: 0,
        quantiteContestee: 0,
        quantiteExcedent: 0,
        etat: 'BON',
        photos: [],
        commentaire: '',
      })),
  };

  if (retour.lignes.length === 0) {
    return echec('Tout le materiel de cette location a deja ete rapproche.');
  }

  return {
    ok: true,
    valeur: {
      ...etat,
      compteurs,
      retours: [...etat.retours, retour],
      journal: journaliser(
        etat,
        {
          action: 'Ouverture d un retour',
          entiteType: 'retour',
          entiteId: numero,
          valeurApres: 'COMMENCE',
        },
        ctx,
      ),
    },
  };
}

export function majLigneRetour(
  etat: EtatDonnees,
  retourId: string,
  ligneId: string,
  patch: Partial<Retour['lignes'][number]>,
): ResultatRegle<EtatDonnees> {
  const retour = etat.retours.find((r) => r.id === retourId);
  if (!retour) return echec('Retour introuvable.');
  if (!['COMMENCE', 'COMPTAGE', 'ECART_DETECTE', 'VERIFICATION'].includes(retour.statut)) {
    return echec('Ce retour est deja accepte : plus aucune quantite ne peut etre modifiee.');
  }

  const ligne = retour.lignes.find((l) => l.id === ligneId);
  if (!ligne) return echec('Ligne de retour introuvable.');
  const maj = { ...ligne, ...patch };
  const nom = etat.produits.find((p) => p.id === ligne.produitId)?.nom ?? ligne.produitId;

  const quantites = [
    maj.quantiteAcceptee,
    maj.quantiteEndommagee,
    maj.quantiteManquante,
    maj.quantiteContestee,
    maj.quantiteExcedent,
  ];
  if (quantites.some((v) => v < 0 || !Number.isInteger(v))) {
    return echec(`${nom} : les quantites doivent etre des entiers positifs ou nuls.`);
  }

  // Section 12.3 — mauvaise reference : aucune acceptation avant verification.
  if (maj.etat === 'REFERENCE_NON_CONFORME' && maj.quantiteAcceptee > 0) {
    return echec(
      `${nom} : la reference recue n est pas conforme. Aucune quantite ne peut etre acceptee avant verification et reaffectation ; qualifiez-la en quantite contestee.`,
    );
  }

  const qualifie =
    maj.quantiteAcceptee + maj.quantiteEndommagee + maj.quantiteManquante + maj.quantiteContestee;
  if (qualifie > maj.quantiteAttendue) {
    return echec(
      `${nom} : ${qualifie} unites sont qualifiees alors que ${maj.quantiteAttendue} unites sont attendues pour ce retour. Saisissez le surplus dans « excedent recu » plutot que dans les quantites attendues.`,
    );
  }

  maj.quantiteRecue = maj.quantiteAcceptee + maj.quantiteEndommagee + maj.quantiteExcedent;

  return {
    ok: true,
    valeur: {
      ...etat,
      retours: etat.retours.map((r) =>
        r.id === retourId
          ? {
              ...r,
              statut: r.statut === 'COMMENCE' ? ('COMPTAGE' as const) : r.statut,
              lignes: r.lignes.map((l) => (l.id === ligneId ? maj : l)),
            }
          : r,
      ),
    },
  };
}

export interface ApercuEcart {
  produitId: string;
  nom: string;
  attendue: number;
  acceptee: number;
  endommagee: number;
  manquante: number;
  contestee: number;
  excedent: number;
  ecart: number;
  compte: boolean;
}

/**
 * Ecart du retour = quantite attendue - quantite acceptee (section 12.1).
 * Le systeme calcule et presente l'ecart AVANT toute decision (RG-043).
 * US-023 : une ligne sans saisie est « non comptee », jamais interpretee comme zero.
 */
export function apercuRetour(etat: EtatDonnees, retourId: string): ApercuEcart[] {
  const retour = etat.retours.find((r) => r.id === retourId);
  if (!retour) return [];
  return retour.lignes.map((l) => ({
    produitId: l.produitId,
    nom: etat.produits.find((p) => p.id === l.produitId)?.nom ?? l.produitId,
    attendue: l.quantiteAttendue,
    acceptee: l.quantiteAcceptee,
    endommagee: l.quantiteEndommagee,
    manquante: l.quantiteManquante,
    contestee: l.quantiteContestee,
    excedent: l.quantiteExcedent,
    ecart: l.quantiteAttendue - l.quantiteAcceptee,
    compte:
      l.quantiteAcceptee +
        l.quantiteEndommagee +
        l.quantiteManquante +
        l.quantiteContestee +
        l.quantiteExcedent >
      0,
  }));
}

export function validerRetour(
  etat: EtatDonnees,
  retourId: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const retour = etat.retours.find((r) => r.id === retourId);
  if (!retour) return echec('Retour introuvable.');
  if (['ACCEPTE', 'CLOTURE', 'ANNULE'].includes(retour.statut)) {
    return echec('Ce retour a deja ete accepte.');
  }
  const location = etat.locations.find((l) => l.id === retour.locationId);
  if (!location) return echec('Location liee introuvable.');

  const totalQualifie = somme(
    retour.lignes,
    (l) =>
      l.quantiteAcceptee +
      l.quantiteEndommagee +
      l.quantiteManquante +
      l.quantiteContestee +
      l.quantiteExcedent,
  );
  if (totalQualifie === 0) {
    return echec(
      'Aucune quantite n a ete comptee. Saisissez les quantites acceptees, endommagees, manquantes, contestees ou en excedent avant de valider.',
    );
  }

  // Section 12.3 — une photo est obligatoire pour tout dommage ou article manquant.
  const sansPreuve = retour.lignes.filter(
    (l) => (l.quantiteEndommagee > 0 || l.quantiteManquante > 0) && l.photos.length === 0,
  );
  if (sansPreuve.length > 0) {
    return echec(
      'Une photo est obligatoire pour chaque dommage ou article manquant.',
      sansPreuve.map(
        (l) =>
          `${etat.produits.find((p) => p.id === l.produitId)?.nom ?? l.produitId} : preuve photo manquante.`,
      ),
    );
  }

  const nouveauxMouvements: Mouvement[] = [];
  const ajouter = (produitId: string, quantite: number, type: TypeMouvement, motif: string) => {
    if (quantite <= 0) return;
    nouveauxMouvements.push(
      mouvement(
        {
          produitId,
          quantite,
          type,
          clientId: location.clientId,
          chantierId: location.chantierId,
          documentRef: retour.numero,
          emplacementSource: 'Sur le chantier',
          emplacementDestination:
            type === 'DOMMAGE' || type === 'EXCEDENT_QUARANTAINE'
              ? 'Quarantaine'
              : type === 'PERTE'
                ? null
                : (etat.produits.find((p) => p.id === produitId)?.emplacement ?? 'Zone de retour'),
          motif,
        },
        ctx,
      ),
    );
  };

  for (const ligne of retour.lignes) {
    ajouter(ligne.produitId, ligne.quantiteAcceptee, 'RETOUR_ACCEPTE', 'Retour accepte en bon etat');
    ajouter(ligne.produitId, ligne.quantiteEndommagee, 'DOMMAGE', 'Retour endommage mis en quarantaine');
    ajouter(ligne.produitId, ligne.quantiteManquante, 'PERTE', 'Quantite declaree manquante au retour');
    ajouter(
      ligne.produitId,
      ligne.quantiteExcedent,
      'EXCEDENT_QUARANTAINE',
      'Surplus non attribue place en quarantaine jusqu a identification de l origine',
    );
  }

  const simulation = simulerMouvements(etat.mouvements, nouveauxMouvements, etat.produits);
  if (!simulation.ok) return echec(simulation.message ?? 'Operation refusee.', simulation.details);

  // Mise a jour du rapprochement de la location.
  const lignesLocation = location.lignes.map((ll) => {
    const ligne = retour.lignes.find((l) => l.ligneLocationId === ll.id);
    if (!ligne) return ll;
    return {
      ...ll,
      quantiteRetournee: ll.quantiteRetournee + ligne.quantiteAcceptee,
      quantiteEndommagee: ll.quantiteEndommagee + ligne.quantiteEndommagee,
      quantiteManquante: ll.quantiteManquante + ligne.quantiteManquante,
      quantiteContestee: ll.quantiteContestee + ligne.quantiteContestee,
    };
  });

  const resteChezClient = somme(lignesLocation, quantiteRestante);
  const contestations = somme(lignesLocation, (l) => l.quantiteContestee);
  const statutLocation: Location['statut'] =
    contestations > 0
      ? 'EN_LITIGE'
      : resteChezClient === 0
        ? 'CLOTUREE'
        : 'RETOUR_PARTIEL';

  // RG-042 : chaque ecart devient un constat numerote, joint au dossier.
  const annee = new Date().getFullYear();
  let compteurs = etat.compteurs;
  const nouveauxEcarts: Ecart[] = [];
  const creerEcart = (
    produitId: string,
    quantite: number,
    type: Ecart['type'],
    photos: Ecart['photos'],
  ) => {
    if (quantite <= 0) return;
    const suite = numeroSuivant(compteurs, 'ECA', annee);
    compteurs = suite.compteurs;
    nouveauxEcarts.push({
      id: id('ecart'),
      numero: suite.numero,
      retourId: retour.id,
      locationId: location.id,
      clientId: location.clientId,
      chantierId: location.chantierId,
      produitId,
      quantite,
      type,
      photos,
      responsableId: ctx.utilisateurId,
      decision: 'A_VERIFIER',
      motif: '',
      dateCreation: maintenant(),
      dateDecision: null,
    });
  };

  for (const ligne of retour.lignes) {
    creerEcart(ligne.produitId, ligne.quantiteManquante, 'MANQUANT', ligne.photos);
    creerEcart(ligne.produitId, ligne.quantiteEndommagee, 'ENDOMMAGE', ligne.photos);
    creerEcart(ligne.produitId, ligne.quantiteContestee, 'CONTESTE', ligne.photos);
    creerEcart(ligne.produitId, ligne.quantiteExcedent, 'EXCEDENT', ligne.photos);
    if (ligne.etat === 'REFERENCE_NON_CONFORME' && ligne.quantiteContestee === 0) {
      creerEcart(ligne.produitId, ligne.quantiteRecue, 'REFERENCE_NON_CONFORME', ligne.photos);
    }
  }

  const statutRetour: Retour['statut'] = nouveauxEcarts.length > 0 ? 'ECART_DETECTE' : 'ACCEPTE';

  return {
    ok: true,
    valeur: {
      ...etat,
      compteurs,
      mouvements: [...etat.mouvements, ...nouveauxMouvements],
      retours: etat.retours.map((r) => (r.id === retourId ? { ...r, statut: statutRetour } : r)),
      locations: etat.locations.map((l) =>
        l.id === location.id ? { ...l, lignes: lignesLocation, statut: statutLocation } : l,
      ),
      ecarts: [...etat.ecarts, ...nouveauxEcarts],
      journal: journaliser(
        etat,
        {
          action: `Comptage soumis — ${nouveauxEcarts.length} ecart(s) detecte(s)`,
          entiteType: 'retour',
          entiteId: retour.numero,
          valeurAvant: retour.statut,
          valeurApres: statutRetour,
        },
        ctx,
      ),
    },
  };
}

/**
 * RG-040 : la cloture exige que toutes les quantites soient rapprochees,
 * que chaque ecart porte une decision et que les preuves requises soient presentes.
 */
export function cloturerRetour(
  etat: EtatDonnees,
  retourId: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const retour = etat.retours.find((r) => r.id === retourId);
  if (!retour) return echec('Retour introuvable.');
  if (retour.statut === 'CLOTURE') return echec('Ce retour est deja cloture.');
  if (retour.statut === 'COMMENCE' || retour.statut === 'COMPTAGE') {
    return echec('Le comptage doit d abord etre soumis avant la cloture du retour.');
  }

  const ouverts = etat.ecarts.filter(
    (e) => e.retourId === retourId && (e.decision === 'A_VERIFIER' || e.decision === 'EN_LITIGE'),
  );
  if (ouverts.length > 0) {
    return echec(
      'La cloture est refusee : des ecarts attendent encore une decision.',
      ouverts.map((e) => {
        const nom = etat.produits.find((p) => p.id === e.produitId)?.nom ?? e.produitId;
        return `${e.numero} — ${nom} : ${e.quantite} unite(s), statut « ${e.decision} ».`;
      }),
    );
  }

  return {
    ok: true,
    valeur: {
      ...etat,
      retours: etat.retours.map((r) => (r.id === retourId ? { ...r, statut: 'CLOTURE' as const } : r)),
      journal: journaliser(
        etat,
        {
          action: 'Cloture du retour',
          entiteType: 'retour',
          entiteId: retour.numero,
          valeurAvant: retour.statut,
          valeurApres: 'CLOTURE',
        },
        ctx,
      ),
    },
  };
}


/* ---------------------------------------------------------------- Ecarts */

export function deciderEcart(
  etat: EtatDonnees,
  ecartId: string,
  decision: Ecart['decision'],
  motif: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const ecart = etat.ecarts.find((e) => e.id === ecartId);
  if (!ecart) return echec('Ecart introuvable.');
  if (!motif.trim()) {
    return echec('Un motif est obligatoire : toute decision sur un ecart est tracee dans le journal.');
  }
  return {
    ok: true,
    valeur: {
      ...etat,
      ecarts: etat.ecarts.map((e) =>
        e.id === ecartId ? { ...e, decision, motif, dateDecision: maintenant() } : e,
      ),
      journal: journaliser(
        etat,
        {
          action: 'Decision sur un ecart',
          entiteType: 'ecart',
          entiteId: ecart.numero,
          valeurAvant: ecart.decision,
          valeurApres: decision,
          motif,
        },
        ctx,
      ),
    },
  };
}

/* ------------------------------------------------------------ Ajustement */

export function ajusterStock(
  etat: EtatDonnees,
  produitId: string,
  nouvelleQuantitePhysique: number,
  motif: string,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const produit = etat.produits.find((p) => p.id === produitId);
  if (!produit) return echec('Article introuvable.');
  if (!motif.trim()) return echec('Un motif est obligatoire pour tout ajustement manuel du stock.');
  if (!Number.isInteger(nouvelleQuantitePhysique) || nouvelleQuantitePhysique < 0) {
    return echec('La quantite apres ajustement doit etre un entier positif ou nul.');
  }

  const etats = calculerStock(etat.produits, etat.mouvements);
  const avant = etats.get(produitId);
  if (!avant) return echec('Etat de stock introuvable.');
  const delta = nouvelleQuantitePhysique - avant.physique;
  if (delta === 0) return echec('La valeur saisie est identique au stock physique actuel.');

  const nouveau = mouvement(
    {
      produitId,
      quantite: delta,
      type: 'AJUSTEMENT',
      documentRef: 'Ajustement manuel',
      motif,
      emplacementDestination: produit.emplacement,
    },
    ctx,
  );

  const simulation = simulerMouvements(etat.mouvements, [nouveau], etat.produits);
  if (!simulation.ok) return echec(simulation.message ?? 'Operation refusee.', simulation.details);

  return {
    ok: true,
    valeur: {
      ...etat,
      mouvements: [...etat.mouvements, nouveau],
      journal: journaliser(
        etat,
        {
          action: 'Ajustement manuel du stock physique',
          entiteType: 'produit',
          entiteId: produit.sku,
          valeurAvant: String(avant.physique),
          valeurApres: String(nouvelleQuantitePhysique),
          motif,
        },
        ctx,
      ),
    },
  };
}

/* ------------------------------------------------------ Demandes (CRUD) */

export function enregistrerDemande(
  etat: EtatDonnees,
  demande: Demande,
  ctx: ContexteOperation,
): ResultatRegle<EtatDonnees> {
  const existe = etat.demandes.some((d) => d.id === demande.id);
  const journal = journaliser(
    etat,
    {
      action: existe ? 'Modification de la demande' : 'Creation de la demande',
      entiteType: 'demande',
      entiteId: demande.numero,
      valeurApres: demande.statut,
    },
    ctx,
  );
  return {
    ok: true,
    valeur: {
      ...etat,
      demandes: existe
        ? etat.demandes.map((d) => (d.id === demande.id ? demande : d))
        : [...etat.demandes, demande],
      journal,
    },
  };
}
