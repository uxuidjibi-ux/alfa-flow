import type { EtatDonnees } from '../models/types';

/**
 * Couche de persistance isolee derriere une interface.
 * Le remplacement par Supabase / PostgreSQL + API consiste a fournir une autre
 * implementation de `DepotDonnees` et de `DepotPhotos` : aucun composant
 * d'interface n'accede directement au stockage.
 */
export interface DepotDonnees {
  charger(): Promise<EtatDonnees | null>;
  enregistrer(etat: EtatDonnees): Promise<void>;
  effacer(): Promise<void>;
}

export interface DepotPhotos {
  ajouter(cle: string, contenu: string): Promise<void>;
  lire(cle: string): Promise<string | null>;
  supprimer(cle: string): Promise<void>;
  vider(): Promise<void>;
}

export const CLE_STOCKAGE = 'alfa-flow.donnees.v1';
export const VERSION_SCHEMA = 1;

interface Enveloppe {
  version: number;
  donnees: EtatDonnees;
}

export class DepotLocalStorage implements DepotDonnees {
  constructor(private readonly cle: string = CLE_STOCKAGE) {}

  async charger(): Promise<EtatDonnees | null> {
    try {
      const brut = window.localStorage.getItem(this.cle);
      if (!brut) return null;
      const enveloppe = JSON.parse(brut) as Enveloppe;
      if (enveloppe.version !== VERSION_SCHEMA) return null;
      return enveloppe.donnees;
    } catch {
      return null;
    }
  }

  async enregistrer(etat: EtatDonnees): Promise<void> {
    const enveloppe: Enveloppe = { version: VERSION_SCHEMA, donnees: etat };
    try {
      window.localStorage.setItem(this.cle, JSON.stringify(enveloppe));
    } catch (erreur) {
      console.warn('Persistance locale impossible (quota depasse ?)', erreur);
    }
  }

  async effacer(): Promise<void> {
    window.localStorage.removeItem(this.cle);
  }
}

/**
 * Les photos sont volumineuses : elles vont dans IndexedDB et non dans
 * localStorage, dont le quota est trop faible.
 */
export class DepotPhotosIndexedDB implements DepotPhotos {
  private readonly nomBase = 'alfa-flow-photos';
  private readonly magasin = 'photos';

  private ouvrir(): Promise<IDBDatabase> {
    return new Promise((resoudre, rejeter) => {
      const requete = indexedDB.open(this.nomBase, 1);
      requete.onupgradeneeded = () => {
        const base = requete.result;
        if (!base.objectStoreNames.contains(this.magasin)) base.createObjectStore(this.magasin);
      };
      requete.onsuccess = () => resoudre(requete.result);
      requete.onerror = () => rejeter(requete.error);
    });
  }

  private async transaction<T>(
    mode: IDBTransactionMode,
    action: (magasin: IDBObjectStore) => IDBRequest<T>,
  ): Promise<T> {
    const base = await this.ouvrir();
    return new Promise<T>((resoudre, rejeter) => {
      const tx = base.transaction(this.magasin, mode);
      const requete = action(tx.objectStore(this.magasin));
      requete.onsuccess = () => resoudre(requete.result);
      requete.onerror = () => rejeter(requete.error);
      tx.oncomplete = () => base.close();
    });
  }

  async ajouter(cle: string, contenu: string): Promise<void> {
    await this.transaction('readwrite', (m) => m.put(contenu, cle));
  }

  async lire(cle: string): Promise<string | null> {
    try {
      const valeur = await this.transaction<string | undefined>('readonly', (m) => m.get(cle));
      return valeur ?? null;
    } catch {
      return null;
    }
  }

  async supprimer(cle: string): Promise<void> {
    await this.transaction('readwrite', (m) => m.delete(cle));
  }

  async vider(): Promise<void> {
    try {
      await this.transaction('readwrite', (m) => m.clear());
    } catch {
      /* base absente : rien a vider */
    }
  }
}

/** Depot en memoire, utilise par les tests unitaires. */
export class DepotMemoire implements DepotDonnees {
  private valeur: EtatDonnees | null = null;
  async charger() {
    return this.valeur;
  }
  async enregistrer(etat: EtatDonnees) {
    this.valeur = etat;
  }
  async effacer() {
    this.valeur = null;
  }
}

export const depotDonnees: DepotDonnees = new DepotLocalStorage();
export const depotPhotos: DepotPhotos = new DepotPhotosIndexedDB();
