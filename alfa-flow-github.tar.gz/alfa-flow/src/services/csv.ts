/** Generation CSV compatible Excel (separateur point-virgule, BOM UTF-8). */

export type ValeurCsv = string | number | null | undefined;

export function echapper(valeur: ValeurCsv): string {
  if (valeur === null || valeur === undefined) return '';
  const texte = String(valeur);
  return /[";\n\r]/.test(texte) ? `"${texte.replace(/"/g, '""')}"` : texte;
}

export function versCsv(entetes: string[], lignes: ValeurCsv[][]): string {
  return [entetes, ...lignes].map((ligne) => ligne.map(echapper).join(';')).join('\r\n');
}

export function nomFichier(base: string): string {
  return `${base}-${new Date().toISOString().slice(0, 10)}.csv`;
}

/** Telechargement reel dans le navigateur. */
export function telechargerCsv(base: string, entetes: string[], lignes: ValeurCsv[][]): void {
  const contenu = `\uFEFF${versCsv(entetes, lignes)}`;
  const blob = new Blob([contenu], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const lien = document.createElement('a');
  lien.href = url;
  lien.download = nomFichier(base);
  document.body.appendChild(lien);
  lien.click();
  document.body.removeChild(lien);
  URL.revokeObjectURL(url);
}
