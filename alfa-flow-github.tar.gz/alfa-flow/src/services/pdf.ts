import { jsPDF } from 'jspdf';
import type { Chantier, Client, Contact, Produit, Sortie, Utilisateur } from '../models/types';
import { CONDITIONS_BON, LIBELLE_STATUT_SORTIE, ORGANISATION } from '../models/referentiel';
import { LOGO_ALFA_BASE64, LOGO_ALFA_RATIO } from '../assets/logo';
import { formatDate, formatDateHeure } from '../utils';

/**
 * Bon de livraison ALFA Flow.
 *
 * La mise en page reprend la structure du bon papier Groupe Alfa fourni le
 * 4 aout 2026 (bon L-18203) : bloc emetteur, « Vendu a » / « Expedie a »,
 * bande administrative, tableau Item Code / Type d'item / Description / U/M /
 * Qte commandee / Qte expediee / Qte a venir, puis bloc LOCATION / ACHAT avec
 * heures et double signature.
 *
 * Reconstitution en attendant le gabarit officiel de Groupe Alfa (ASSUMPTIONS.md).
 */

export interface DonneesBon {
  sortie: Sortie;
  client: Client;
  chantier: Chantier;
  contact?: Contact;
  produits: Produit[];
  preparateur: Utilisateur | undefined;
  referenceDemande: string;
}

const ROUGE: [number, number, number] = [255, 5, 1];
const ENCRE: [number, number, number] = [17, 17, 17];
const GRIS: [number, number, number] = [110, 116, 122];
const LIGNE: [number, number, number] = [160, 165, 170];

const MARGE = 12;
const LARGEUR = 210;
const DROITE = LARGEUR - MARGE;

function cadre(doc: jsPDF, x: number, y: number, l: number, h: number) {
  doc.setDrawColor(...LIGNE);
  doc.setLineWidth(0.3);
  doc.rect(x, y, l, h);
}

function etiquette(doc: jsPDF, texte: string, x: number, y: number) {
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(...GRIS);
  doc.text(texte.toUpperCase(), x, y);
}

function valeur(doc: jsPDF, texte: string, x: number, y: number, taille = 9) {
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(taille);
  doc.setTextColor(...ENCRE);
  doc.text(texte || '—', x, y);
}

export function construireBonLivraison(donnees: DonneesBon): jsPDF {
  const { sortie, client, chantier, contact, produits, preparateur, referenceDemande } = donnees;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  let y = MARGE;

  /* ------------------------------------------------------------- En-tete */

  const largeurLogo = 46;
  try {
    doc.addImage(LOGO_ALFA_BASE64, 'PNG', MARGE, y, largeurLogo, largeurLogo / LOGO_ALFA_RATIO);
  } catch {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.setTextColor(...ENCRE);
    doc.text('ALFA', MARGE, y + 10);
  }

  const xEmetteur = MARGE + 62;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...ENCRE);
  doc.text(ORGANISATION.raisonSociale, xEmetteur, y + 4);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(ORGANISATION.adresse, xEmetteur, y + 8.5);
  doc.text(ORGANISATION.ville, xEmetteur, y + 12.5);
  doc.text(`Tel. : ${ORGANISATION.telephone}`, xEmetteur, y + 16.5);
  doc.text(`Telec. : ${ORGANISATION.telecopieur}`, xEmetteur, y + 20.5);

  const xBloc = MARGE + 122;
  const largeurBloc = DROITE - xBloc;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(...ENCRE);
  doc.text('BON DE LIVRAISON', xBloc + largeurBloc / 2, y + 5, { align: 'center' });

  cadre(doc, xBloc, y + 8, largeurBloc, 14);
  doc.line(xBloc + largeurBloc / 2, y + 8, xBloc + largeurBloc / 2, y + 22);
  doc.line(xBloc, y + 13, xBloc + largeurBloc, y + 13);
  etiquette(doc, 'Date', xBloc + 2, y + 11.7);
  etiquette(doc, 'No. bon de liv.', xBloc + largeurBloc / 2 + 2, y + 11.7);
  valeur(doc, formatDate(sortie.dateSortie), xBloc + 2, y + 19, 9.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...ROUGE);
  doc.setFontSize(11);
  doc.text(sortie.numero, xBloc + largeurBloc / 2 + 2, y + 19);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(...GRIS);
  doc.text(
    `Page 1/1${sortie.version > 1 ? `  ·  Version ${sortie.version}` : ''}  ·  ${LIBELLE_STATUT_SORTIE[sortie.statut]}`,
    xBloc + largeurBloc / 2,
    y + 25.5,
    { align: 'center' },
  );

  y += 30;

  /* ------------------------------------------------ Vendu a / Expedie a */

  const hauteurAdresse = 26;
  const largeurColonne = (DROITE - MARGE) / 2;
  cadre(doc, MARGE, y, largeurColonne, hauteurAdresse);
  cadre(doc, MARGE + largeurColonne, y, largeurColonne, hauteurAdresse);

  etiquette(doc, 'Vendu a', MARGE + 2, y + 4);
  const lignesClient = [
    client.nom,
    contact?.nom ?? '',
    client.ville,
    `Tel. : ${client.telephone}`,
  ].filter(Boolean);
  lignesClient.forEach((ligne, i) => valeur(doc, ligne, MARGE + 2, y + 9.5 + i * 4.2, 8.5));

  etiquette(doc, 'Expedie a', MARGE + largeurColonne + 2, y + 4);
  const lignesLivraison = [
    chantier.nom,
    sortie.expedieA || chantier.adresse,
    chantier.ville,
    contact?.telephone ? `Tel. : ${contact.telephone}` : '',
  ].filter(Boolean);
  lignesLivraison.forEach((ligne, i) =>
    valeur(doc, ligne, MARGE + largeurColonne + 2, y + 9.5 + i * 4.2, 8.5),
  );

  y += hauteurAdresse;

  /* --------------------------------------------- Bande administrative */

  const colonnesAdmin = [
    { titre: 'Bon de comm. client', texte: sortie.bonCommandeClient, largeur: 30 },
    { titre: '# comm. Alfa', texte: sortie.commandeAlfa, largeur: 24 },
    { titre: 'Representant', texte: sortie.representant, largeur: 32 },
    { titre: 'Date expediee', texte: formatDate(sortie.dateSortie), largeur: 28 },
    { titre: 'Expedie via', texte: sortie.expedieVia, largeur: 34 },
    { titre: 'Termes', texte: sortie.termes, largeur: DROITE - MARGE - 148 },
  ];

  const hauteurAdmin = 11;
  cadre(doc, MARGE, y, DROITE - MARGE, hauteurAdmin);
  doc.line(MARGE, y + 5, DROITE, y + 5);
  let xAdmin = MARGE;
  for (const colonne of colonnesAdmin) {
    if (xAdmin > MARGE) doc.line(xAdmin, y, xAdmin, y + hauteurAdmin);
    etiquette(doc, colonne.titre, xAdmin + 1.5, y + 3.6);
    valeur(doc, colonne.texte, xAdmin + 1.5, y + 9, 8);
    xAdmin += colonne.largeur;
  }

  y += hauteurAdmin + 3;

  /* ------------------------------------------------ Tableau des lignes */

  const colonnes = [
    { titre: 'Item Code', x: MARGE + 1.5, alignement: 'left' as const },
    { titre: "Type d'item", x: MARGE + 26, alignement: 'left' as const },
    { titre: 'No. de produit / Description', x: MARGE + 47, alignement: 'left' as const },
    { titre: 'U/M', x: MARGE + 128, alignement: 'left' as const },
    { titre: 'Qte comm.', x: MARGE + 160, alignement: 'right' as const },
    { titre: 'Qte expediee', x: MARGE + 179, alignement: 'right' as const },
    { titre: 'Qte a venir', x: DROITE - 1.5, alignement: 'right' as const },
  ];

  doc.setFillColor(242, 243, 244);
  doc.rect(MARGE, y, DROITE - MARGE, 7, 'F');
  cadre(doc, MARGE, y, DROITE - MARGE, 7);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.setTextColor(...GRIS);
  for (const colonne of colonnes) {
    doc.text(colonne.titre.toUpperCase(), colonne.x, y + 4.5, { align: colonne.alignement });
  }
  y += 7;

  const debutTableau = y;
  let totalExpedie = 0;
  let totalAVenir = 0;

  for (const ligne of sortie.lignes) {
    const produit = produits.find((p) => p.id === ligne.produitId);
    if (y > 232) {
      doc.addPage();
      y = MARGE;
    }
    totalExpedie += ligne.quantite;
    totalAVenir += ligne.quantiteAVenir;

    const description = doc.splitTextToSize(produit?.nom ?? ligne.produitId, 78) as string[];

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.2);
    doc.setTextColor(...ENCRE);
    doc.text(produit?.codeItem ?? '—', colonnes[0].x, y + 4.5);
    doc.text(ligne.typeItem === 'ACHAT' ? 'Achat' : 'Location', colonnes[1].x, y + 4.5);
    doc.text(description[0], colonnes[2].x, y + 4.5);
    doc.text(produit?.unite ?? 'unite', colonnes[3].x, y + 4.5);
    doc.text(String(ligne.quantiteCommandee), colonnes[4].x, y + 4.5, { align: 'right' });
    doc.setFont('helvetica', 'bold');
    doc.text(String(ligne.quantite), colonnes[5].x, y + 4.5, { align: 'right' });
    doc.setFont('helvetica', 'normal');

    // Le reliquat est mis en evidence : c'est ce que le client attend encore (RG-024).
    if (ligne.quantiteAVenir > 0) doc.setTextColor(...ROUGE);
    doc.text(String(ligne.quantiteAVenir), colonnes[6].x, y + 4.5, { align: 'right' });
    doc.setTextColor(...ENCRE);

    let hauteurLigne = 6.5;
    const complements: string[] = [];
    if (description.length > 1) complements.push(description.slice(1).join(' '));
    if (produit?.dimensions || produit?.couleur) {
      complements.push([produit?.dimensions, produit?.couleur].filter(Boolean).join(' · '));
    }
    if (ligne.note) complements.push(`Note : ${ligne.note}`);

    for (const complement of complements) {
      doc.setFontSize(7);
      doc.setTextColor(...GRIS);
      doc.text(complement, colonnes[2].x, y + hauteurLigne + 2.5);
      hauteurLigne += 3.6;
    }

    doc.setDrawColor(...LIGNE);
    doc.setLineWidth(0.15);
    doc.line(MARGE, y + hauteurLigne, DROITE, y + hauteurLigne);
    y += hauteurLigne;
  }

  cadre(doc, MARGE, debutTableau, DROITE - MARGE, y - debutTableau);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(...ENCRE);
  doc.text(`Total expedie : ${totalExpedie} unite(s)`, MARGE + 1.5, y + 5.5);
  if (totalAVenir > 0) {
    doc.setTextColor(...ROUGE);
    doc.text(`Reste a venir : ${totalAVenir} unite(s)`, DROITE, y + 5.5, { align: 'right' });
  }

  y += 11;

  /* ------------------------------------------------- LOCATION / ACHAT */

  if (y > 198) {
    doc.addPage();
    y = MARGE;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...ENCRE);
  doc.text('LOCATION / ACHAT', MARGE, y);
  y += 2.5;

  const hauteurConditions = 21;
  cadre(doc, MARGE, y, DROITE - MARGE, hauteurConditions);
  etiquette(doc, 'Commentaires', MARGE + 2, y + 4);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.4);
  doc.setTextColor(...ENCRE);
  let yCondition = y + 8;
  for (const condition of [CONDITIONS_BON.achat, CONDITIONS_BON.location, CONDITIONS_BON.transport]) {
    for (const l of doc.splitTextToSize(condition, DROITE - MARGE - 6) as string[]) {
      doc.text(l, MARGE + 2, yCondition);
      yCondition += 2.9;
    }
  }
  y += hauteurConditions + 2;

  const heures = [
    { titre: 'Hre arrivee', texte: sortie.heureArrivee },
    { titre: 'Hre commencee', texte: sortie.heureCommencee },
    { titre: 'Hre terminee', texte: sortie.heureTerminee },
  ];
  const largeurHeure = (DROITE - MARGE) / 3;
  cadre(doc, MARGE, y, DROITE - MARGE, 10);
  heures.forEach((heure, i) => {
    const x = MARGE + i * largeurHeure;
    if (i > 0) doc.line(x, y, x, y + 10);
    etiquette(doc, heure.titre, x + 2, y + 3.8);
    valeur(doc, heure.texte, x + 2, y + 8.2, 8.5);
  });
  y += 12;

  /* --------------------------------------------------------- Signatures */

  const hauteurSignature = 34;
  const largeurSignature = (DROITE - MARGE) / 2;
  cadre(doc, MARGE, y, largeurSignature, hauteurSignature);
  cadre(doc, MARGE + largeurSignature, y, largeurSignature, hauteurSignature);

  const blocSignature = (
    x: number,
    titre: string,
    nom: string,
    lettresMoulees: string,
    dataUrl: string | null,
    date: string | null,
  ) => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(...ENCRE);
    doc.text(titre, x + 2, y + 4.5);

    etiquette(doc, 'Signature', x + 2, y + 10);
    if (dataUrl) {
      try {
        doc.addImage(dataUrl, 'PNG', x + 22, y + 5.5, largeurSignature - 26, 12);
      } catch {
        valeur(doc, nom, x + 22, y + 12, 9);
      }
    }
    doc.setDrawColor(...LIGNE);
    doc.line(x + 21, y + 17.5, x + largeurSignature - 3, y + 17.5);

    etiquette(doc, 'Lettres moulees', x + 2, y + 23);
    valeur(doc, lettresMoulees, x + 30, y + 23, 8.5);
    doc.line(x + 29, y + 24, x + largeurSignature - 3, y + 24);

    etiquette(doc, 'Date', x + 2, y + 30);
    valeur(doc, date ? formatDate(date) : '', x + 30, y + 30, 8.5);
    doc.line(x + 29, y + 31, x + largeurSignature - 3, y + 31);
  };

  blocSignature(
    MARGE,
    'CLIENT',
    sortie.signataireNom,
    sortie.signataireLettresMoulees,
    sortie.signatureDataUrl,
    sortie.dateSignature,
  );
  blocSignature(
    MARGE + largeurSignature,
    'REPRESENTANT ALFA',
    sortie.representantSignatureNom || sortie.representant,
    (sortie.representantSignatureNom || sortie.representant).toUpperCase(),
    sortie.representantSignatureDataUrl,
    sortie.dateSortie,
  );

  y += hauteurSignature + 4;

  /* ------------------------------------------------------------- Pied */

  doc.setFontSize(6.4);
  doc.setTextColor(...GRIS);
  doc.text(
    `Prepare par : ${preparateur?.nom ?? '—'}   ·   Livreur : ${sortie.livreur || '—'}   ·   Reference demande : ${referenceDemande}`,
    MARGE,
    y,
  );
  doc.text(`Imprime le ${formatDateHeure(new Date().toISOString())}`, MARGE, y + 3.4);
  doc.text(
    'Document produit par ALFA Flow (demonstrateur). La signature electronique presentee est une simulation de demonstration et ne constitue pas',
    MARGE,
    y + 7.6,
  );
  doc.text(
    "un dispositif de signature juridiquement qualifie. Gabarit reconstitue d'apres le bon papier Groupe Alfa, en attente du gabarit officiel.",
    MARGE,
    y + 10.6,
  );

  return doc;
}

export function telechargerBon(donnees: DonneesBon): void {
  construireBonLivraison(donnees).save(`${donnees.sortie.numero}.pdf`);
}

export function apercuBon(donnees: DonneesBon): string {
  return construireBonLivraison(donnees).output('datauristring');
}

export function imprimerBon(donnees: DonneesBon): void {
  const doc = construireBonLivraison(donnees);
  doc.autoPrint();
  const url = doc.output('bloburl');
  window.open(url as unknown as string, '_blank');
}
