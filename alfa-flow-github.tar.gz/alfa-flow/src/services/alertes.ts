import type { Alerte, EtatDonnees, EtatStock } from '../models/types';
import { LIBELLE_ALERTE } from '../models/referentiel';
import { SEUIL_DOSSIER_BLOQUE_HEURES, SEUIL_STOCK_DORMANT_JOURS } from '../models/referentiel';
import { aujourdHui, ecartJours, somme } from '../utils';
import { quantiteRestante } from './operations';

/**
 * Les alertes ne sont pas stockees : elles sont derivees de l'etat courant.
 * L'identifiant est deterministe (type + entite), ce qui garantit qu'un meme
 * evenement ne genere jamais deux alertes.
 */
export function deriverAlertes(
  etat: EtatDonnees,
  stocks: Map<string, EtatStock>,
  date: string = aujourdHui(),
): Alerte[] {
  const alertes: Alerte[] = [];
  const pousser = (a: Omit<Alerte, 'dateHeure'> & { dateHeure?: string }) => {
    if (alertes.some((x) => x.id === a.id)) return;
    alertes.push({ ...a, dateHeure: a.dateHeure ?? `${date}T08:00:00.000Z` });
  };
  const nomClient = (clientId: string) => etat.clients.find((c) => c.id === clientId)?.nom ?? '—';

  // Stock sous le seuil
  for (const produit of etat.produits) {
    const stock = stocks.get(produit.id);
    if (!stock || stock.disponible >= produit.seuilAlerte) continue;
    pousser({
      id: `STOCK_SOUS_SEUIL:${produit.id}`,
      type: 'STOCK_SOUS_SEUIL',
      severite: stock.disponible === 0 ? 'CRITIQUE' : 'ATTENTION',
      titre: LIBELLE_ALERTE.STOCK_SOUS_SEUIL,
      message: `${produit.nom} : ${stock.disponible} disponible(s) pour un seuil de ${produit.seuilAlerte}.`,
      entiteType: 'produit',
      entiteId: produit.id,
      lien: `/catalogue/${produit.id}`,
    });
  }

  // Demandes en attente dont une ligne depasse le disponible
  for (const demande of etat.demandes) {
    if (demande.statut !== 'A_VERIFIER' && demande.statut !== 'SOUMISE') continue;
    for (const ligne of demande.lignes) {
      const stock = stocks.get(ligne.produitId);
      if (!stock || ligne.quantiteDemandee <= stock.disponible) continue;
      const produit = etat.produits.find((p) => p.id === ligne.produitId);
      pousser({
        id: `DEMANDE_SUPERIEURE_DISPONIBLE:${demande.id}:${ligne.id}`,
        type: 'DEMANDE_SUPERIEURE_DISPONIBLE',
        severite: 'ATTENTION',
        titre: LIBELLE_ALERTE.DEMANDE_SUPERIEURE_DISPONIBLE,
        message: `${demande.numero} — ${produit?.nom ?? ligne.produitId} : ${ligne.quantiteDemandee} demande(s) pour ${stock.disponible} disponible(s).`,
        entiteType: 'demande',
        entiteId: demande.id,
        lien: `/demandes/${demande.id}`,
      });
    }
  }

  // Preparations incompletes ou bloquees
  for (const preparation of etat.preparations) {
    if (preparation.statut !== 'PARTIELLEMENT_PREPAREE' && preparation.statut !== 'BLOQUEE') continue;
    pousser({
      id: `PREPARATION_INCOMPLETE:${preparation.id}`,
      type: 'PREPARATION_INCOMPLETE',
      severite: preparation.statut === 'BLOQUEE' ? 'CRITIQUE' : 'ATTENTION',
      titre: LIBELLE_ALERTE.PREPARATION_INCOMPLETE,
      message: `${preparation.numero} : ${somme(preparation.lignes, (l) => l.quantitePreparee)} unite(s) preparee(s) sur ${somme(preparation.lignes, (l) => l.quantiteConfirmee)}.`,
      entiteType: 'preparation',
      entiteId: preparation.id,
      lien: `/preparations/${preparation.id}`,
    });
  }

  // Bons livres non signes
  for (const sortie of etat.sorties) {
    if (sortie.statut === 'SIGNEE' || sortie.statut === 'SORTIE_CONFIRMEE') continue;
    if (sortie.statut !== 'LIVREE' && sortie.statut !== 'SIGNATURE_EN_ATTENTE') continue;
    pousser({
      id: `BON_NON_SIGNE:${sortie.id}`,
      type: 'BON_NON_SIGNE',
      severite: 'ATTENTION',
      titre: LIBELLE_ALERTE.BON_NON_SIGNE,
      message: `${sortie.numero} — ${nomClient(sortie.clientId)} : la confirmation de reception n a pas encore ete recue.`,
      entiteType: 'sortie',
      entiteId: sortie.id,
      lien: `/livraisons/${sortie.id}`,
    });
  }

  // Retours prochains, en retard, partiels
  for (const location of etat.locations) {
    if (location.statut === 'CLOTUREE') continue;
    const reste = somme(location.lignes, quantiteRestante);
    if (reste <= 0) continue;
    const jours = ecartJours(location.retourAttendu, date);
    if (jours < 0) {
      pousser({
        id: `RETOUR_EN_RETARD:${location.id}`,
        type: 'RETOUR_EN_RETARD',
        severite: 'CRITIQUE',
        titre: LIBELLE_ALERTE.RETOUR_EN_RETARD,
        message: `${location.numero} — ${nomClient(location.clientId)} : retour attendu depuis ${Math.abs(jours)} jour(s), ${reste} unite(s) encore chez le client.`,
        entiteType: 'location',
        entiteId: location.id,
        lien: `/locations/${location.id}`,
      });
    } else if (jours <= 3) {
      pousser({
        id: `RETOUR_PROCHAIN:${location.id}`,
        type: 'RETOUR_PROCHAIN',
        severite: 'INFO',
        titre: LIBELLE_ALERTE.RETOUR_PROCHAIN,
        message: `${location.numero} — ${nomClient(location.clientId)} : retour attendu dans ${jours} jour(s).`,
        entiteType: 'location',
        entiteId: location.id,
        lien: `/locations/${location.id}`,
      });
    }
    if (location.statut === 'RETOUR_PARTIEL') {
      pousser({
        id: `RETOUR_PARTIEL:${location.id}`,
        type: 'RETOUR_PARTIEL',
        severite: 'ATTENTION',
        titre: LIBELLE_ALERTE.RETOUR_PARTIEL,
        message: `${location.numero} — ${nomClient(location.clientId)} : ${reste} unite(s) restent a recuperer.`,
        entiteType: 'location',
        entiteId: location.id,
        lien: `/locations/${location.id}`,
      });
    }
  }

  // Ecarts non resolus
  for (const ecart of etat.ecarts) {
    if (ecart.decision === 'RESOLU' || ecart.decision === 'ABANDONNE') continue;
    const produit = etat.produits.find((p) => p.id === ecart.produitId);
    pousser({
      id: `ECART_DETECTE:${ecart.id}`,
      type: ecart.type === 'ENDOMMAGE' ? 'MATERIEL_ENDOMMAGE' : 'ECART_DETECTE',
      severite: ecart.type === 'CONTESTE' ? 'CRITIQUE' : 'ATTENTION',
      titre: ecart.type === 'ENDOMMAGE' ? LIBELLE_ALERTE.MATERIEL_ENDOMMAGE : LIBELLE_ALERTE.ECART_DETECTE,
      message: `${ecart.numero} — ${nomClient(ecart.clientId)} : ${ecart.quantite} × ${produit?.nom ?? ecart.produitId}.`,
      entiteType: 'ecart',
      entiteId: ecart.id,
      lien: `/ecarts`,
    });
  }

  // RG-030 — stock dormant : aucun mouvement au-dela du seuil de jours.
  const dernierMouvement = new Map<string, string>();
  for (const mvt of etat.mouvements) {
    const precedent = dernierMouvement.get(mvt.produitId);
    if (!precedent || mvt.dateHeure > precedent) dernierMouvement.set(mvt.produitId, mvt.dateHeure);
  }
  for (const produit of etat.produits) {
    const derniere = dernierMouvement.get(produit.id);
    if (!derniere) continue;
    const jours = ecartJours(date, derniere.slice(0, 10));
    if (jours < SEUIL_STOCK_DORMANT_JOURS) continue;
    pousser({
      id: `STOCK_DORMANT:${produit.id}`,
      type: 'STOCK_DORMANT',
      severite: 'INFO',
      titre: LIBELLE_ALERTE.STOCK_DORMANT,
      message: `${produit.nom} : aucun mouvement depuis ${jours} jours (seuil : ${SEUIL_STOCK_DORMANT_JOURS} jours).`,
      entiteType: 'produit',
      entiteId: produit.id,
      lien: `/catalogue/${produit.id}`,
    });
  }

  // Dossier bloque depuis plus de 24 heures.
  for (const preparation of etat.preparations) {
    if (preparation.statut !== 'BLOQUEE') continue;
    const heures = Math.round(
      (new Date(`${date}T12:00:00.000Z`).getTime() - new Date(preparation.dateCreation).getTime()) / 3600000,
    );
    if (heures < SEUIL_DOSSIER_BLOQUE_HEURES) continue;
    pousser({
      id: `DOSSIER_BLOQUE:${preparation.id}`,
      type: 'DOSSIER_BLOQUE',
      severite: 'CRITIQUE',
      titre: LIBELLE_ALERTE.DOSSIER_BLOQUE,
      message: `${preparation.numero} : dossier bloque depuis ${heures} heures.`,
      entiteType: 'preparation',
      entiteId: preparation.id,
      lien: `/preparations/${preparation.id}`,
    });
  }

  // Ajustements sensibles (au-dela de 10 unites)
  for (const mvt of etat.mouvements) {
    if (mvt.type !== 'AJUSTEMENT' || Math.abs(mvt.quantite) < 10) continue;
    const produit = etat.produits.find((p) => p.id === mvt.produitId);
    pousser({
      id: `AJUSTEMENT_SENSIBLE:${mvt.id}`,
      type: 'AJUSTEMENT_SENSIBLE',
      severite: 'ATTENTION',
      titre: LIBELLE_ALERTE.AJUSTEMENT_SENSIBLE,
      message: `${produit?.nom ?? mvt.produitId} : ajustement de ${mvt.quantite > 0 ? '+' : ''}${mvt.quantite} unite(s). Motif : ${mvt.motif ?? '—'}.`,
      entiteType: 'produit',
      entiteId: mvt.produitId,
      lien: `/catalogue/${mvt.produitId}`,
      dateHeure: mvt.dateHeure,
    });
  }

  const rang = { CRITIQUE: 0, ATTENTION: 1, INFO: 2 };
  return alertes.sort((a, b) => rang[a.severite] - rang[b.severite] || a.titre.localeCompare(b.titre));
}
