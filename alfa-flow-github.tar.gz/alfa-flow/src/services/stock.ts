import type { EtatStock, Mouvement, Produit, ResultatRegle, TypeMouvement } from '../models/types';

/**
 * Regle fondamentale : le stock n'est jamais un nombre librement modifiable.
 * Tout etat de stock est le resultat du repli (fold) du registre de mouvements.
 *
 * Convention de signe : `Mouvement.quantite` porte la magnitude du deplacement
 * (toujours > 0), sauf AJUSTEMENT qui est signe. Le sens applique a chaque
 * compartiment est defini une seule fois ci-dessous.
 */

interface EffetMouvement {
  physique: number;
  reserve: number;
  enPreparation: number;
  enCirculation: number;
  endommage: number;
}

const NUL: EffetMouvement = {
  physique: 0,
  reserve: 0,
  enPreparation: 0,
  enCirculation: 0,
  endommage: 0,
};

/** Effet unitaire (pour une quantite de 1) de chaque type de mouvement. */
export const EFFETS_MOUVEMENT: Record<TypeMouvement, EffetMouvement> = {
  // Entree initiale de l'inventaire.
  STOCK_INITIAL: { ...NUL, physique: 1 },
  // Engagement d'une quantite au profit d'une demande approuvee.
  RESERVATION: { ...NUL, reserve: 1 },
  LIBERATION_RESERVATION: { ...NUL, reserve: -1 },
  // Changement d'emplacement : sans effet sur les compartiments.
  TRANSFERT_INTERNE: { ...NUL },
  // La quantite quitte la reserve pour la zone de preparation ; elle est
  // toujours physiquement presente dans la cour.
  PREPARATION: { ...NUL, reserve: -1, enPreparation: 1 },
  // Sortie reelle : le materiel quitte la cour et entre en circulation.
  SORTIE: { ...NUL, enPreparation: -1, physique: -1, enCirculation: 1 },
  // Vente ferme : le materiel quitte definitivement le parc et n'est jamais
  // attendu au retour. Il ne rejoint donc pas le stock en circulation.
  VENTE: { ...NUL, enPreparation: -1, physique: -1 },
  // Retour accepte : le materiel revient et redevient disponible.
  RETOUR_ACCEPTE: { ...NUL, enCirculation: -1, physique: 1 },
  // Materiel interne bloque (controle, nettoyage, expertise).
  QUARANTAINE: { ...NUL, endommage: 1 },
  // Retour endommage : present physiquement mais bloque.
  DOMMAGE: { ...NUL, enCirculation: -1, physique: 1, endommage: 1 },
  // Quantite declaree perdue chez le client : sort definitivement du parc.
  PERTE: { ...NUL, enCirculation: -1 },
  // RG-027 : le rebut sort du patrimoine (contrairement au materiel endommage).
  REBUT: { ...NUL, physique: -1, endommage: -1 },
  // RG-029 : entree de la reference reellement recue lors d'une substitution.
  SUBSTITUTION_ENTREE: { ...NUL, physique: 1 },
  // Section 12.3 : surplus recu sans origine identifiee, entre bloque en quarantaine.
  EXCEDENT_QUARANTAINE: { ...NUL, physique: 1, endommage: 1 },
  // Ecriture compensatoire signee, toujours motivee.
  AJUSTEMENT: { ...NUL, physique: 1 },
};

export function etatStockVide(produitId: string): EtatStock {
  return {
    produitId,
    physique: 0,
    reserve: 0,
    enPreparation: 0,
    enCirculation: 0,
    endommage: 0,
    disponible: 0,
    theorique: 0,
  };
}

function finaliser(etat: EtatStock): EtatStock {
  etat.disponible = etat.physique - etat.reserve - etat.enPreparation - etat.endommage;
  etat.theorique = etat.physique + etat.enCirculation;
  return etat;
}

/** Replie le registre complet et retourne l'etat de stock de chaque produit. */
export function calculerStock(produits: Produit[], mouvements: Mouvement[]): Map<string, EtatStock> {
  const etats = new Map<string, EtatStock>();
  for (const produit of produits) etats.set(produit.id, etatStockVide(produit.id));

  for (const mouvement of mouvements) {
    let etat = etats.get(mouvement.produitId);
    if (!etat) {
      etat = etatStockVide(mouvement.produitId);
      etats.set(mouvement.produitId, etat);
    }
    const effet = EFFETS_MOUVEMENT[mouvement.type];
    const q = mouvement.quantite;
    etat.physique += effet.physique * q;
    etat.reserve += effet.reserve * q;
    etat.enPreparation += effet.enPreparation * q;
    etat.enCirculation += effet.enCirculation * q;
    etat.endommage += effet.endommage * q;
  }

  for (const etat of etats.values()) finaliser(etat);
  return etats;
}

/** Etat de stock d'un seul produit (pratique pour les vues de detail). */
export function calculerStockProduit(produitId: string, mouvements: Mouvement[]): EtatStock {
  const etat = etatStockVide(produitId);
  for (const mouvement of mouvements) {
    if (mouvement.produitId !== produitId) continue;
    const effet = EFFETS_MOUVEMENT[mouvement.type];
    const q = mouvement.quantite;
    etat.physique += effet.physique * q;
    etat.reserve += effet.reserve * q;
    etat.enPreparation += effet.enPreparation * q;
    etat.enCirculation += effet.enCirculation * q;
    etat.endommage += effet.endommage * q;
  }
  return finaliser(etat);
}

/**
 * Quantite signee du mouvement telle qu'elle doit apparaitre dans le registre
 * et les exports : effet net sur le stock physique interne.
 */
export function quantiteSignee(mouvement: Mouvement): number {
  return EFFETS_MOUVEMENT[mouvement.type].physique * mouvement.quantite;
}

/* -------------------------------------------------------------- Controles */

export interface DemandeQuantite {
  produitId: string;
  nom: string;
  quantite: number;
}

/**
 * Verifie qu'une reservation ou une sortie ne depasse pas le disponible.
 * Retourne un message explicite, jamais un simple booleen.
 */
export function verifierDisponibilite(
  lignes: DemandeQuantite[],
  etats: Map<string, EtatStock>,
): ResultatRegle {
  const details: string[] = [];
  for (const ligne of lignes) {
    const etat = etats.get(ligne.produitId) ?? etatStockVide(ligne.produitId);
    if (ligne.quantite > etat.disponible) {
      details.push(
        `${ligne.nom} : ${ligne.quantite} unite(s) demandee(s) alors que ${etat.disponible} unite(s) sont disponibles.`,
      );
    }
  }
  if (details.length > 0) {
    return {
      ok: false,
      message: `Quantite superieure au stock disponible sur ${details.length} ligne(s).`,
      details,
    };
  }
  return { ok: true };
}

/** Aucun compartiment ne doit pouvoir devenir negatif silencieusement. */
export function verifierCoherence(etat: EtatStock): ResultatRegle {
  const details: string[] = [];
  if (etat.physique < 0) details.push('Stock physique negatif.');
  if (etat.reserve < 0) details.push('Stock reserve negatif.');
  if (etat.enPreparation < 0) details.push('Stock en preparation negatif.');
  if (etat.enCirculation < 0) details.push('Stock en circulation negatif.');
  if (etat.endommage < 0) details.push('Stock endommage negatif.');
  return details.length === 0
    ? { ok: true }
    : { ok: false, message: 'Etat de stock incoherent.', details };
}

/**
 * Simule l'application de mouvements avant de les enregistrer.
 * Toute incoherence bloque l'operation et explique la cause.
 */
export function simulerMouvements(
  mouvementsExistants: Mouvement[],
  nouveaux: Mouvement[],
  produits: Produit[],
): ResultatRegle<Map<string, EtatStock>> {
  const etats = calculerStock(produits, [...mouvementsExistants, ...nouveaux]);
  const details: string[] = [];
  const touches = new Set(nouveaux.map((m) => m.produitId));
  for (const produitId of touches) {
    const etat = etats.get(produitId);
    if (!etat) continue;
    const controle = verifierCoherence(etat);
    if (!controle.ok) {
      const nom = produits.find((p) => p.id === produitId)?.nom ?? produitId;
      details.push(`${nom} : ${(controle.details ?? []).join(' ')}`);
    }
  }
  if (details.length > 0) {
    return {
      ok: false,
      message: "L'operation genererait un stock negatif.",
      details,
    };
  }
  return { ok: true, valeur: etats };
}

/** Agregation utilisee par le graphique du tableau de bord. */
export function agregerStock(etats: Map<string, EtatStock>) {
  const total = {
    disponible: 0,
    reserve: 0,
    enPreparation: 0,
    enCirculation: 0,
    endommage: 0,
    physique: 0,
    theorique: 0,
  };
  for (const etat of etats.values()) {
    total.disponible += etat.disponible;
    total.reserve += etat.reserve;
    total.enPreparation += etat.enPreparation;
    total.enCirculation += etat.enCirculation;
    total.endommage += etat.endommage;
    total.physique += etat.physique;
    total.theorique += etat.theorique;
  }
  return total;
}

export function produitsSousSeuil(produits: Produit[], etats: Map<string, EtatStock>): Produit[] {
  return produits.filter((p) => {
    const etat = etats.get(p.id);
    return etat ? etat.disponible < p.seuilAlerte : false;
  });
}
