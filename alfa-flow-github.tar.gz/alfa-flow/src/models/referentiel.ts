import type {
  CategoriePreuve,
  DecisionEcart,
  EtatArticle,
  StatutRetour,
  Permission,
  Role,
  StatutDemande,
  StatutLocation,
  StatutPreparation,
  StatutSortie,
  TypeAlerte,
  TypeEcart,
  TypeMouvement,
} from './types';

/* ------------------------------------------------------------- Libelles */

export const LIBELLE_ROLE: Record<Role, string> = {
  ADMIN: 'Administrateur principal',
  COUR: 'Responsable de cour',
  SECRETARIAT: 'Secretariat',
  DIRECTION: 'Direction',
};

export const LIBELLE_STATUT_DEMANDE: Record<StatutDemande, string> = {
  BROUILLON: 'Brouillon',
  SOUMISE: 'Soumise',
  A_VERIFIER: 'A verifier',
  APPROUVEE: 'Approuvee',
  REFUSEE: 'Refusee',
  ANNULEE: 'Annulee',
};

export const LIBELLE_STATUT_PREPARATION: Record<StatutPreparation, string> = {
  A_PREPARER: 'A preparer',
  EN_PREPARATION: 'En preparation',
  PARTIELLEMENT_PREPAREE: 'Partiellement preparee',
  PRETE: 'Prete',
  BLOQUEE: 'Bloquee',
};

export const LIBELLE_STATUT_SORTIE: Record<StatutSortie, string> = {
  PRETE_A_SORTIR: 'Prete a sortir',
  SORTIE_CONFIRMEE: 'Sortie confirmee',
  EN_LIVRAISON: 'En livraison',
  LIVREE: 'Livree',
  SIGNATURE_EN_ATTENTE: 'Signature en attente',
  SIGNEE: 'Signee',
};

export const LIBELLE_STATUT_LOCATION: Record<StatutLocation, string> = {
  ACTIVE: 'Active',
  RETOUR_ATTENDU: 'Retour attendu',
  EN_RETARD: 'En retard',
  RETOUR_PARTIEL: 'Retour partiel',
  EN_LITIGE: 'En litige',
  CLOTUREE: 'Cloturee',
};

export const LIBELLE_DECISION_ECART: Record<DecisionEcart, string> = {
  A_VERIFIER: 'A verifier',
  ACCEPTE: 'Accepte',
  A_FACTURER: 'A facturer',
  REMPLACEMENT_ATTENDU: 'Remplacement attendu',
  ABANDONNE: 'Abandonne avec justification',
  EN_LITIGE: 'En litige',
  RESOLU: 'Resolu',
};

export const LIBELLE_TYPE_ECART: Record<TypeEcart, string> = {
  MANQUANT: 'Quantite manquante',
  ENDOMMAGE: 'Materiel endommage',
  CONTESTE: 'Quantite contestee',
  EXCEDENT: 'Excedent recu',
  REFERENCE_NON_CONFORME: 'Reference non conforme',
};

export const LIBELLE_MOUVEMENT: Record<TypeMouvement, string> = {
  STOCK_INITIAL: 'Stock initial',
  RESERVATION: 'Reservation',
  LIBERATION_RESERVATION: 'Liberation de reservation',
  TRANSFERT_INTERNE: 'Transfert interne',
  PREPARATION: 'Preparation',
  SORTIE: 'Sortie en location',
  VENTE: 'Sortie par vente',
  RETOUR_ACCEPTE: 'Retour accepte',
  QUARANTAINE: 'Mise en quarantaine',
  DOMMAGE: 'Dommage',
  PERTE: 'Perte',
  REBUT: 'Rebut',
  SUBSTITUTION_ENTREE: 'Entree par substitution',
  EXCEDENT_QUARANTAINE: 'Excedent non attribue en quarantaine',
  AJUSTEMENT: 'Ajustement compensatoire',
};

/** F2 — cycle de vie du retour. */
export const LIBELLE_STATUT_RETOUR: Record<StatutRetour, string> = {
  COMMENCE: 'Retour commence',
  COMPTAGE: 'Comptage en cours',
  ECART_DETECTE: 'Ecart detecte',
  VERIFICATION: 'Verification',
  ACCEPTE: 'Accepte',
  CLOTURE: 'Cloture',
  ANNULE: 'Annule',
};

/** Section 12.1, etape 3 — qualification du materiel recu. */
export const LIBELLE_ETAT_ARTICLE: Record<EtatArticle, string> = {
  BON: 'Bon',
  A_INSPECTER: 'A inspecter',
  A_REPARER: 'A reparer',
  ENDOMMAGE: 'Endommage',
  REBUT: 'Rebut',
  REFERENCE_NON_CONFORME: 'Reference non conforme',
};

/** DATA-014 — categories de preuve. */
export const LIBELLE_PREUVE: Record<CategoriePreuve, string> = {
  AVANT_DEPART: 'Avant depart',
  CHARGEMENT: 'Chargement',
  LIVRAISON: 'Livraison',
  SIGNATURE_PAPIER: 'Signature papier',
  RETOUR: 'Retour',
  DOMMAGE: 'Dommage',
  ARTICLE_MANQUANT: 'Article manquant',
  CORRECTION_INVENTAIRE: 'Correction d inventaire',
};

export const LIBELLE_ALERTE: Record<TypeAlerte, string> = {
  STOCK_SOUS_SEUIL: 'Stock sous le seuil',
  DEMANDE_SUPERIEURE_DISPONIBLE: 'Demande superieure au disponible',
  PREPARATION_INCOMPLETE: 'Preparation incomplete',
  BON_NON_SIGNE: 'Bon de livraison non signe',
  RETOUR_PROCHAIN: 'Retour prochain',
  RETOUR_EN_RETARD: 'Retour en retard',
  RETOUR_PARTIEL: 'Retour partiel',
  ECART_DETECTE: 'Ecart detecte',
  MATERIEL_ENDOMMAGE: 'Materiel endommage',
  DOCUMENT_MANQUANT: 'Document manquant',
  AJUSTEMENT_SENSIBLE: 'Modification sensible',
  DOSSIER_BLOQUE: 'Dossier bloque',
  STOCK_DORMANT: 'Stock dormant',
};

/* ---------------------------------------------------------- Permissions */

const LECTURE_COMMUNE: Permission[] = [
  'catalogue.lire',
  'stock.lire',
  'demande.lire',
  'preparation.lire',
  'location.lire',
];

export const PERMISSIONS_PAR_ROLE: Record<Role, Permission[]> = {
  ADMIN: [
    ...LECTURE_COMMUNE,
    'stock.ajuster',
    'demande.creer',
    'demande.approuver',
    'preparation.executer',
    'sortie.confirmer',
    'bon.generer',
    'retour.executer',
    'ecart.decider',
    'client.gerer',
    'rapport.lire',
    'journal.lire',
    'admin.gerer',
  ],
  COUR: [...LECTURE_COMMUNE, 'preparation.executer', 'sortie.confirmer', 'retour.executer'],
  SECRETARIAT: [
    ...LECTURE_COMMUNE,
    'demande.creer',
    'demande.approuver',
    'bon.generer',
    'client.gerer',
    'rapport.lire',
  ],
  DIRECTION: [
    ...LECTURE_COMMUNE,
    'stock.ajuster',
    'ecart.decider',
    'rapport.lire',
    'journal.lire',
  ],
};

export function peut(role: Role, permission: Permission): boolean {
  return PERMISSIONS_PAR_ROLE[role].includes(permission);
}

/* --------------------------------------------------------- Transitions */

export const TRANSITIONS_DEMANDE: Record<StatutDemande, StatutDemande[]> = {
  BROUILLON: ['SOUMISE', 'ANNULEE'],
  SOUMISE: ['A_VERIFIER', 'ANNULEE'],
  A_VERIFIER: ['APPROUVEE', 'REFUSEE', 'ANNULEE'],
  APPROUVEE: ['ANNULEE'],
  REFUSEE: [],
  ANNULEE: [],
};

export const TRANSITIONS_PREPARATION: Record<StatutPreparation, StatutPreparation[]> = {
  A_PREPARER: ['EN_PREPARATION', 'BLOQUEE'],
  EN_PREPARATION: ['PARTIELLEMENT_PREPAREE', 'PRETE', 'BLOQUEE'],
  PARTIELLEMENT_PREPAREE: ['EN_PREPARATION', 'PRETE', 'BLOQUEE'],
  PRETE: ['EN_PREPARATION'],
  BLOQUEE: ['EN_PREPARATION'],
};

export const TRANSITIONS_SORTIE: Record<StatutSortie, StatutSortie[]> = {
  PRETE_A_SORTIR: ['SORTIE_CONFIRMEE'],
  SORTIE_CONFIRMEE: ['EN_LIVRAISON'],
  EN_LIVRAISON: ['LIVREE'],
  LIVREE: ['SIGNATURE_EN_ATTENTE', 'SIGNEE'],
  SIGNATURE_EN_ATTENTE: ['SIGNEE'],
  SIGNEE: [],
};

export const TRANSITIONS_LOCATION: Record<StatutLocation, StatutLocation[]> = {
  ACTIVE: ['RETOUR_ATTENDU', 'RETOUR_PARTIEL', 'EN_RETARD', 'CLOTUREE', 'EN_LITIGE'],
  RETOUR_ATTENDU: ['RETOUR_PARTIEL', 'EN_RETARD', 'CLOTUREE', 'EN_LITIGE'],
  EN_RETARD: ['RETOUR_PARTIEL', 'CLOTUREE', 'EN_LITIGE'],
  RETOUR_PARTIEL: ['EN_RETARD', 'CLOTUREE', 'EN_LITIGE'],
  EN_LITIGE: ['CLOTUREE'],
  CLOTUREE: [],
};

export const TRANSITIONS_RETOUR: Record<StatutRetour, StatutRetour[]> = {
  COMMENCE: ['COMPTAGE', 'ANNULE'],
  COMPTAGE: ['ECART_DETECTE', 'ACCEPTE', 'ANNULE'],
  ECART_DETECTE: ['VERIFICATION', 'ANNULE'],
  VERIFICATION: ['ACCEPTE', 'ANNULE'],
  ACCEPTE: ['CLOTURE'],
  CLOTURE: [],
  ANNULE: [],
};

/**
 * Section 8.2 — typologie des emplacements du depot de Sainte-Sophie.
 * Les emplacements internes et externes ne se somment jamais dans un meme indicateur.
 */
export const EMPLACEMENTS_INTERNES = [
  'Cour - Zone A - Rangee 1',
  'Cour - Zone A - Rangee 2',
  'Cour - Zone B - Rangee 1',
  'Cour - Zone B - Rangee 2',
  'Entrepot - Zone 1 - Rangee A',
  'Entrepot - Zone 1 - Rangee B',
  'Entrepot - Zone 2 - Rangee A',
  'Zone de preparation',
  'Zone de retour',
  'Quarantaine',
  'Reparation',
] as const;

export const EMPLACEMENTS_EXTERNES = [
  'Vehicule de livraison',
  'Chez le client',
  'Sur le chantier',
] as const;

export function estEmplacementInterne(emplacement: string | null): boolean {
  return emplacement !== null && (EMPLACEMENTS_INTERNES as readonly string[]).includes(emplacement);
}


/**
 * Entite emettrice, relevee sur le bon de livraison papier fourni le 4 aout 2026.
 * Groupe Alfa est la marque commerciale ; l'entite legale figurant sur les documents
 * est 9184-9745 Quebec inc.
 */
export const ORGANISATION = {
  marque: 'Groupe Alfa',
  raisonSociale: '9184-9745 Quebec inc.',
  adresse: '2647 boul. Sainte-Sophie',
  ville: 'Sainte-Sophie, QC J5J 2V3',
  telephone: '514-919-ALFA (2532)',
  telecopieur: '450-508-1148',
  descripteur: "Produits de coffrage et d'echafaudage",
  descripteurEn: 'Forming and scaffolding products',
} as const;

/** Conditions imprimees au bas du bon papier, reprises mot pour mot. */
export const CONDITIONS_BON = {
  achat:
    "ACHAT : le materiel demeure la propriete de 9184-9745 Quebec inc. jusqu'a paiement complet. Frais pour tout racks, boites en bois et/ou plywood et/ou metal, palette et cages non retournes.",
  location:
    'LOCATION : minimum 28 jours. Le materiel demeure la propriete de 9184-9745 Quebec inc. Frais pour tout racks, boites en bois et/ou plywood et/ou metal, palette et cages non retournes.',
  transport:
    "Groupe Alfa n'est pas responsable du chargement et du poids sur les camions.",
} as const;

/** Duree minimale de location relevee sur le bon papier : 28 jours. */
export const DUREE_LOCATION_MINIMALE_JOURS = 28;

export const TERMES_DEFAUT = 'Net 30 jours';

/**
 * Numerotation des bons : le format papier existant est « L-##### » en sequence
 * continue (dernier bon observe : L-18203, 4 aout 2026). La sequence se poursuit
 * plutot que de repartir a zero, afin d'eviter tout doublon avec l'historique papier.
 */
export const PREFIXE_BON = 'L';
export const DERNIER_BON_PAPIER = 18203;

export const LIBELLE_TYPE_ITEM: Record<'LOCATION' | 'ACHAT', string> = {
  LOCATION: 'Location',
  ACHAT: 'Achat',
};

/** SEC-003 — au-dela de ce seuil, un ajustement exige la validation d'un role superieur. */
export const SEUIL_VALIDATION_AJUSTEMENT = 25;

/** RG-030 — nombre de jours sans mouvement au-dela duquel un article est signale dormant. */
export const SEUIL_STOCK_DORMANT_JOURS = 120;

/** Alerte « dossier bloque » : nombre d'heures avant declenchement. */
export const SEUIL_DOSSIER_BLOQUE_HEURES = 24;
