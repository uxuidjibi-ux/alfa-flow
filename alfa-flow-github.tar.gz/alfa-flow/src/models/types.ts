/**
 * Modele metier ALFA Flow.
 * Aucun import externe : ce fichier doit rester utilisable par les tests unitaires
 * et par une future couche serveur (Supabase / PostgreSQL) sans modification.
 */

/* ------------------------------------------------------------------ Roles */

export type Role = 'ADMIN' | 'COUR' | 'SECRETARIAT' | 'DIRECTION';

/** Le signataire externe n'a pas de compte : il agit par lien simule (BF-003, SEC-004). */
export type RoleExterne = 'CLIENT_SIGNATAIRE';

export interface Utilisateur {
  id: string;
  nom: string;
  role: Role;
  fonction: string;
  actif: boolean;
}

export type Permission =
  | 'catalogue.lire'
  | 'stock.lire'
  | 'stock.ajuster'
  | 'demande.lire'
  | 'demande.creer'
  | 'demande.approuver'
  | 'preparation.lire'
  | 'preparation.executer'
  | 'sortie.confirmer'
  | 'bon.generer'
  | 'location.lire'
  | 'retour.executer'
  | 'ecart.decider'
  | 'client.gerer'
  | 'rapport.lire'
  | 'journal.lire'
  | 'admin.gerer';

/* --------------------------------------------------------------- Produits */

export type Unite = 'unite' | 'paire' | 'ensemble' | 'metre';

/** Ligne de location ou de vente ferme (colonne « Type d'item » du bon Alfa). */
export type TypeItem = 'LOCATION' | 'ACHAT';

export interface Produit {
  id: string;
  /** Code article Alfa tel qu'il figure sur les bons (ex. 900605, RACK-C44). */
  codeItem: string;
  sku: string;
  nom: string;
  famille: string;
  sousFamille: string;
  dimensions: string;
  couleur: string;
  unite: Unite;
  emplacement: string;
  seuilAlerte: number;
  /** Chemin de la photo, ou null si aucune photo exploitable n'est disponible. */
  image: string | null;
  /** true quand la photo provient de l'extraction PDF et doit etre validee par Groupe Alfa. */
  photoAValider: boolean;
  actif: boolean;
}

/* ------------------------------------------------------ Registre de stock */

export type TypeMouvement =
  | 'STOCK_INITIAL'
  | 'RESERVATION'
  | 'LIBERATION_RESERVATION'
  | 'TRANSFERT_INTERNE'
  | 'PREPARATION'
  | 'SORTIE'
  | 'VENTE'
  | 'RETOUR_ACCEPTE'
  | 'QUARANTAINE'
  | 'DOMMAGE'
  | 'PERTE'
  | 'REBUT'
  | 'SUBSTITUTION_ENTREE'
  | 'EXCEDENT_QUARANTAINE'
  | 'AJUSTEMENT';

export interface Mouvement {
  id: string;
  produitId: string;
  /** Toujours strictement positif, sauf AJUSTEMENT qui peut etre negatif. */
  quantite: number;
  type: TypeMouvement;
  emplacementSource: string | null;
  emplacementDestination: string | null;
  clientId: string | null;
  chantierId: string | null;
  /** Reference du document declencheur : DEM-2026-014, BL-2026-031, RET-2026-008... */
  documentRef: string | null;
  utilisateurId: string;
  dateHeure: string;
  motif: string | null;
  /** SEC-011 : appareil ayant produit l'ecriture. */
  appareil: string | null;
  /** RG-029 / RG-031 : ecriture liee (substitution, annulation, compensation). */
  mouvementLieId: string | null;
}

/** Etat de stock d'un produit, entierement recalcule a partir du registre. */
export interface EtatStock {
  produitId: string;
  physique: number;
  reserve: number;
  enPreparation: number;
  enCirculation: number;
  endommage: number;
  disponible: number;
  theorique: number;
}

/* --------------------------------------------------- Clients et chantiers */

export interface Contact {
  id: string;
  clientId: string;
  nom: string;
  fonction: string;
  courriel: string;
  telephone: string;
  signataire: boolean;
}

export interface Client {
  id: string;
  code: string;
  nom: string;
  ville: string;
  telephone: string;
  courriel: string;
  notes: string;
}

export interface Chantier {
  id: string;
  clientId: string;
  code: string;
  nom: string;
  adresse: string;
  ville: string;
  contactId: string | null;
  actif: boolean;
}

/* --------------------------------------------------------------- Demandes */

export type StatutDemande =
  | 'BROUILLON'
  | 'SOUMISE'
  | 'A_VERIFIER'
  | 'APPROUVEE'
  | 'REFUSEE'
  | 'ANNULEE';

export interface LigneDemande {
  id: string;
  produitId: string;
  /** Location ou achat ferme : determine si la quantite reviendra ou non. */
  typeItem: TypeItem;
  quantiteDemandee: number;
  /** Renseignee a l'approbation : c'est elle qui engage le stock. */
  quantiteApprouvee: number | null;
  note: string;
}

export interface Demande {
  id: string;
  numero: string;
  clientId: string;
  chantierId: string;
  dateSouhaitee: string;
  dateCreation: string;
  statut: StatutDemande;
  lignes: LigneDemande[];
  notes: string;
  piecesJointes: string[];
  creeParId: string;
  contactId: string | null;
}

/* ----------------------------------------------------------- Preparations */

export type StatutPreparation =
  | 'A_PREPARER'
  | 'EN_PREPARATION'
  | 'PARTIELLEMENT_PREPAREE'
  | 'PRETE'
  | 'BLOQUEE';

/** DATA-014 : huit categories de preuve, jamais melangees. */
export type CategoriePreuve =
  | 'AVANT_DEPART'
  | 'CHARGEMENT'
  | 'LIVRAISON'
  | 'SIGNATURE_PAPIER'
  | 'RETOUR'
  | 'DOMMAGE'
  | 'ARTICLE_MANQUANT'
  | 'CORRECTION_INVENTAIRE';

export interface PhotoRef {
  id: string;
  /** Cle de la photo dans le magasin IndexedDB, ou chemin public pour les donnees de demo. */
  cle: string;
  legende: string;
  dateHeure: string;
  categorie: CategoriePreuve;
  utilisateurId: string;
  /** DATA-018 : une preuve n'est jamais ecrasee ; un remplacement incremente la version. */
  version: number;
  remplacePhotoId: string | null;
}

export interface LignePreparation {
  id: string;
  ligneDemandeId: string;
  produitId: string;
  typeItem: TypeItem;
  quantiteConfirmee: number;
  quantitePreparee: number;
  photos: PhotoRef[];
  noteInterne: string;
  manquant: boolean;
  substitutionProduitId: string | null;
  substitutionMotif: string;
  confirmee: boolean;
}

export interface Preparation {
  id: string;
  numero: string;
  demandeId: string;
  statut: StatutPreparation;
  assigneAId: string | null;
  vague: number;
  dateCreation: string;
  lignes: LignePreparation[];
  notes: string;
}

/* ------------------------------------------- Sorties et bons de livraison */

export type StatutSortie =
  | 'PRETE_A_SORTIR'
  | 'SORTIE_CONFIRMEE'
  | 'EN_LIVRAISON'
  | 'LIVREE'
  | 'SIGNATURE_EN_ATTENTE'
  | 'SIGNEE';

export interface LigneSortie {
  id: string;
  produitId: string;
  typeItem: TypeItem;
  /** Colonne « Qte Comm. » : quantite commandee au dossier. */
  quantiteCommandee: number;
  /** Colonne « Qte expediee » : quantite reellement sortie. C'est elle qui bouge le stock. */
  quantite: number;
  /** Colonne « Qte a venir » : reliquat restant du au client (RG-024). */
  quantiteAVenir: number;
  note: string;
}

export interface ReceptionLigne {
  ligneSortieId: string;
  quantiteConstatee: number;
  conforme: boolean;
  commentaire: string;
}

export interface Sortie {
  id: string;
  numero: string;
  /** US-018 : toute regeneration apres impression cree une nouvelle version visible. */
  version: number;
  preparationId: string;
  demandeId: string;
  clientId: string;
  chantierId: string;
  statut: StatutSortie;
  lignes: LigneSortie[];
  dateSortie: string;
  preparateurId: string;
  livreur: string;
  /** Bloc administratif repris du bon papier Groupe Alfa. */
  bonCommandeClient: string;
  commandeAlfa: string;
  representant: string;
  expedieVia: string;
  termes: string;
  /** Adresse « Expedie a » lorsqu'elle differe de l'adresse du chantier. */
  expedieA: string;
  heureArrivee: string;
  heureCommencee: string;
  heureTerminee: string;
  /** Signature du representant Alfa, distincte de celle du client. */
  representantSignatureNom: string;
  representantSignatureDataUrl: string | null;
  signataireNom: string;
  /** « Lettres moulees » du bon papier. */
  signataireLettresMoulees: string;
  signatureDataUrl: string | null;
  dateSignature: string | null;
  photoDocumentSigne: PhotoRef | null;
  /**
   * Verification faite par le client a la reception, ligne par ligne.
   * C'est ce qui rend le bon « intelligent » : le client ne signe pas a l'aveugle,
   * il confirme ou conteste chaque quantite, et l'ecart remonte immediatement.
   */
  receptionClient: ReceptionLigne[];
  /** Jeton du lien client simule (aucune valeur de securite). */
  jetonPublic: string;
  envoiSimule: boolean;
}

/* -------------------------------------------------------------- Locations */

export type StatutLocation =
  | 'ACTIVE'
  | 'RETOUR_ATTENDU'
  | 'EN_RETARD'
  | 'RETOUR_PARTIEL'
  | 'EN_LITIGE'
  | 'CLOTUREE';

export interface LigneLocation {
  id: string;
  produitId: string;
  quantiteSortie: number;
  quantiteRetournee: number;
  quantiteEndommagee: number;
  quantiteManquante: number;
  quantiteContestee: number;
}

export interface Location {
  id: string;
  numero: string;
  sortieId: string;
  clientId: string;
  chantierId: string;
  dateSortie: string;
  retourAttendu: string;
  statut: StatutLocation;
  lignes: LigneLocation[];
}

/* ---------------------------------------------------------------- Retours */

/** Qualification du materiel recu (section 12.1, etape 3). */
export type EtatArticle =
  | 'BON'
  | 'A_INSPECTER'
  | 'A_REPARER'
  | 'ENDOMMAGE'
  | 'REBUT'
  | 'REFERENCE_NON_CONFORME';
/** F2 : cycle de vie complet d'un retour. */
export type StatutRetour =
  | 'COMMENCE'
  | 'COMPTAGE'
  | 'ECART_DETECTE'
  | 'VERIFICATION'
  | 'ACCEPTE'
  | 'CLOTURE'
  | 'ANNULE';

export interface LigneRetour {
  id: string;
  produitId: string;
  ligneLocationId: string;
  quantiteAttendue: number;
  quantiteRecue: number;
  quantiteAcceptee: number;
  quantiteEndommagee: number;
  quantiteManquante: number;
  quantiteContestee: number;
  /** Section 12.3 : surplus non attribue, place en quarantaine jusqu'a identification. */
  quantiteExcedent: number;
  etat: EtatArticle;
  photos: PhotoRef[];
  commentaire: string;
}

export interface Retour {
  id: string;
  numero: string;
  locationId: string;
  date: string;
  statut: StatutRetour;
  lignes: LigneRetour[];
  receptionnaireId: string;
  notes: string;
}

/* ----------------------------------------------------------------- Ecarts */

export type TypeEcart = 'MANQUANT' | 'ENDOMMAGE' | 'CONTESTE' | 'EXCEDENT' | 'REFERENCE_NON_CONFORME';
export type DecisionEcart =
  | 'A_VERIFIER'
  | 'ACCEPTE'
  | 'A_FACTURER'
  | 'REMPLACEMENT_ATTENDU'
  | 'ABANDONNE'
  | 'EN_LITIGE'
  | 'RESOLU';

export interface Ecart {
  id: string;
  numero: string;
  retourId: string | null;
  locationId: string;
  clientId: string;
  chantierId: string;
  produitId: string;
  quantite: number;
  type: TypeEcart;
  photos: PhotoRef[];
  responsableId: string | null;
  decision: DecisionEcart;
  motif: string;
  dateCreation: string;
  dateDecision: string | null;
}

/* ---------------------------------------------------------------- Alertes */

export type TypeAlerte =
  | 'STOCK_SOUS_SEUIL'
  | 'DEMANDE_SUPERIEURE_DISPONIBLE'
  | 'PREPARATION_INCOMPLETE'
  | 'BON_NON_SIGNE'
  | 'RETOUR_PROCHAIN'
  | 'RETOUR_EN_RETARD'
  | 'RETOUR_PARTIEL'
  | 'ECART_DETECTE'
  | 'MATERIEL_ENDOMMAGE'
  | 'DOCUMENT_MANQUANT'
  | 'AJUSTEMENT_SENSIBLE'
  | 'DOSSIER_BLOQUE'
  | 'STOCK_DORMANT';

export type SeveriteAlerte = 'INFO' | 'ATTENTION' | 'CRITIQUE';

export interface Alerte {
  /** Cle deterministe (type + entite) : empeche les doublons pour un meme evenement. */
  id: string;
  type: TypeAlerte;
  severite: SeveriteAlerte;
  titre: string;
  message: string;
  entiteType: 'produit' | 'demande' | 'preparation' | 'sortie' | 'location' | 'retour' | 'ecart';
  entiteId: string;
  lien: string;
  dateHeure: string;
}

export interface EtatAlerte {
  acquittee: boolean;
  resolue: boolean;
}

/* ---------------------------------------------------- Journal d'activite */

export interface JournalEntree {
  id: string;
  utilisateurId: string;
  action: string;
  dateHeure: string;
  entiteType: string;
  entiteId: string;
  valeurAvant: string | null;
  valeurApres: string | null;
  motif: string | null;
  appareil: string | null;
}

/* ------------------------------------------------------- Etat applicatif */

export interface EtatDonnees {
  produits: Produit[];
  mouvements: Mouvement[];
  clients: Client[];
  contacts: Contact[];
  chantiers: Chantier[];
  utilisateurs: Utilisateur[];
  demandes: Demande[];
  preparations: Preparation[];
  sorties: Sortie[];
  locations: Location[];
  retours: Retour[];
  ecarts: Ecart[];
  journal: JournalEntree[];
  etatsAlertes: Record<string, EtatAlerte>;
  compteurs: Record<string, number>;
}

/** Resultat normalise des regles metier : jamais d'exception silencieuse. */
export interface ResultatRegle<T = void> {
  ok: boolean;
  message?: string;
  details?: string[];
  valeur?: T;
}
