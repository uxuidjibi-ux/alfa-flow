/* Utilitaires transverses, sans dependance externe. */

let compteurLocal = 0;

/** Identifiant technique stable et lisible dans le journal. */
export function id(prefixe: string): string {
  compteurLocal += 1;
  return `${prefixe}_${Date.now().toString(36)}${compteurLocal.toString(36)}`;
}

/** Numero de document sequentiel : DEM-2026-014, BL-2026-031, RET-2026-008... */
export function numeroSuivant(
  compteurs: Record<string, number>,
  prefixe: string,
  annee: number,
): { numero: string; compteurs: Record<string, number> } {
  const cle = `${prefixe}-${annee}`;
  const valeur = (compteurs[cle] ?? 0) + 1;
  return {
    numero: `${prefixe}-${annee}-${String(valeur).padStart(3, '0')}`,
    compteurs: { ...compteurs, [cle]: valeur },
  };
}

/**
 * Numerotation continue sans annee, utilisee pour les bons de livraison afin de
 * poursuivre la sequence papier existante (L-18203, L-18204...).
 */
export function numeroSequentiel(
  compteurs: Record<string, number>,
  prefixe: string,
  depart: number,
): { numero: string; compteurs: Record<string, number> } {
  const valeur = (compteurs[prefixe] ?? depart) + 1;
  return {
    numero: `${prefixe}-${valeur}`,
    compteurs: { ...compteurs, [prefixe]: valeur },
  };
}

export function maintenant(): string {
  return new Date().toISOString();
}

export function aujourdHui(): string {
  return new Date().toISOString().slice(0, 10);
}

export function jourPlus(jours: number, depuis: string = aujourdHui()): string {
  const d = new Date(`${depuis.slice(0, 10)}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + jours);
  return d.toISOString().slice(0, 10);
}

export function ecartJours(a: string, b: string): number {
  const da = new Date(`${a.slice(0, 10)}T12:00:00Z`).getTime();
  const db = new Date(`${b.slice(0, 10)}T12:00:00Z`).getTime();
  return Math.round((da - db) / 86400000);
}

export function formatDate(valeur: string | null | undefined): string {
  if (!valeur) return '—';
  const d = new Date(valeur.length <= 10 ? `${valeur}T12:00:00Z` : valeur);
  if (Number.isNaN(d.getTime())) return '—';
  return new Intl.DateTimeFormat('fr-CA', { dateStyle: 'medium' }).format(d);
}

export function formatDateHeure(valeur: string | null | undefined): string {
  if (!valeur) return '—';
  const d = new Date(valeur);
  if (Number.isNaN(d.getTime())) return '—';
  return new Intl.DateTimeFormat('fr-CA', { dateStyle: 'medium', timeStyle: 'short' }).format(d);
}

export function formatNombre(valeur: number): string {
  return new Intl.NumberFormat('fr-CA').format(valeur);
}

/** Normalise pour la recherche : minuscules, sans accents, sans ponctuation superflue. */
export function normaliser(texte: string): string {
  return texte
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

export function contient(source: string, requete: string): boolean {
  if (!requete.trim()) return true;
  const cible = normaliser(source);
  return normaliser(requete)
    .split(' ')
    .every((mot) => cible.includes(mot));
}

export function classes(...valeurs: Array<string | false | null | undefined>): string {
  return valeurs.filter(Boolean).join(' ');
}

export function grouperPar<T, K extends string>(items: T[], cle: (item: T) => K): Record<K, T[]> {
  return items.reduce(
    (acc, item) => {
      const k = cle(item);
      (acc[k] ||= []).push(item);
      return acc;
    },
    {} as Record<K, T[]>,
  );
}

export function somme<T>(items: T[], valeur: (item: T) => number): number {
  return items.reduce((total, item) => total + valeur(item), 0);
}

/** Jeton du lien client simule. Aucune valeur de securite (voir MVP_VS_PRODUCTION.md). */
export function jetonDemo(): string {
  return Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 6);
}
