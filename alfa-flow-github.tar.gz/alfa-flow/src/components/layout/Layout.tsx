import { useEffect, useMemo, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  Bell,
  Boxes,
  Compass,
  ClipboardList,
  FileText,
  Gauge,
  Home,
  Layers,
  Menu,
  PackageCheck,
  RotateCcw,
  Search,
  Settings,
  ShieldQuestion,
  LogOut,
  Truck,
  Users,
  X,
} from 'lucide-react';
import { useBoutique } from '../../state/store';
import { useAlertes, useRechercheGlobale } from '../../state/selecteurs';
import { LIBELLE_ROLE, ORGANISATION } from '../../models/referentiel';
import type { Role } from '../../models/types';
import { classes } from '../../utils';
import { Bouton, Message } from '../ui/primitives';
import { GuideDemo } from './GuideDemo';

const NAVIGATION = [
  { libelle: 'Tableau de bord', chemin: '/', icone: Home },
  { libelle: 'Demandes', chemin: '/demandes', icone: ClipboardList },
  { libelle: 'Preparations', chemin: '/preparations', icone: PackageCheck },
  { libelle: 'Sorties et livraisons', chemin: '/livraisons', icone: Truck },
  { libelle: 'Locations', chemin: '/locations', icone: Layers },
  { libelle: 'Retours', chemin: '/retours', icone: RotateCcw },
  { libelle: 'Ecarts', chemin: '/ecarts', icone: ShieldQuestion },
  { libelle: 'Stock', chemin: '/stock', icone: Boxes },
  { libelle: 'Catalogue', chemin: '/catalogue', icone: Gauge },
  { libelle: 'Clients et chantiers', chemin: '/clients', icone: Users },
  { libelle: 'Alertes', chemin: '/alertes', icone: AlertTriangle },
  { libelle: 'Rapports', chemin: '/rapports', icone: FileText },
  { libelle: 'Administration', chemin: '/administration', icone: Settings },
];

const ROLES: Role[] = ['ADMIN', 'COUR', 'SECRETARIAT', 'DIRECTION'];

export function Layout() {
  const [menuOuvert, setMenuOuvert] = useState(false);
  const emplacement = useLocation();

  // La navigation mobile se referme des qu'on change de page.
  useEffect(() => setMenuOuvert(false), [emplacement.pathname]);

  return (
    <div className="min-h-screen bg-white">
      <a href="#contenu" className="lien-evitement">
        Aller au contenu principal
      </a>

      <EnTete onOuvrirMenu={() => setMenuOuvert(true)} />

      <div className="flex">
        <BarreLaterale menuOuvert={menuOuvert} onFermer={() => setMenuOuvert(false)} />

        <main id="contenu" className="min-w-0 flex-1 bg-white">
          <Outlet />
        </main>
      </div>

      <Notifications />
      <GuideDemo />
    </div>
  );
}

/* ------------------------------------------------------------- En-tete */

function EnTete({ onOuvrirMenu }: { onOuvrirMenu: () => void }) {
  const roleActif = useBoutique((e) => e.roleActif);
  const changerRole = useBoutique((e) => e.changerRole);
  const utilisateur = useBoutique((e) => e.utilisateurActif)();
  const changerProfil = useBoutique((e) => e.changerProfil);
  const guideActif = useBoutique((e) => e.guideActif);
  const demarrerGuide = useBoutique((e) => e.demarrerGuide);
  const quitterGuide = useBoutique((e) => e.quitterGuide);
  const alertes = useAlertes();
  const nonResolues = alertes.filter((a) => !a.resolue && !a.acquittee).length;

  return (
    <header className="sticky top-0 z-30 border-b border-alfa-line bg-white">
      <div className="flex items-center gap-3 px-3 py-2.5 sm:px-4">
        <button
          type="button"
          onClick={onOuvrirMenu}
          aria-label="Ouvrir la navigation"
          className="flex h-11 w-11 items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface lg:hidden"
        >
          <Menu aria-hidden="true" className="h-5 w-5" />
        </button>

        <Link to="/" className="flex items-center gap-2.5">
          <img
            src="/marque/alfa-logo.png"
            alt={ORGANISATION.marque}
            className="h-8 w-auto sm:h-9"
          />
          <span className="hidden text-sm font-semibold tracking-tight text-alfa-ink sm:inline">
            Flow
          </span>
        </Link>

        <RechercheGlobale />

        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => (guideActif ? quitterGuide() : demarrerGuide())}
            aria-pressed={guideActif}
            title={guideActif ? 'Fermer le guide' : 'Lancer la demonstration guidee'}
            className={`flex h-11 w-11 items-center justify-center rounded-alfa hover:bg-alfa-surface ${
              guideActif ? 'text-alfa-red' : 'text-alfa-slate'
            }`}
          >
            <Compass aria-hidden="true" className="h-5 w-5" />
            <span className="sr-only">
              {guideActif ? 'Fermer le guide de demonstration' : 'Lancer la demonstration guidee'}
            </span>
          </button>

          <Link
            to="/alertes"
            className="relative flex h-11 w-11 items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface"
            aria-label={`Alertes${nonResolues > 0 ? ` — ${nonResolues} non traitees` : ''}`}
          >
            <Bell aria-hidden="true" className="h-5 w-5" />
            {nonResolues > 0 && (
              <span className="absolute right-1.5 top-1.5 min-w-[18px] rounded-full bg-alfa-red px-1 text-[10px] font-bold leading-[18px] text-white">
                {nonResolues > 9 ? '9+' : nonResolues}
              </span>
            )}
          </Link>

          <div className="hidden sm:block">
            <label htmlFor="selecteur-role" className="sr-only">
              Role de demonstration
            </label>
            <select
              id="selecteur-role"
              value={roleActif}
              onChange={(e) => changerRole(e.target.value as Role)}
              className="min-h-[44px] rounded-alfa border border-alfa-line bg-white px-2.5 text-sm text-alfa-ink focus:border-alfa-red focus:outline-none focus:ring-2 focus:ring-alfa-red/30"
            >
              {ROLES.map((role) => (
                <option key={role} value={role}>
                  {LIBELLE_ROLE[role]}
                </option>
              ))}
            </select>
          </div>

          <div className="hidden items-center gap-2 border-l border-alfa-line pl-2.5 md:flex">
            <span
              aria-hidden="true"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-alfa-ink text-xs font-semibold text-white"
            >
              {utilisateur.nom
                .split(' ')
                .map((mot) => mot[0])
                .join('')
                .slice(0, 2)}
            </span>
            <div className="leading-tight">
              <p className="text-sm font-medium text-alfa-ink">{utilisateur.nom}</p>
              <p className="text-xs text-alfa-muted">{utilisateur.fonction}</p>
            </div>
            <button
              type="button"
              onClick={changerProfil}
              title="Changer de profil"
              className="flex h-11 w-11 items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface"
            >
              <LogOut aria-hidden="true" className="h-4 w-4" />
              <span className="sr-only">Changer de profil</span>
            </button>
          </div>
        </div>
      </div>

      {/* Le selecteur de role reste accessible sur petit ecran. */}
      <div className="flex items-center gap-2 border-t border-alfa-line px-3 py-2 sm:hidden">
        <label htmlFor="selecteur-role-mobile" className="sr-only">
          Role de demonstration
        </label>
        <select
          id="selecteur-role-mobile"
          value={roleActif}
          onChange={(e) => changerRole(e.target.value as Role)}
          className="min-h-[44px] flex-1 rounded-alfa border border-alfa-line bg-white px-2.5 text-sm"
        >
          {ROLES.map((role) => (
            <option key={role} value={role}>
              Role : {LIBELLE_ROLE[role]}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={changerProfil}
          className="flex h-11 w-11 flex-none items-center justify-center rounded-alfa border border-alfa-line text-alfa-slate"
        >
          <LogOut aria-hidden="true" className="h-4 w-4" />
          <span className="sr-only">Changer de profil</span>
        </button>
      </div>
    </header>
  );
}

/* -------------------------------------------------- Recherche globale */

function RechercheGlobale() {
  const [requete, setRequete] = useState('');
  const [ouvert, setOuvert] = useState(false);
  const resultats = useRechercheGlobale(requete);
  const naviguer = useNavigate();

  const aller = (lien: string) => {
    setRequete('');
    setOuvert(false);
    naviguer(lien);
  };

  return (
    <div className="relative hidden min-w-0 flex-1 max-w-md md:block">
      <label htmlFor="recherche-globale" className="sr-only">
        Rechercher un article, un client, un chantier ou un document
      </label>
      <div className="relative">
        <Search
          aria-hidden="true"
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-alfa-muted"
        />
        <input
          id="recherche-globale"
          type="search"
          value={requete}
          placeholder="Rechercher un article, un client, un bon…"
          onChange={(e) => {
            setRequete(e.target.value);
            setOuvert(true);
          }}
          onFocus={() => setOuvert(true)}
          onBlur={() => window.setTimeout(() => setOuvert(false), 150)}
          className="champ pl-9"
          role="combobox"
          aria-expanded={ouvert && resultats.length > 0}
          aria-controls="resultats-recherche"
          autoComplete="off"
        />
      </div>

      {ouvert && requete.trim().length >= 2 && (
        <div
          id="resultats-recherche"
          className="absolute left-0 right-0 top-full z-40 mt-1 max-h-96 overflow-y-auto rounded-alfa border border-alfa-line bg-white shadow-pop"
        >
          {resultats.length === 0 ? (
            <p className="px-3 py-4 text-sm text-alfa-slate">
              Aucun resultat pour « {requete} ». Essayez un code article, un numero de bon ou un
              nom de client.
            </p>
          ) : (
            <ul className="divide-y divide-alfa-line">
              {resultats.map((resultat) => (
                <li key={`${resultat.type}-${resultat.lien}-${resultat.titre}`}>
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => aller(resultat.lien)}
                    className="flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left hover:bg-alfa-surface"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-alfa-ink">
                        {resultat.titre}
                      </span>
                      <span className="block truncate text-xs text-alfa-muted">
                        {resultat.sousTitre}
                      </span>
                    </span>
                    <span className="flex-none text-micro uppercase tracking-wide text-alfa-muted">
                      {resultat.type}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------ Barre laterale */

function BarreLaterale({ menuOuvert, onFermer }: { menuOuvert: boolean; onFermer: () => void }) {
  const barreReduite = useBoutique((e) => e.barreReduite);
  const basculerBarre = useBoutique((e) => e.basculerBarre);
  const alertes = useAlertes();
  const compteurs = useCompteursNavigation();

  const contenu = (reduite: boolean) => (
    <nav aria-label="Navigation principale" className="flex h-full flex-col">
      <ul className="flex-1 space-y-0.5 p-2">
        {NAVIGATION.map((entree) => {
          const Icone = entree.icone;
          const compteur =
            entree.chemin === '/alertes'
              ? alertes.filter((a) => !a.resolue).length
              : compteurs[entree.chemin];
          return (
            <li key={entree.chemin}>
              <NavLink
                to={entree.chemin}
                end={entree.chemin === '/'}
                title={reduite ? entree.libelle : undefined}
                className={({ isActive }) =>
                  classes(
                    'flex min-h-[44px] items-center gap-2.5 rounded-alfa px-2.5 text-sm transition-colors',
                    isActive
                      ? 'bg-alfa-redSoft font-medium text-alfa-redDark'
                      : 'text-alfa-slate hover:bg-alfa-surface hover:text-alfa-ink',
                  )
                }
              >
                <Icone aria-hidden="true" className="h-[18px] w-[18px] flex-none" />
                {!reduite && <span className="min-w-0 flex-1 truncate">{entree.libelle}</span>}
                {!reduite && compteur > 0 && (
                  <span className="flex-none rounded-full bg-alfa-surface px-1.5 text-xs tabular-nums text-alfa-slate">
                    {compteur}
                  </span>
                )}
              </NavLink>
            </li>
          );
        })}
      </ul>

      <div className="border-t border-alfa-line p-2">
        <button
          type="button"
          onClick={basculerBarre}
          className="hidden min-h-[44px] w-full items-center gap-2.5 rounded-alfa px-2.5 text-sm text-alfa-slate hover:bg-alfa-surface lg:flex"
        >
          <Menu aria-hidden="true" className="h-[18px] w-[18px]" />
          {!reduite && <span>Reduire la barre</span>}
        </button>
      </div>
    </nav>
  );

  return (
    <>
      {/* Ordinateur */}
      <aside
        className={classes(
          'sticky top-[57px] hidden h-[calc(100vh-57px)] flex-none border-r border-alfa-line bg-white lg:block',
          barreReduite ? 'w-[60px]' : 'w-[232px]',
        )}
      >
        {contenu(barreReduite)}
      </aside>

      {/* Mobile et tablette */}
      {menuOuvert && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-alfa-ink/40"
            onClick={onFermer}
            aria-hidden="true"
          />
          <div className="absolute inset-y-0 left-0 w-[264px] max-w-[85vw] bg-white shadow-pop">
            <div className="flex items-center justify-between border-b border-alfa-line px-3 py-2.5">
              <span className="font-semibold text-alfa-ink">Navigation</span>
              <button
                type="button"
                onClick={onFermer}
                aria-label="Fermer la navigation"
                className="flex h-11 w-11 items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface"
              >
                <X aria-hidden="true" className="h-5 w-5" />
              </button>
            </div>
            {contenu(false)}
          </div>
        </div>
      )}
    </>
  );
}

/** Compteurs affiches dans la navigation : ce qui attend une action. */
function useCompteursNavigation(): Record<string, number> {
  const donnees = useBoutique((e) => e.donnees);
  return useMemo(
    () => ({
      '/demandes': donnees.demandes.filter((d) => d.statut === 'A_VERIFIER').length,
      '/preparations': donnees.preparations.filter((p) => p.statut !== 'PRETE').length,
      '/livraisons': donnees.sorties.filter((s) => s.statut !== 'SIGNEE').length,
      '/locations': donnees.locations.filter((l) => l.statut !== 'CLOTUREE').length,
      '/retours': donnees.retours.filter((r) => r.statut === 'COMMENCE' || r.statut === 'COMPTAGE')
        .length,
      '/ecarts': donnees.ecarts.filter((e) => e.decision === 'A_VERIFIER').length,
    }),
    [donnees],
  );
}

/* -------------------------------------------------------- Notifications */

function Notifications() {
  const messages = useBoutique((e) => e.messages);
  const fermer = useBoutique((e) => e.fermerMessage);
  if (messages.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="sans-impression fixed bottom-3 left-1/2 z-50 w-[min(92vw,460px)] -translate-x-1/2 space-y-2 sm:bottom-5 sm:left-auto sm:right-5 sm:translate-x-0"
    >
      {messages.map((message) => (
        <div key={message.id} className="rounded-alfa bg-white shadow-pop">
          <div className="relative">
            <Message
              ton={message.type === 'succes' ? 'succes' : message.type === 'erreur' ? 'erreur' : 'info'}
              titre={message.texte}
              details={message.details}
            />
            <button
              type="button"
              onClick={() => fermer(message.id)}
              aria-label="Fermer le message"
              className="absolute right-1 top-1 flex h-8 w-8 items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface"
            >
              <X aria-hidden="true" className="h-4 w-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

export { Bouton };
