import { useNavigate } from 'react-router-dom';
import { ArrowRight, ChevronLeft, Compass, X } from 'lucide-react';
import { ETAPES_GUIDE, useBoutique } from '../../state/store';
import { Bouton } from '../ui/primitives';

/**
 * Mode guide du scenario « Demonstration client ».
 * Il presente une instruction courte et met en evidence l'action suivante,
 * sans jamais bloquer l'utilisation normale de l'application.
 */
export function GuideDemo() {
  const actif = useBoutique((e) => e.guideActif);
  const etape = useBoutique((e) => e.etapeGuide);
  const allerEtape = useBoutique((e) => e.allerEtape);
  const quitter = useBoutique((e) => e.quitterGuide);
  const naviguer = useNavigate();

  if (!actif) return null;

  const courante = ETAPES_GUIDE[etape];
  const derniere = etape === ETAPES_GUIDE.length - 1;

  const suivante = () => {
    if (derniere) {
      quitter();
      return;
    }
    const prochaine = ETAPES_GUIDE[etape + 1];
    allerEtape(etape + 1);
    naviguer(prochaine.chemin);
  };

  return (
    <aside
      aria-label="Guide de demonstration"
      className="sans-impression fixed inset-x-3 bottom-3 z-40 max-h-[60vh] overflow-y-auto rounded-alfa border border-alfa-ink bg-alfa-ink text-white shadow-pop sm:inset-x-auto sm:left-5 sm:w-[380px]"
    >
      <div className="flex items-start gap-3 px-4 py-3">
        <Compass aria-hidden="true" className="mt-0.5 h-5 w-5 flex-none text-alfa-red" />
        <div className="min-w-0 flex-1">
          <p className="text-micro uppercase tracking-wide text-white/60">
            Demonstration guidee — etape {etape + 1} sur {ETAPES_GUIDE.length}
          </p>
          <h2 className="mt-0.5 font-semibold">{courante.titre}</h2>
          <p className="mt-1 text-sm leading-relaxed text-white/80">{courante.texte}</p>
          <p className="mt-2 rounded-alfa bg-white/10 px-2.5 py-1.5 text-sm">
            <span className="font-medium">A faire : </span>
            {courante.action}
          </p>
        </div>
        <button
          type="button"
          onClick={quitter}
          aria-label="Quitter le guide"
          className="flex h-9 w-9 flex-none items-center justify-center rounded-alfa text-white/70 hover:bg-white/10 hover:text-white"
        >
          <X aria-hidden="true" className="h-4 w-4" />
        </button>
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-white/15 px-4 py-2.5">
        <div className="flex gap-1" aria-hidden="true">
          {ETAPES_GUIDE.map((_, index) => (
            <span
              key={index}
              className={
                index === etape ? 'h-1.5 w-5 rounded-full bg-alfa-red' : 'h-1.5 w-1.5 rounded-full bg-white/30'
              }
            />
          ))}
        </div>

        <div className="flex gap-2">
          <Bouton
            compact
            variante="discret"
            className="text-white hover:bg-white/10 hover:text-white"
            disabled={etape === 0}
            onClick={() => {
              allerEtape(etape - 1);
              naviguer(ETAPES_GUIDE[etape - 1].chemin);
            }}
            icone={<ChevronLeft aria-hidden="true" className="h-4 w-4" />}
          >
            Precedent
          </Bouton>
          <Bouton
            compact
            variante="principal"
            onClick={suivante}
            icone={derniere ? undefined : <ArrowRight aria-hidden="true" className="h-4 w-4" />}
          >
            {derniere ? 'Terminer' : 'Etape suivante'}
          </Bouton>
        </div>
      </div>
    </aside>
  );
}
