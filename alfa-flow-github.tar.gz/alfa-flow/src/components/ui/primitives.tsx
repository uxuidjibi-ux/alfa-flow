import { useEffect, useId, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  Check,
  ChevronRight,
  Info,
  Loader2,
  Minus,
  Plus,
  SearchX,
  X,
} from 'lucide-react';
import { classes } from '../../utils';

/* -------------------------------------------------------------- Boutons */

type VarianteBouton = 'principal' | 'secondaire' | 'discret' | 'danger';

interface BoutonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variante?: VarianteBouton;
  icone?: React.ReactNode;
  compact?: boolean;
}

const STYLES_BOUTON: Record<VarianteBouton, string> = {
  principal: 'bg-alfa-red text-white hover:bg-alfa-redDark disabled:bg-alfa-muted',
  secondaire:
    'border border-alfa-line bg-white text-alfa-ink hover:bg-alfa-surface disabled:text-alfa-muted',
  discret: 'text-alfa-slate hover:bg-alfa-surface hover:text-alfa-ink disabled:text-alfa-muted',
  danger: 'border border-alfa-red text-alfa-redDark hover:bg-alfa-redSoft',
};

export function Bouton({
  variante = 'secondaire',
  icone,
  compact = false,
  className,
  children,
  ...reste
}: BoutonProps) {
  return (
    <button
      {...reste}
      className={classes(
        // PERF-002 : 44 points minimum, utilisable avec des gants.
        'inline-flex items-center justify-center gap-2 rounded-alfa font-medium transition-colors',
        'focus:outline-none focus:ring-2 focus:ring-alfa-red/40 focus:ring-offset-2',
        'disabled:cursor-not-allowed',
        compact ? 'min-h-[36px] px-3 text-sm' : 'min-h-[44px] px-4',
        STYLES_BOUTON[variante],
        className,
      )}
    >
      {icone}
      {children}
    </button>
  );
}

/* --------------------------------------------------------------- Statuts */

type TonStatut = 'neutre' | 'info' | 'succes' | 'attention' | 'critique';

const STYLES_STATUT: Record<TonStatut, string> = {
  neutre: 'border-alfa-line bg-alfa-surface text-alfa-slate',
  info: 'border-etat-info/30 bg-etat-info/10 text-etat-info',
  succes: 'border-etat-succes/30 bg-etat-succes/10 text-etat-succes',
  attention: 'border-etat-attention/30 bg-etat-attention/10 text-etat-attention',
  critique: 'border-alfa-red/30 bg-alfa-redSoft text-alfa-redDark',
};

const MARQUEUR: Record<TonStatut, string> = {
  neutre: '○',
  info: '◆',
  succes: '●',
  attention: '▲',
  critique: '■',
};

/**
 * PERF-003 : le statut n'est jamais porte par la seule couleur.
 * Un marqueur de forme accompagne systematiquement le libelle.
 */
export function Statut({ ton = 'neutre', children }: { ton?: TonStatut; children: React.ReactNode }) {
  return (
    <span
      className={classes(
        'inline-flex items-center gap-1.5 whitespace-nowrap rounded-alfa border px-2 py-0.5 text-xs font-medium',
        STYLES_STATUT[ton],
      )}
    >
      <span aria-hidden="true" className="text-[9px] leading-none">
        {MARQUEUR[ton]}
      </span>
      {children}
    </span>
  );
}

/* ------------------------------------------------------------- Structure */

export function Page({
  titre,
  description,
  actions,
  fil,
  children,
}: {
  titre: string;
  description?: string;
  actions?: React.ReactNode;
  fil?: Array<{ libelle: string; lien?: string }>;
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto w-full max-w-[1400px] px-4 py-5 sm:px-6 sm:py-7">
      {fil && fil.length > 0 && <FilAriane elements={fil} />}
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-alfa-ink sm:text-2xl">{titre}</h1>
          {description && <p className="mt-1 max-w-2xl text-sm text-alfa-slate">{description}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export function FilAriane({ elements }: { elements: Array<{ libelle: string; lien?: string }> }) {
  return (
    <nav aria-label="Fil d'Ariane" className="mb-3">
      <ol className="flex flex-wrap items-center gap-1 text-sm text-alfa-muted">
        {elements.map((element, index) => (
          <li key={`${element.libelle}-${index}`} className="flex items-center gap-1">
            {index > 0 && <ChevronRight aria-hidden="true" className="h-3.5 w-3.5" />}
            {element.lien ? (
              <Link to={element.lien} className="hover:text-alfa-ink hover:underline">
                {element.libelle}
              </Link>
            ) : (
              <span aria-current="page" className="text-alfa-slate">
                {element.libelle}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function Section({
  titre,
  action,
  children,
  className,
}: {
  titre?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={classes('carte', className)}>
      {(titre || action) && (
        <div className="flex items-center justify-between gap-3 border-b border-alfa-line px-4 py-3">
          {titre && <h2 className="text-sm font-semibold text-alfa-ink">{titre}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

/* ---------------------------------------------------------------- Etats */

export function Chargement({ texte = 'Chargement en cours' }: { texte?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-2 py-12 text-alfa-slate">
      <Loader2 aria-hidden="true" className="h-5 w-5 animate-spin" />
      <span>{texte}…</span>
    </div>
  );
}

export function EtatVide({
  titre,
  texte,
  action,
}: {
  titre: string;
  texte?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-2 px-4 py-12 text-center">
      <SearchX aria-hidden="true" className="h-7 w-7 text-alfa-muted" />
      <p className="font-medium text-alfa-ink">{titre}</p>
      {texte && <p className="max-w-md text-sm text-alfa-slate">{texte}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/** PERF-004 : le message nomme toujours le champ et l'action corrective. */
export function Message({
  ton,
  titre,
  details,
}: {
  ton: 'erreur' | 'succes' | 'info' | 'attention';
  titre: string;
  details?: string[];
}) {
  const styles = {
    erreur: 'border-alfa-red/40 bg-alfa-redSoft',
    succes: 'border-etat-succes/30 bg-etat-succes/5',
    info: 'border-etat-info/30 bg-etat-info/5',
    attention: 'border-etat-attention/40 bg-etat-attention/5',
  }[ton];
  const Icone = { erreur: AlertTriangle, succes: Check, info: Info, attention: AlertTriangle }[ton];
  const couleurIcone = {
    erreur: 'text-alfa-red',
    succes: 'text-etat-succes',
    info: 'text-etat-info',
    attention: 'text-etat-attention',
  }[ton];

  return (
    <div
      role={ton === 'erreur' ? 'alert' : 'status'}
      className={classes('flex items-start gap-2.5 rounded-alfa border px-3 py-2.5 text-sm', styles)}
    >
      <Icone aria-hidden="true" className={classes('mt-0.5 h-4 w-4 flex-none', couleurIcone)} />
      <div className="min-w-0">
        <p className="font-medium text-alfa-ink">{titre}</p>
        {details && details.length > 0 && (
          <ul className="mt-1 list-inside list-disc space-y-0.5 text-alfa-slate">
            {details.map((detail, index) => (
              <li key={index}>{detail}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------- Champs */

interface ChampProps extends React.InputHTMLAttributes<HTMLInputElement> {
  etiquette: string;
  aide?: string;
  erreur?: string;
}

export function Champ({ etiquette, aide, erreur, id, ...reste }: ChampProps) {
  const genere = useId();
  const identifiant = id ?? genere;
  const idAide = `${identifiant}-aide`;
  const idErreur = `${identifiant}-erreur`;

  return (
    <div>
      <label htmlFor={identifiant} className="etiquette-champ">
        {etiquette}
      </label>
      <input
        {...reste}
        id={identifiant}
        aria-invalid={erreur ? true : undefined}
        aria-describedby={classes(aide && idAide, erreur && idErreur) || undefined}
        className={classes('champ mt-1.5', erreur && 'champ-invalide', reste.className)}
      />
      {aide && !erreur && (
        <p id={idAide} className="mt-1 text-xs text-alfa-muted">
          {aide}
        </p>
      )}
      {erreur && (
        <p id={idErreur} role="alert" className="mt-1 text-xs font-medium text-alfa-redDark">
          {erreur}
        </p>
      )}
    </div>
  );
}

export function ChampTexte({
  etiquette,
  aide,
  id,
  ...reste
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { etiquette: string; aide?: string }) {
  const genere = useId();
  const identifiant = id ?? genere;
  return (
    <div>
      <label htmlFor={identifiant} className="etiquette-champ">
        {etiquette}
      </label>
      <textarea
        {...reste}
        id={identifiant}
        className={classes('champ mt-1.5 min-h-[88px] py-2', reste.className)}
      />
      {aide && <p className="mt-1 text-xs text-alfa-muted">{aide}</p>}
    </div>
  );
}

export function ChampSelection({
  etiquette,
  aide,
  id,
  children,
  ...reste
}: React.SelectHTMLAttributes<HTMLSelectElement> & { etiquette: string; aide?: string }) {
  const genere = useId();
  const identifiant = id ?? genere;
  return (
    <div>
      <label htmlFor={identifiant} className="etiquette-champ">
        {etiquette}
      </label>
      <select {...reste} id={identifiant} className={classes('champ mt-1.5', reste.className)}>
        {children}
      </select>
      {aide && <p className="mt-1 text-xs text-alfa-muted">{aide}</p>}
    </div>
  );
}

/**
 * BF-012 : saisie rapide des quantites, incrementes +1 / +5 / +10 et clavier.
 * Concu pour un usage sur tablette dans la cour.
 */
export function CompteurQuantite({
  valeur,
  onChange,
  max,
  etiquette,
  desactive,
}: {
  valeur: number;
  onChange: (valeur: number) => void;
  max?: number;
  etiquette: string;
  desactive?: boolean;
}) {
  const identifiant = useId();
  const borner = (nouvelle: number) => Math.max(0, max === undefined ? nouvelle : Math.min(max, nouvelle));

  return (
    <div>
      <label htmlFor={identifiant} className="sr-only">
        {etiquette}
      </label>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center rounded-alfa border border-alfa-line">
          <button
            type="button"
            aria-label="Retirer une unite"
            disabled={desactive || valeur <= 0}
            onClick={() => onChange(borner(valeur - 1))}
            className="flex h-11 w-11 items-center justify-center rounded-l-alfa text-alfa-slate hover:bg-alfa-surface disabled:text-alfa-line"
          >
            <Minus aria-hidden="true" className="h-4 w-4" />
          </button>
          <input
            id={identifiant}
            type="number"
            inputMode="numeric"
            min={0}
            max={max}
            value={valeur}
            disabled={desactive}
            onChange={(e) => onChange(borner(Number(e.target.value)))}
            className="h-11 w-16 border-x border-alfa-line text-center tabular-nums focus:outline-none focus:ring-2 focus:ring-inset focus:ring-alfa-red/30 disabled:bg-alfa-surface"
          />
          <button
            type="button"
            aria-label="Ajouter une unite"
            disabled={desactive || (max !== undefined && valeur >= max)}
            onClick={() => onChange(borner(valeur + 1))}
            className="flex h-11 w-11 items-center justify-center rounded-r-alfa text-alfa-slate hover:bg-alfa-surface disabled:text-alfa-line"
          >
            <Plus aria-hidden="true" className="h-4 w-4" />
          </button>
        </div>

        {[5, 10].map((pas) => (
          <Bouton
            key={pas}
            compact
            type="button"
            disabled={desactive}
            onClick={() => onChange(borner(valeur + pas))}
          >
            +{pas}
          </Bouton>
        ))}

        {max !== undefined && (
          <Bouton compact type="button" disabled={desactive} onClick={() => onChange(max)}>
            Tout ({max})
          </Bouton>
        )}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------- Modale */

export function Modale({
  ouverte,
  titre,
  description,
  onFermer,
  children,
  actions,
}: {
  ouverte: boolean;
  titre: string;
  description?: string;
  onFermer: () => void;
  children?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  const reference = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!ouverte) return;
    const surTouche = (evenement: KeyboardEvent) => {
      if (evenement.key === 'Escape') onFermer();
    };
    document.addEventListener('keydown', surTouche);
    reference.current?.focus();
    return () => document.removeEventListener('keydown', surTouche);
  }, [ouverte, onFermer]);

  if (!ouverte) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-alfa-ink/40 p-0 sm:items-center sm:p-4">
      <div
        ref={reference}
        role="dialog"
        aria-modal="true"
        aria-label={titre}
        tabIndex={-1}
        className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-xl bg-white shadow-pop focus:outline-none sm:rounded-alfa"
      >
        <div className="flex items-start justify-between gap-3 border-b border-alfa-line px-4 py-3">
          <div>
            <h2 className="font-semibold text-alfa-ink">{titre}</h2>
            {description && <p className="mt-0.5 text-sm text-alfa-slate">{description}</p>}
          </div>
          <button
            type="button"
            onClick={onFermer}
            aria-label="Fermer"
            className="flex h-11 w-11 flex-none items-center justify-center rounded-alfa text-alfa-slate hover:bg-alfa-surface"
          >
            <X aria-hidden="true" className="h-5 w-5" />
          </button>
        </div>
        {children && <div className="px-4 py-4">{children}</div>}
        {actions && (
          <div className="flex flex-wrap justify-end gap-2 border-t border-alfa-line px-4 py-3">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Confirmation d'une action sensible. Un motif peut etre exige :
 * SEC-005 impose motif, auteur, valeur avant et apres pour toute correction.
 */
export function Confirmation({
  ouverte,
  titre,
  description,
  libelleAction = 'Confirmer',
  motifRequis = false,
  onConfirmer,
  onAnnuler,
}: {
  ouverte: boolean;
  titre: string;
  description: string;
  libelleAction?: string;
  motifRequis?: boolean;
  onConfirmer: (motif: string) => void;
  onAnnuler: () => void;
}) {
  const [motif, setMotif] = useState('');
  const [erreur, setErreur] = useState<string | null>(null);

  useEffect(() => {
    if (ouverte) {
      setMotif('');
      setErreur(null);
    }
  }, [ouverte]);

  const valider = () => {
    if (motifRequis && !motif.trim()) {
      setErreur('Le motif est obligatoire : cette action est inscrite au journal d activite.');
      return;
    }
    onConfirmer(motif.trim());
  };

  return (
    <Modale
      ouverte={ouverte}
      titre={titre}
      description={description}
      onFermer={onAnnuler}
      actions={
        <>
          <Bouton onClick={onAnnuler}>Annuler</Bouton>
          <Bouton variante="principal" onClick={valider}>
            {libelleAction}
          </Bouton>
        </>
      }
    >
      {motifRequis && (
        <ChampTexte
          etiquette="Motif"
          value={motif}
          onChange={(e) => setMotif(e.target.value)}
          aide="Conserve dans le journal avec votre nom, la date et l heure."
        />
      )}
      {erreur && (
        <div className="mt-3">
          <Message ton="erreur" titre={erreur} />
        </div>
      )}
    </Modale>
  );
}

/* -------------------------------------------------------------- Tableau */

export function Tableau({
  entetes,
  children,
  legende,
}: {
  entetes: Array<{ libelle: string; alignement?: 'gauche' | 'droite'; discret?: boolean }>;
  children: React.ReactNode;
  legende?: string;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] border-collapse text-sm">
        {legende && <caption className="sr-only">{legende}</caption>}
        <thead>
          <tr className="border-b border-alfa-line bg-alfa-surface">
            {entetes.map((entete) => (
              <th
                key={entete.libelle}
                scope="col"
                className={classes(
                  'px-3 py-2.5 text-micro font-semibold uppercase tracking-wide text-alfa-muted',
                  entete.alignement === 'droite' ? 'text-right' : 'text-left',
                  entete.discret && 'hidden lg:table-cell',
                )}
              >
                {entete.libelle}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-alfa-line">{children}</tbody>
      </table>
    </div>
  );
}

export function Cellule({
  children,
  alignement,
  discret,
  className,
}: {
  children: React.ReactNode;
  alignement?: 'gauche' | 'droite';
  discret?: boolean;
  className?: string;
}) {
  return (
    <td
      className={classes(
        'px-3 py-2.5 align-middle',
        alignement === 'droite' && 'text-right tabular-nums',
        discret && 'hidden lg:table-cell',
        className,
      )}
    >
      {children}
    </td>
  );
}

/** Couple etiquette / valeur, utilise dans les fiches. */
export function Donnee({
  terme,
  valeur,
  accent,
}: {
  terme: string;
  valeur: React.ReactNode;
  accent?: boolean;
}) {
  return (
    <div>
      <dt className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">{terme}</dt>
      <dd className={classes('mt-0.5 text-sm', accent ? 'font-semibold text-alfa-ink' : 'text-alfa-slate')}>
        {valeur}
      </dd>
    </div>
  );
}
