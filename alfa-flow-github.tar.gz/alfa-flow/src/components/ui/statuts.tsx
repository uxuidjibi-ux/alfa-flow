import {
  LIBELLE_DECISION_ECART,
  LIBELLE_STATUT_DEMANDE,
  LIBELLE_STATUT_LOCATION,
  LIBELLE_STATUT_PREPARATION,
  LIBELLE_STATUT_RETOUR,
  LIBELLE_STATUT_SORTIE,
  LIBELLE_TYPE_ITEM,
} from '../../models/referentiel';
import type {
  DecisionEcart,
  StatutDemande,
  StatutLocation,
  StatutPreparation,
  StatutRetour,
  StatutSortie,
  TypeItem,
} from '../../models/types';
import { Statut } from './primitives';

/**
 * Un statut = un libelle + un ton + un marqueur de forme.
 * Le systeme est defini une seule fois pour rester coherent d'un ecran a l'autre.
 */

type Ton = 'neutre' | 'info' | 'succes' | 'attention' | 'critique';

const TON_DEMANDE: Record<StatutDemande, Ton> = {
  BROUILLON: 'neutre',
  SOUMISE: 'info',
  A_VERIFIER: 'attention',
  APPROUVEE: 'succes',
  REFUSEE: 'critique',
  ANNULEE: 'neutre',
};

const TON_PREPARATION: Record<StatutPreparation, Ton> = {
  A_PREPARER: 'info',
  EN_PREPARATION: 'info',
  PARTIELLEMENT_PREPAREE: 'attention',
  PRETE: 'succes',
  BLOQUEE: 'critique',
};

const TON_SORTIE: Record<StatutSortie, Ton> = {
  PRETE_A_SORTIR: 'info',
  SORTIE_CONFIRMEE: 'info',
  EN_LIVRAISON: 'info',
  LIVREE: 'attention',
  SIGNATURE_EN_ATTENTE: 'attention',
  SIGNEE: 'succes',
};

const TON_LOCATION: Record<StatutLocation, Ton> = {
  ACTIVE: 'info',
  RETOUR_ATTENDU: 'attention',
  EN_RETARD: 'critique',
  RETOUR_PARTIEL: 'attention',
  EN_LITIGE: 'critique',
  CLOTUREE: 'succes',
};

const TON_RETOUR: Record<StatutRetour, Ton> = {
  COMMENCE: 'info',
  COMPTAGE: 'info',
  ECART_DETECTE: 'attention',
  VERIFICATION: 'attention',
  ACCEPTE: 'succes',
  CLOTURE: 'succes',
  ANNULE: 'neutre',
};

const TON_ECART: Record<DecisionEcart, Ton> = {
  A_VERIFIER: 'attention',
  ACCEPTE: 'info',
  A_FACTURER: 'attention',
  REMPLACEMENT_ATTENDU: 'info',
  ABANDONNE: 'neutre',
  EN_LITIGE: 'critique',
  RESOLU: 'succes',
};

export const StatutDemandeBadge = ({ statut }: { statut: StatutDemande }) => (
  <Statut ton={TON_DEMANDE[statut]}>{LIBELLE_STATUT_DEMANDE[statut]}</Statut>
);

export const StatutPreparationBadge = ({ statut }: { statut: StatutPreparation }) => (
  <Statut ton={TON_PREPARATION[statut]}>{LIBELLE_STATUT_PREPARATION[statut]}</Statut>
);

export const StatutSortieBadge = ({ statut }: { statut: StatutSortie }) => (
  <Statut ton={TON_SORTIE[statut]}>{LIBELLE_STATUT_SORTIE[statut]}</Statut>
);

export const StatutLocationBadge = ({ statut }: { statut: StatutLocation }) => (
  <Statut ton={TON_LOCATION[statut]}>{LIBELLE_STATUT_LOCATION[statut]}</Statut>
);

export const StatutRetourBadge = ({ statut }: { statut: StatutRetour }) => (
  <Statut ton={TON_RETOUR[statut]}>{LIBELLE_STATUT_RETOUR[statut]}</Statut>
);

export const DecisionEcartBadge = ({ decision }: { decision: DecisionEcart }) => (
  <Statut ton={TON_ECART[decision]}>{LIBELLE_DECISION_ECART[decision]}</Statut>
);

/** Location ou achat : la distinction change le sort de la quantite. */
export const TypeItemBadge = ({ type }: { type: TypeItem }) => (
  <Statut ton={type === 'ACHAT' ? 'neutre' : 'info'}>{LIBELLE_TYPE_ITEM[type]}</Statut>
);
