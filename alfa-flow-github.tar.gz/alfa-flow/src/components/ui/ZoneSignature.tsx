import { useCallback, useEffect, useRef, useState } from 'react';
import { Eraser, PenLine } from 'lucide-react';

interface Props {
  /** Appele a chaque fin de trace avec l'image PNG, ou null si la zone est videe. */
  onChange: (dataUrl: string | null) => void;
  label?: string;
  hauteur?: number;
  desactive?: boolean;
}

/**
 * Signature tracee au doigt, au stylet ou a la souris.
 * Les evenements Pointer couvrent les trois cas sans code specifique par appareil,
 * ce qui rend la zone utilisable sur telephone, tablette et ordinateur (PERF-001).
 */
export function ZoneSignature({
  onChange,
  label = 'Signature',
  hauteur = 160,
  desactive = false,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const dessine = useRef(false);
  const dernierPoint = useRef<{ x: number; y: number } | null>(null);
  const [vide, setVide] = useState(true);

  // Le canvas est redimensionne selon la densite d'ecran pour un trace net.
  const ajusterTaille = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const densite = window.devicePixelRatio || 1;
    const image = vide ? null : canvas.toDataURL('image/png');
    canvas.width = Math.max(1, Math.floor(rect.width * densite));
    canvas.height = Math.max(1, Math.floor(hauteur * densite));
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(densite, densite);
    ctx.lineWidth = 2.2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#111111';
    if (image) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, hauteur);
      img.src = image;
    }
  }, [hauteur, vide]);

  useEffect(() => {
    ajusterTaille();
    window.addEventListener('resize', ajusterTaille);
    return () => window.removeEventListener('resize', ajusterTaille);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const position = (evenement: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = evenement.currentTarget.getBoundingClientRect();
    return { x: evenement.clientX - rect.left, y: evenement.clientY - rect.top };
  };

  const demarrer = (evenement: React.PointerEvent<HTMLCanvasElement>) => {
    if (desactive) return;
    evenement.currentTarget.setPointerCapture(evenement.pointerId);
    dessine.current = true;
    dernierPoint.current = position(evenement);
  };

  const tracer = (evenement: React.PointerEvent<HTMLCanvasElement>) => {
    if (!dessine.current || desactive) return;
    const ctx = canvasRef.current?.getContext('2d');
    const depart = dernierPoint.current;
    if (!ctx || !depart) return;
    const point = position(evenement);
    ctx.beginPath();
    ctx.moveTo(depart.x, depart.y);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
    dernierPoint.current = point;
    if (vide) setVide(false);
  };

  const terminer = () => {
    if (!dessine.current) return;
    dessine.current = false;
    dernierPoint.current = null;
    const canvas = canvasRef.current;
    if (canvas) onChange(canvas.toDataURL('image/png'));
  };

  const effacer = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setVide(true);
    onChange(null);
  };

  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="text-micro font-semibold uppercase tracking-wide text-alfa-muted">
          {label}
        </span>
        <button
          type="button"
          onClick={effacer}
          disabled={vide || desactive}
          className="inline-flex min-h-[44px] items-center gap-1.5 px-2 text-sm text-alfa-slate underline-offset-2 hover:text-alfa-ink hover:underline disabled:cursor-not-allowed disabled:text-alfa-line"
        >
          <Eraser aria-hidden="true" className="h-4 w-4" />
          Effacer
        </button>
      </div>

      <div className="relative rounded-alfa border border-alfa-line bg-white">
        <canvas
          ref={canvasRef}
          style={{ height: hauteur, touchAction: 'none' }}
          className="w-full cursor-crosshair rounded-alfa"
          onPointerDown={demarrer}
          onPointerMove={tracer}
          onPointerUp={terminer}
          onPointerLeave={terminer}
          onPointerCancel={terminer}
          role="img"
          aria-label={vide ? `${label} — zone vide, tracez votre signature` : `${label} — signature tracee`}
        />

        {vide && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-1 text-alfa-muted">
            <PenLine aria-hidden="true" className="h-5 w-5" />
            <span className="text-sm">Tracez votre signature ici</span>
            <span className="text-xs">Doigt, stylet ou souris</span>
          </div>
        )}

        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-6 bottom-6 border-b border-dashed border-alfa-line"
        />
      </div>
    </div>
  );
}
