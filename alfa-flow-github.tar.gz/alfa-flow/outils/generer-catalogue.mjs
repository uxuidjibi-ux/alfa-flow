/**
 * Genere src/data/produits.ts a partir du texte extrait de « LISTE PRODUIT.pdf ».
 * Les quantites de demonstration sont pseudo-aleatoires mais deterministes
 * (graine fixe) afin que la reinitialisation redonne toujours le meme etat.
 */
import fs from 'node:fs';

const brut = fs.readFileSync('/tmp/doc2.txt', 'utf8');

const lignes = brut
  .split('\n')
  .map((l) => l.trim())
  .filter(Boolean)
  .filter((l) => !/^=+$/.test(l) && l !== '=' && !/^CATÉGORIE/.test(l))
  .map((l) => l.replace(/^CATÉGORIE ÉVÉNEMEN/, '').trim())
  .filter((l) => l.length > 4 && /[A-ZÀ-Ü]/.test(l))
  .filter((l) => !/^\s*=/.test(l));

// Certaines lignes du PDF sont collees (defaut d'extraction) : on les separe.
const MOTS_CLES = [
  'ADAPTATEUR', 'BARRE', 'CONTRE-PLAQUÉ', 'ÉQUERRE', 'GARDE-CORPS', 'GARDE-CROPS', 'LIMON',
  'PLATEFORME', 'PLATE-FORME', 'POTEAU', 'POUTRE', 'RACCORD', 'RAMPE', 'RISER',
  '1 PLACE', '2 PLACES', '3 PLACES', '4 PLACES',
];

const noms = [];
for (const ligne of lignes) {
  let reste = ligne;
  const decoupes = [];
  let garde = 0;
  while (garde++ < 6) {
    let indexCoupe = -1;
    for (const mot of MOTS_CLES) {
      // On ne coupe que sur une concatenation reelle : le mot-cle colle au mot precedent.
      const i = reste.indexOf(mot, 1);
      if (i > 0 && reste[i - 1] !== ' ' && (indexCoupe === -1 || i < indexCoupe)) indexCoupe = i;
    }
    if (indexCoupe === -1) break;
    decoupes.push(reste.slice(0, indexCoupe).trim());
    reste = reste.slice(indexCoupe).trim();
  }
  decoupes.push(reste.trim());
  for (const d of decoupes) if (d.length > 4) noms.push(d);
}

const uniques = [...new Set(noms.map((n) => n.replace(/\s+/g, ' ').trim()))];

/* ------------------------------------------------------- Classification */

function famille(nom) {
  const n = nom.toUpperCase();
  if (n.startsWith('BARRE HORIZONTALE') || n.startsWith('BARRE HORIOZNTALE')) return ['Barres', 'Barre horizontale'];
  if (n.startsWith('BARRE DIAGONALE')) return ['Barres', 'Barre diagonale'];
  if (n.startsWith('BARRURE')) return ['Accessoires', 'Barrure'];
  if (n.startsWith('GARDE-CORPS') || n.startsWith('GARDE-CROPS') || n.startsWith('ARRIÈRE GARDE-CORPS')) {
    return ['Garde-corps', n.includes('ÉVÉNEMENTIEL') ? 'Garde-corps evenementiel' : 'Garde-corps aluminium'];
  }
  if (n.startsWith('POTEAU')) return ['Poteaux', n.includes('VERTICAL') ? 'Poteau vertical' : 'Poteau adaptateur'];
  if (n.startsWith('LIMON') || n.startsWith('MARCHE') || n.startsWith('DEMI MARCHE') || n.startsWith('RISER'))
    return ['Escaliers', n.startsWith('RISER') ? 'Riser' : n.startsWith('LIMON') ? 'Limon' : 'Marche'];
  if (n.startsWith('RAMPE')) return ['Escaliers', 'Rampe'];
  if (n.startsWith('PLANCHER') || n.startsWith('PLATE-FORME') || n.startsWith('PLATEFORME'))
    return ['Planchers', 'Plancher'];
  if (n.startsWith('POUTRE') || n.startsWith('POUTRELLE') || n.startsWith('LATTICE'))
    return ['Poutres', n.startsWith('POUTRELLE') ? 'Poutrelle' : 'Poutre'];
  if (n.startsWith('RACCORD') || n.startsWith('ADAPTATEUR') || n.startsWith('ADAPTEUR') || n.startsWith('SPIGOT') || n.startsWith('COLLIER') || n.startsWith('PIN') || n.startsWith('BOULON') || n.startsWith('BOUTEILLES') || n.startsWith('ATTACHE'))
    return ['Accessoires', 'Raccord et adaptateur'];
  if (n.startsWith('VÉRIN') || n.startsWith('ÉQUERRE')) return ['Accessoires', 'Verin et equerre'];
  if (n.startsWith('CLOTURE') || n.includes('CLOTURE')) return ['Chantier', 'Cloture'];
  if (n.includes('SIÈGE') || n.startsWith('CONTENANT')) return ['Evenementiel', 'Siege'];
  if (n.startsWith('CONTRE-PLAQUÉ') || n.startsWith('TABLETTE')) return ['Bois', 'Panneau'];
  if (n.startsWith('VOMITOIRE')) return ['Evenementiel', 'Vomitoire'];
  return ['Divers', 'Divers'];
}

const COULEURS = ['BOURGOGNE', 'ROUGE', 'BLEU PÂLE', 'BLEU', 'JAUNE', 'VERT', 'NOIR', 'BLANC', 'ARGENT', 'BRUN', 'MAUVE', 'GRIS', 'DORÉ'];

function couleur(nom) {
  const apres = nom.split(/[-–]/).slice(1).join('-').toUpperCase();
  const source = apres || nom.toUpperCase();
  const trouvees = COULEURS.filter((c) => source.includes(c));
  if (trouvees.length === 0) return '';
  const propre = trouvees
    .filter((c, i, arr) => !arr.some((autre, j) => j !== i && autre.includes(c) && autre !== c))
    .slice(0, 2)
    .map((c) => c.charAt(0) + c.slice(1).toLowerCase());
  return propre.join(' / ');
}

function dimensions(nom) {
  const morceaux = [];
  const pieds = nom.match(/\d+['’]\s?\d*["”]?/g);
  if (pieds) morceaux.push(...pieds);
  const metres = nom.match(/\d+[.,]?\d*\s?[mM](?![a-zA-Z])/g);
  if (metres) morceaux.push(...metres.map((m) => m.replace(/\s+/g, '').toUpperCase()));
  const modules = nom.match(/\b(1500|2000|2400|3000)\b/g);
  if (modules) morceaux.push(...modules);
  const pouces = nom.match(/\b\d{2}["”]/g);
  if (pouces) morceaux.push(...pouces);
  return [...new Set(morceaux)].join(' × ');
}

/* -------------------------------------------- Generateur deterministe */

function graine(texte) {
  let h = 2166136261;
  for (let i = 0; i < texte.length; i++) {
    h ^= texte.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

// Section 8.2 : emplacements internes du depot de Sainte-Sophie.
const EMPLACEMENTS = [
  'Cour - Zone A - Rangee 1', 'Cour - Zone A - Rangee 2',
  'Cour - Zone B - Rangee 1', 'Cour - Zone B - Rangee 2',
  'Entrepot - Zone 1 - Rangee A', 'Entrepot - Zone 1 - Rangee B',
  'Entrepot - Zone 2 - Rangee A',
];

const PHOTOS = {
  'BARRE HORIZONTALE 1500 - BOURGOGNE': 'bh-1500-bourgogne.jpg',
  'BARRE HORIZONTALE 2000': 'bh-2000.jpg',
  'BARRE HORIOZNTALE PALIER 2000': 'bh-palier-2000.jpg',
  'BARRE HORIOZNTALE PALIER 2400': 'bh-palier-2400.jpg',
  'BARRE HORIZONTALE 2\'2"': 'bh-2pi2.jpg',
  'BARRE HORIZONTALE 5\'6" - BLEU PÂLE': 'bh-5pi6-bleu-pale.jpg',
  'BARRE HORIZONTALE 9\'10" - ROUGE': 'bh-9pi10-rouge.jpg',
  'BARRE HORIZONTALE 4\'2"': 'bh-5pi2-jaune.jpg',
  'BARRE HORIZONTALE 8\'6': 'bh-3pi10-mauve.jpg',
  'BARRE HORIZONTALE 2400': 'bh-7pi.jpg',
};

const MOTS_MAJUSCULES = new Set(['U', 'HD', 'DT', 'RA', 'SWB', 'PIC-PIC', 'ALU', 'V']);

function motPropre(mot, capitaliser) {
  const prefixe = (mot.match(/^[("']+/) || [''])[0];
  const suffixe = (mot.match(/[)"']+$/) || [''])[0];
  const coeur = mot.slice(prefixe.length, mot.length - suffixe.length || undefined);
  if (!coeur) return mot;
  if (/[0-9]/.test(coeur)) return mot;
  if (MOTS_MAJUSCULES.has(coeur.toUpperCase())) return prefixe + coeur.toUpperCase() + suffixe;
  const bas = coeur.toLowerCase();
  const rendu = capitaliser ? bas.charAt(0).toUpperCase() + bas.slice(1) : bas;
  return prefixe + rendu + suffixe;
}

function nomPropre(nom) {
  const nettoye = nom
    .replace(/HORIOZNTALE/g, 'HORIZONTALE')
    .replace(/GARDE-CROPS/g, 'GARDE-CORPS')
    .replace(/ADAPTEUR/g, 'ADAPTATEUR')
    .replace(/CONTRE MARCHE/g, 'CONTRE-MARCHE')
    .replace(/\s+/g, ' ')
    .replace(/\s+[-–]\s*/g, ' – ')
    .replace(/\s[xX]\s/g, ' × ')
    .replace(/(\d)\s?[mM]\b/g, '$1 m')
    .trim();

  const mots = nettoye.split(' ');
  let apresTiret = false;
  return mots
    .map((mot, i) => {
      if (mot === '–' || mot === '×') {
        apresTiret = mot === '–';
        return mot;
      }
      const capitaliser = i === 0 || apresTiret;
      apresTiret = false;
      return motPropre(mot, capitaliser);
    })
    .join(' ');
}

const codesUtilises = new Set();
function sku(f, sf, nom, index) {
  const base =
    f.slice(0, 2).toUpperCase() +
    sf.replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase();
  let code = `ALF-${base}-${String(index + 1).padStart(3, '0')}`;
  let n = 1;
  while (codesUtilises.has(code)) code = `ALF-${base}-${String(index + 1).padStart(3, '0')}-${n++}`;
  codesUtilises.add(code);
  return code;
}

const vus = new Set();
const produits = uniques
  .filter((nomBrut) => {
    const cle = nomPropre(nomBrut).toLowerCase();
    if (vus.has(cle)) return false;
    vus.add(cle);
    return true;
  })
  .map((nomBrut, index) => {
  const [f, sf] = famille(nomBrut);
  const g = graine(nomBrut);
  const g2 = graine(nomBrut + 'x');
  const grosVolume = f === 'Barres' || f === 'Poteaux' || f === 'Accessoires';
  const total = Math.round(grosVolume ? 60 + g * 340 : 12 + g * 120);
  return {
    id: `prod_${String(index + 1).padStart(3, '0')}`,
    // Format releve sur les bons Groupe Alfa : code numerique a six chiffres.
    codeItem: String(900000 + (index + 1) * 5),
    sku: sku(f, sf, nomBrut, index),
    nom: nomPropre(nomBrut),
    famille: f,
    sousFamille: sf,
    dimensions: dimensions(nomBrut),
    couleur: couleur(nomBrut),
    unite: 'unite',
    emplacement: EMPLACEMENTS[Math.floor(g2 * EMPLACEMENTS.length) % EMPLACEMENTS.length],
    seuilAlerte: Math.max(5, Math.round(total * 0.12)),
    image: PHOTOS[nomBrut.toUpperCase()] ? `/produits/${PHOTOS[nomBrut.toUpperCase()]}` : null,
    photoAValider: Boolean(PHOTOS[nomBrut.toUpperCase()]),
    actif: true,
    quantiteInitiale: total,
  };
  });

const entete = `/**
 * Catalogue de demonstration.
 * Source : « LISTE PRODUIT.pdf » fourni par Groupe Alfa (extraction automatique).
 * ATTENTION : il ne s'agit PAS de l'inventaire complet et definitif de Groupe Alfa.
 * Les quantites sont des donnees de demonstration generees de facon deterministe.
 * Fichier genere par outils/generer-catalogue.mjs — ne pas modifier a la main.
 */
import type { Produit } from '../models/types';

export interface ProduitSeed extends Produit {
  /** Quantite du mouvement STOCK_INITIAL. */
  quantiteInitiale: number;
}

export const PRODUITS: ProduitSeed[] = ${JSON.stringify(produits, null, 2)};

export const FAMILLES = [...new Set(PRODUITS.map((p) => p.famille))].sort();
export const SOUS_FAMILLES = [...new Set(PRODUITS.map((p) => p.sousFamille))].sort();
export const COULEURS = [...new Set(PRODUITS.map((p) => p.couleur).filter(Boolean))].sort();
export const EMPLACEMENTS_PRODUITS = [...new Set(PRODUITS.map((p) => p.emplacement))].sort();
`;

fs.mkdirSync('alfa-flow/src/data', { recursive: true });
fs.writeFileSync('alfa-flow/src/data/produits.ts', entete.replace(/"unite": "unite"/g, '"unite": "unite"'));
console.log(`${produits.length} produits generes`);
console.log('Avec photo :', produits.filter((p) => p.image).length);
console.log('Familles :', [...new Set(produits.map((p) => p.famille))].join(', '));
console.log(produits.slice(0, 5).map((p) => `${p.sku} ${p.nom} [${p.famille}/${p.sousFamille}] ${p.dimensions} ${p.couleur} q=${p.quantiteInitiale}`).join('\n'));
