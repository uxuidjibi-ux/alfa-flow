/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        alfa: {
          // Rouge ALFA releve sur le logo du document source (bandeau rouge)
          red: '#D2172A',
          redDark: '#A81120',
          redSoft: '#FBE9EB',
          // Anthracite du logotype ALFA
          ink: '#1E2226',
          slate: '#4A5157',
          muted: '#7C858C',
          line: '#E2E5E8',
          surface: '#F5F6F7',
        },
        etat: {
          neutre: '#4A5157',
          info: '#1F5FA8',
          succes: '#1B7F4B',
          attention: '#B26A00',
          critique: '#D2172A',
        },
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'system-ui', '-apple-system', 'sans-serif'],
      },
      fontSize: {
        micro: ['0.6875rem', { lineHeight: '1rem', letterSpacing: '0.04em' }],
      },
      borderRadius: { alfa: '3px' },
      boxShadow: {
        panel: '0 1px 2px rgba(30,34,38,0.06), 0 1px 1px rgba(30,34,38,0.04)',
        pop: '0 8px 24px rgba(30,34,38,0.14)',
      },
    },
  },
  plugins: [],
};
