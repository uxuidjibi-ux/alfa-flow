# MVP_VS_PRODUCTION.md

Ce document sépare **ce qui fonctionne réellement**, **ce qui est simulé** et **ce qui devra
être construit ou sécurisé** avant toute mise en production.

À lire avant toute présentation externe : ne présentez jamais comme sécurisée une fonction
listée en section 2.

---

## 1. Ce qui fonctionne réellement

Ces fonctions sont implémentées, exécutées dans le navigateur et couvertes par des tests.

### Règles de stock

- Calcul du disponible, du physique, de la circulation et du théorique depuis le registre.
- Refus de toute réservation ou sortie dépassant le disponible, avec message chiffré.
- Impossibilité de générer un compartiment négatif silencieusement.
- Distinction location / achat : une ligne vendue quitte le parc sans entrer en circulation.
- Ajustement manuel exigeant motif, valeur avant, valeur après, auteur et horodatage.
- Rebut sortant du patrimoine, endommagé restant au patrimoine mais hors du disponible.

### Parcours métier

- Création d'une demande en sept étapes, avec brouillon récupérable.
- Approbation ligne à ligne créant les réservations, refus motivé.
- Préparation avec incréments rapides, photos, notes internes, articles manquants.
- Contrôle final bloquant qui nomme chaque exception.
- Confirmation de sortie, génération du bon PDF, numérotation continue avec l'historique papier.
- Page client de vérification et de signature, ligne par ligne.
- Suivi des locations avec niveau d'alerte et dates de retour.
- Retours partiels successifs sur une même sortie, avec les huit compteurs séparés.
- Calcul de l'écart présenté **avant** toute décision.
- Décisions sur les écarts, motif obligatoire, trace au journal.
- Alertes dérivées sans doublon, acquittement et résolution.
- Rapports filtrables, export CSV réel portant auteur, date et filtres.
- Journal d'activité en ajout seul.
- Persistance après actualisation du navigateur et réinitialisation complète.

---

## 2. Ce qui est simulé

Chacune de ces fonctions est **identifiée comme simulation dans l'interface elle-même**.

| Fonction | État réel | Risque si présentée comme acquise |
|---|---|---|
| **Authentification** | Absente. Le sélecteur de rôle change l'affichage, rien d'autre. | Aucun contrôle d'accès. N'importe qui voit tout. |
| **Permissions** | Vérifiées côté navigateur uniquement. | SEC-001 exige une vérification serveur. Contournable trivialement. |
| **Signature électronique** | Tracé enregistré en image, sans identification du signataire ni piste d'audit. | Sans valeur probante. Ne remplace pas votre bon papier signé. |
| **Lien client** | Jeton lisible, non signé, sans expiration ni révocation. | Toute personne connaissant le lien accède au bon. |
| **Journal d'audit** | Conservé dans le navigateur, modifiable par qui a accès à l'appareil. | Non opposable en cas de litige. |
| **Envoi de courriels** | Bouton « simuler l'envoi ». Aucun message n'est expédié. | Le client ne reçoit rien. |
| **Photos** | Illustrations du catalogue. Aucun téléversement, aucun original conservé. | Aucune preuve réelle constituée. |
| **Sauvegarde** | Aucune. Les données vivent dans le navigateur. | Vider le cache efface tout. |
| **Multi-organisation** | Absente. Une seule base, un seul dépôt. | SEC-012 non satisfait. |
| **Conservation légale** | Aucune politique de rétention. | DATA-019 et SEC-017 non traités. |

---

## 3. Ce qui devra être construit avant la production

### Bloquant — sans quoi la mise en production est impossible

1. **Serveur et API métier.** Toute écriture doit passer par le serveur, seule autorité
   d'écriture. La couche `src/services/` a été écrite sans dépendance à React précisément pour
   être portée telle quelle côté serveur.
2. **Base de données relationnelle** avec transactions garanties, le registre des mouvements
   en table immuable et en ajout seul.
3. **Authentification** avec expiration de session, protection contre les tentatives répétées
   et second facteur pour les rôles administrateur et direction.
4. **Vérification des permissions côté serveur**, à chaque requête.
5. **Stockage de fichiers sécurisé** pour les photos, avec original conservé, dérivés
   compressés, accès contrôlé et expirant.
6. **Sauvegardes chiffrées** et **restauration testée** — une sauvegarde non restaurée n'est
   pas une sauvegarde.
7. **Journal d'audit côté serveur**, en ajout seul, hors de portée des utilisateurs.

### Important — à trancher avant le lot 1

8. **Numérotation des bons** : reprendre la séquence réelle depuis le système actuel. Le
   démonstrateur poursuit à partir de L-18203, valeur relevée sur un bon papier. Une reprise
   incorrecte créerait des doublons sur des documents de preuve.
9. **Codes articles réels** : le démonstrateur génère des codes au format observé, mais ce ne
   sont pas les vôtres. Un export du système actuel est nécessaire.
10. **Signature électronique** : décider avec un conseiller juridique quelles signatures
    doivent rester sur papier, et si un prestataire de signature avancée est requis.
11. **Politique de conservation** des preuves, par type de document, avec suspension de
    suppression tant qu'un dossier est litigieux.
12. **Seuils** : validation supérieure des ajustements, expiration des réservations, stock
    dormant. Le démonstrateur utilise des valeurs d'exemple.

### Souhaitable — après le MVP

13. Mode de connexion limitée avec file de synchronisation, si la couverture réseau en cour
    le justifie.
14. Import Excel du catalogue en deux temps, avec rapport de rejet par ligne.
15. Portail client complet, lecture de codes, intégration comptable, facturation.

---

## 4. Ce qui a été écarté volontairement

- **Aucun montant, aucun prix, aucune facture.** Le cahier des charges place la facturation
  hors périmètre du MVP. Le démonstrateur prépare les éléments — quantités, durées, écarts —
  mais ne calcule rien.
- **Un seul dépôt.** Le modèle porte la notion d'emplacement mais ne gère pas plusieurs sites.
- **Aucune fonction d'intelligence artificielle** n'intervient dans une règle critique.

---

## 5. Prochaines étapes recommandées

1. **Atelier de validation de 90 à 120 minutes** avec le responsable opérationnel, le
   secrétariat, la réception et la direction, consacré aux vingt questions de la section 25 du
   cahier des charges.
2. **Récupérer le gabarit officiel** du bon de livraison et un export des articles réels.
3. **Signer le périmètre MVP** avant tout chiffrage.
4. **Chiffrer par lot**, en commençant par les lots 1 à 3, qui portent l'essentiel de la valeur.
5. **Comptage physique par échantillonnage** avant toute reprise de données : les quantités
   initiales sont le premier risque du projet.
