# ALFA Flow — Hypothèses et points à valider

Ce fichier consigne **toutes les décisions prises faute d'information**, ainsi que les
écarts assumés entre le démonstrateur et le cahier des charges v2.0 du 4 août 2026.

Convention reprise du cahier des charges : chaque point porte le statut
**Confirmé**, **Observé**, **Recommandé**, **À valider** ou **Hors MVP**.

---

## 1. Nature du livrable

| Point | Décision | Statut |
|---|---|---|
| Le démonstrateur n'est pas le MVP de production. | Il illustre les parcours et les règles ; il n'implémente ni serveur, ni authentification réelle, ni isolation multi-organisation. | Recommandé |
| Le cahier des charges décrit un système où **toute écriture passe par l'API métier** (F7). | Ici, la logique métier est isolée dans `src/services/` et ne dépend d'aucun composant d'interface : le remplacement de la persistance locale par une API est un changement d'implémentation, pas de conception. | Recommandé |
| SEC-001 « toute vérification de permission est effectuée côté serveur ». | **Impossible à respecter sans serveur.** Les permissions sont vérifiées côté client uniquement, à des fins de démonstration. Voir MVP_VS_PRODUCTION.md. | À valider |

---

## 2. Catalogue et données sources

| Point | Décision | Statut |
|---|---|---|
| Le cahier des charges annonce **260 articles et 17 familles** ([R4], catalogue public). | Le PDF « LISTE PRODUIT » transmis a permis d'extraire **227 articles uniques** répartis en **11 familles**. L'écart provient de l'extraction, pas d'un choix. Le catalogue de démonstration n'est donc **pas** l'inventaire complet de Groupe Alfa. | Observé |
| DATA-003 — unicité de la référence. | Les SKU sont générés (`ALF-<famille><sous-famille>-<n°>`) car le PDF n'en contient aucun. Unicité vérifiée par test. **QV-012 : les articles possèdent-ils déjà des codes uniques ?** Si oui, ils remplacent les SKU générés. | À valider |
| RF-010 / RF-011 — quelles variantes créent un stock distinct. | Hypothèse retenue : **longueur, module et couleur créent un stock distinct** (deux barres de couleurs différentes ne sont pas interchangeables en cour). Le cahier des charges demande un arbitrage famille par famille au lot 0. | À valider |
| Quantités initiales. | Générées de façon **déterministe mais fictive** (60 à 400 unités pour les barres, poteaux et accessoires ; 12 à 130 pour le reste). Quatre articles sont volontairement en stock bas pour illustrer les alertes de seuil. **QV-001 non répondue.** | Recommandé |
| Seuils d'alerte. | Fixés à 12 % de la quantité initiale, minimum 5. Aucune donnée réelle disponible. | Recommandé |
| DATA-033 — quantités non confirmées. | Non implémenté : toutes les quantités de démonstration sont réputées comptées. En production, une quantité « à compter » doit être exclue du disponible. | Hors démonstrateur |

### Photos produits

Le PDF contient des photographies de cour prises au téléphone, intercalées entre les
libellés. **10 photos ont été extraites** (détourage par masque alpha inclus) et
associées aux barres horizontales par une heuristique combinant l'ordre du texte de la
page et la couleur des embouts.

- Deux associations sont **confirmées par la couleur** (5'2" jaune, 3'10" mauve).
- Les huit autres sont **probables mais non vérifiées**.
- Toutes portent la mention **« Photo à valider »** dans l'interface (champ `photoAValider`).
- Les 217 autres articles affichent un espace neutre, jamais une fausse photo — conformément à DATA-007 (« média à compléter »).

**À valider :** une reprise photo par article est nécessaire avant toute présentation externe.

---

## 3. Règles de stock (section 8)

| Règle | Traitement dans le démonstrateur | Statut |
|---|---|---|
| Équations 8.3 | Implémentées littéralement dans `src/services/stock.ts`, vérifiées par tests. | Confirmé |
| RG-021 — disponible jamais négatif | Implémenté : toute opération l'entraînant est refusée avec un message nommant l'article et les deux quantités. | Confirmé |
| RG-022 — physique temporairement négatif toléré avec alerte bloquante | **Écart assumé** : le démonstrateur refuse également tout stock physique négatif. Le cas « erreur détectée » n'est pas simulable sans saisie terrain réelle. | À valider |
| RG-023 — expiration des réservations | **Non implémenté** : le délai n'est pas défini. Une réservation reste active jusqu'à la sortie ou l'annulation. **Délai à fixer.** | À valider |
| RG-026 — transfert interne | Type de mouvement présent, sans écran dédié dans le démonstrateur. | Hors démonstrateur |
| RG-027 — endommagé ≠ rebut | Implémenté : `DOMMAGE` bloque sans sortir du patrimoine ; `REBUT` sort du patrimoine. L'approbation requise pour le rebut n'est pas simulée. | Recommandé |
| RG-028 — matériel perdu dû par le client | Le mouvement `PERTE` retire l'unité de la circulation et génère un écart en décision. La créance client n'est pas modélisée (pas de facturation au MVP). | À valider |
| RG-029 — substitution = deux écritures liées | Type `SUBSTITUTION_ENTREE` et champ `mouvementLieId` présents ; le parcours de substitution en préparation exige un motif. | Recommandé |
| RG-030 — stock dormant | Seuil fixé à **120 jours** (valeur d'exemple citée dans US-029). Alerte implémentée. | À valider |
| SEC-003 — seuil d'ajustement exigeant validation supérieure | Fixé arbitrairement à **25 unités**. Le démonstrateur signale l'ajustement sensible mais ne bloque pas en attente d'un second validateur. **QV-007 non répondue.** | À valider |
| RF-001 — séparation créateur / validateur | Non implémenté : un seul utilisateur par rôle dans la démonstration. | À valider |

---

## 4. Emplacements

La typologie de la section 8.2 est reprise telle quelle : cour et entrepôt découpés en
zones et rangées, plus zone de préparation, zone de retour, quarantaine et réparation ;
côté externe, véhicule de livraison, chez le client et sur le chantier.

**Les noms de zones et de rangées sont inventés.** Un seul dépôt est géré, conformément
à BF-002, mais aucune donnée réelle sur l'organisation physique de Sainte-Sophie n'a
été fournie.

---

## 5. Demandes, préparations, sorties

| Point | Décision | Statut |
|---|---|---|
| QV-003 — une demande peut-elle couvrir plusieurs chantiers ? | Hypothèse : **non**. Une demande porte un client et un chantier. Si la réponse est oui, le modèle de données de la demande et du bon devra être repris. | À valider |
| QV-004 — génération des numéros de bons | **Résolu.** Format `L-#####`, séquence continue à partir de L-18203 (dernier bon papier observé). | Confirmé |
| Type d'item | **Confirmé le 4 août 2026 : un même bon mêle couramment location et achat.** Le type suit la ligne, depuis la demande jusqu'au bon. Conséquence sur le stock : une ligne en achat génère un mouvement `VENTE` qui sort la quantité du parc **sans** l'ajouter au stock en circulation ; elle n'apparaît dans aucune location et n'est jamais attendue au retour. | Confirmé |
| Colonnes de quantités | Le bon papier porte **Qté commandée / Qté expédiée / Qté à venir**. Le reliquat RG-024 apparaît donc directement sur le document client. Repris tel quel. | Confirmé |
| Double signature | Le bon papier fait signer **le client et le représentant Alfa**, chacun avec nom en lettres moulées et date. Repris. | Confirmé |
| Heures de livraison | Le bon papier porte « Hre arrivée / commencée / terminée ». Champs ajoutés au modèle. | Observé |
| BF-019 — contrôle final | Implémenté avec six contrôles bloquants : ligne non traitée, quantité supérieure au confirmé, quantité inférieure sans justification, photo manquante, substitution non justifiée, article manquant sans note. | Confirmé |
| BF-017 — préparation en plusieurs vagues | Le modèle porte un numéro de vague et le reliquat reste réservé. Une seule vague est pré-créée dans les données de démonstration. | Recommandé |
| US-010 — demande complétée après envoi, versionnée | **Non implémenté** : pas d'historique de versions des demandes. | Hors démonstrateur |
| Méthode par lien client (section 9.2) | **Non implémentée** : seule la page publique de consultation et signature d'un bon existe. La composition d'une demande par le client est un parcours distinct. | Hors démonstrateur |

---

## 6. Retours et rapprochement (section 12)

Les huit compteurs de DATA-020 sont conservés séparément, plus un neuvième champ
`quantiteExcedent` nécessaire au cas « quantité supérieure » de la section 12.3.

Les six cas d'exception du tableau 12.3 sont traités ainsi :

| Cas | Comportement implémenté |
|---|---|
| Retour complet | Rapprochement automatique, location clôturée. |
| Retour partiel successif | Ligne laissée ouverte, reliquat visible, plusieurs retours par sortie autorisés. |
| Retour avec dommage | Quantité en quarantaine, écart créé, photo obligatoire. |
| Manquant | Mouvement `PERTE`, écart créé, photo obligatoire. |
| Quantité supérieure | Saisie dans « excédent reçu », mouvement `EXCEDENT_QUARANTAINE`, écart de type excédent. |
| Mauvaise référence | Acceptation **refusée** tant que la ligne est qualifiée « référence non conforme ». |
| Article non identifiable | **Non implémenté** : une entrée en quarantaine sans article rattaché exige un écran d'inventaire libre. |
| Correction après clôture | **Non implémenté** : la réouverture contrôlée (US-026, priorité Should) n'est pas dans le démonstrateur. |

**QV-018 — un article peut-il revenir sur un autre chantier que celui de départ ?**
Hypothèse : le retour est rattaché à la location d'origine. RG-041 mentionne qu'un retour
peut couvrir plusieurs bons de livraison ; ce cas n'est pas implémenté.

---

## 7. Preuves et documents

- DATA-014 : les huit catégories de preuve sont modélisées et sélectionnables.
- DATA-018 : le champ `version` et `remplacePhotoId` empêchent l'écrasement silencieux ; l'interface propose un remplacement versionné.
- DATA-016 : compression simulée côté navigateur ; **aucune conservation d'un original haute qualité**, faute de stockage serveur.
- SEC-007 : les métadonnées ne sont pas retirées — les photos de démonstration proviennent du PDF et non d'un appareil.
- **QV-015 — durée de conservation des preuves : sans réponse.** Aucune politique de rétention n'est implémentée.

---

## 7 bis. Gabarit du bon de livraison

Le bon papier fourni le 4 août 2026 (bon **L-18203**) a servi de modèle. Sont repris
fidèlement : le bloc émetteur (9184-9745 Québec inc., 2647 boul. Sainte-Sophie), les
blocs « Vendu à » et « Expédié à », la bande administrative (bon de commande client,
n° commande Alfa, représentant, date expédiée, expédié via, termes), le tableau à sept
colonnes, les conditions Location/Achat, les trois heures de livraison et la double
signature.

**Ce gabarit est une reconstitution, pas le gabarit officiel.** Il devra être remplacé
dès réception du modèle utilisé par le logiciel actuel de Groupe Alfa. Les mentions
légales des conditions ont été recopiées depuis la photo et doivent être relues.

**À valider :** le logo fourni porte le descripteur « Produits de coffrage et
d'échafaudage », alors que le PDF du catalogue portait « Matériaux et ingénierie ».
Deux déclinaisons de marque coexistent ; celle du logo fourni est utilisée.

---

## 8. Signature et portée juridique

Le cahier des charges est explicite : le produit **n'est pas présenté comme juridiquement
conforme**, et la configuration des signatures doit être validée avec un conseiller
juridique (BF-025, QV-005).

Dans le démonstrateur :

- La page publique de signature est une **simulation de démonstration**, sans lien signé, sans expiration, sans révocation, sans piste d'audit inviolable.
- Le jeton du lien est un identifiant lisible, **sans aucune valeur de sécurité**.
- Le PDF généré porte une mention explicite de simulation.
- BF-022 (signature papier puis photo du document signé) est le mode nominal retenu, conformément à RF-030.

---

## 9. Alertes

Les quatorze alertes de la section 13 sont modélisées. Écarts assumés :

- Les alertes sont **dérivées de l'état courant** et non stockées : l'identifiant est déterministe (type + entité), ce qui garantit RF-040 (aucun doublon pour un même événement) par construction plutôt que par déduplication.
- Les fréquences d'envoi (1/jour, 1/4 h, 1/48 h) ne sont pas simulées : sans serveur, il n'y a pas de tâche planifiée.
- Le canal courriel n'existe pas ; toutes les alertes sont dans l'application.
- Délais « bon non signé à 48 h » et « retour attendu à J−3 » : valeurs du cahier des charges reprises telles quelles, elles-mêmes marquées « à valider ».

---

## 10. Indicateurs et rapports

- Les indicateurs recalculables depuis les mouvements sont implémentés.
- **Stock total et valeur** ne l'est pas : aucune valeur unitaire de référence n'est disponible (QV-001, QV-008).
- Temps moyen de préparation et temps moyen de traitement d'un retour reposent sur des horodatages de statut partiellement simulés dans les données de démonstration.
- Export CSV réel implémenté (séparateur point-virgule, BOM UTF-8, compatible Excel) ; RF-050 respecté : auteur, date et filtres appliqués figurent dans l'export.

---

## 11. Données de démonstration

Clients, chantiers, contacts et dossiers sont **entièrement fictifs** et identifiés comme
tels par le suffixe « (demo) ». Aucune donnée réelle de Groupe Alfa n'y figure. Les
scénarios couvrent : 4 clients, 6 chantiers, 6 contacts, 7 demandes (tous statuts),
5 préparations, 4 bons de livraison, 4 locations (active, en retard, retour partiel,
clôturée), 3 retours et 3 écarts.

---

## 12. Questions bloquantes reprises du cahier des charges

Les vingt questions de la section 25 restent ouvertes. Celles qui affectent
**directement** ce démonstrateur, par ordre d'impact :

1. **QV-007** — qui autorise pertes, dommages et ajustements, et au-delà de quel seuil.
2. **QV-017** — plusieurs signataires par client : impacte les liens de signature.
3. **QV-008 / QV-010** — présence des prix et production de factures : le démonstrateur n'affiche aucun montant.
4. **QV-014** — fiabilité du réseau en cour : conditionne l'effort de mode hors ligne.

---

*Document maintenu à jour à chaque itération du démonstrateur.
Dernière mise à jour : alignement sur le cahier des charges v2.0 du 4 août 2026.*
