# ACCEPTANCE_CHECKLIST.md

État au **4 août 2026**. Cette liste reprend la matrice de recette de la section 22 du cahier
des charges, adaptée au périmètre du démonstrateur.

**Légende :** ✅ vérifié · ⚠️ partiel ou simulé · ⛔ hors périmètre du démonstrateur ·
⏳ à vérifier au premier lancement

---

## 1. Résultats des tests automatisés

**22 tests sur 22 réussis.**

| Test | Résultat |
|---|---|
| Calcul du stock disponible selon la formule 8.3 | ✅ |
| Stock en circulation après une sortie | ✅ |
| Quantité signée cohérente au registre | ✅ |
| Rebut hors patrimoine, excédent en quarantaine | ✅ |
| Agrégation et détection des articles sous le seuil | ✅ |
| Refus d'une réservation supérieure au disponible, message chiffré | ✅ |
| Impossibilité de générer un stock négatif | ✅ |
| Séquence cohérente acceptée | ✅ |
| Catalogue sans identifiant ni SKU dupliqué | ✅ |
| Aucun compartiment négatif dans les données de démonstration | ✅ |
| Dossiers attendus par la démonstration présents | ✅ |
| Aucune alerte en double pour un même événement | ✅ |
| Refus d'une approbation supérieure au disponible | ✅ |
| Approbation réduite créant la réservation | ✅ |
| Contrôle final bloquant sur ligne non traitée | ✅ |
| Refus d'une quantité préparée supérieure à l'approuvée | ✅ |
| Préparation partielle justifiée acceptée | ✅ |
| Parcours complet sortie → bon → retour partiel → écart → stock | ✅ |
| Ligne vendue distinguée d'une ligne louée sur un même bon | ✅ |
| Ajustement exigeant un motif, valeur avant et après tracées | ✅ |
| Permissions par rôle | ✅ |
| Persistance et réinitialisation | ✅ |

**Comment les reproduire :** `npm test`

> Note de transparence : ces tests ont été exécutés au moyen d'un adaptateur minimal de l'API
> Vitest, l'environnement de développement n'ayant pas accès au registre npm. Ils sont écrits
> avec l'API Vitest standard et doivent être réexécutés par `npm test` après installation.

---

## 2. Matrice de recette du cahier des charges

| ID | Exigence | État | Note |
|---|---|---|---|
| REC-01 | Import de 260 lignes avec doublons signalés | ⛔ | Import Excel hors périmètre du démonstrateur. Le catalogue est généré depuis le PDF fourni. |
| REC-02 | Demande de 120 pour 100 disponibles → 100 confirmées, reliquat, alerte | ✅ | Écran Demandes, quantité ajustable ligne à ligne avec message chiffré. |
| REC-03 | Préparer 60 puis 25 sur une ligne de 100 → 85 préparées, 15 restantes | ⚠️ | Le modèle porte le numéro de vague et le reliquat ; une seule vague est pré-créée dans les données de démonstration. |
| REC-04 | Ligne non traitée et photo manquante → sortie refusée, exceptions nommées | ✅ | Contrôle final, six contrôles bloquants. |
| REC-05 | Sortie de 120 pour 100 disponibles → refusée, aucun mouvement créé | ✅ | Testé. |
| REC-06 | Bon de 8 lignes généré et imprimable en noir et blanc | ✅ | PDF calqué sur le bon papier. Aucune information portée par la seule couleur. |
| REC-07 | 100 sorties, 70 retournées, retour de 20 → 90 retournées, 10 restantes | ✅ | Testé (critère AC-000). |
| REC-08 | Retour couvrant deux chantiers, dossier unique soldé | ⛔ | Un retour est rattaché à une location. Cas non implémenté, documenté dans ASSUMPTIONS. |
| REC-09 | Décision « à facturer » refusée sans motif, acceptée avec | ✅ | Testé et présent à l'écran Écarts. |
| REC-10 | Correction par écriture compensatoire, mouvement d'origine intact | ✅ | Testé sur l'ajustement de stock. |
| REC-11 | Saisie hors ligne puis synchronisation sans doublon | ⛔ | Mode de connexion limitée hors périmètre. |
| REC-12 | Accès refusé aux données d'un autre client, tentative journalisée | ⛔ | Impossible sans serveur. Voir MVP_VS_PRODUCTION. |
| REC-13 | Journal retrouvant création, validation, signature, correction, export | ⚠️ | Journal présent et complet, mais conservé dans le navigateur et non infalsifiable. |
| REC-14 | Restauration d'une sauvegarde documentée et chronométrée | ⛔ | Aucune sauvegarde serveur. |
| REC-15 | Export Excel identique à l'écran, portant auteur, date et filtres | ✅ | Export CSV compatible Excel, pied de fichier portant rapport, date, client et période. |

---

## 3. Interactions obligatoires demandées

| Fonction | État |
|---|---|
| Navigation entre les 16 écrans, aucune page vide ou cassée | ✅ |
| Changement de rôle modifiant les actions accessibles | ✅ |
| Recherche globale (articles, clients, chantiers, demandes, bons, locations) | ✅ |
| Filtres, tri, affichage liste et galerie | ✅ |
| Création d'une demande en sept étapes | ✅ |
| Ajout et retrait de produits, modification des quantités | ✅ |
| Enregistrement d'un brouillon | ✅ |
| Changement de statut valide, refus d'une transition invalide | ✅ |
| Préparation partielle | ✅ |
| Ajout et prévisualisation de photos | ⚠️ Capture simulée, illustrations du catalogue |
| Confirmation d'une sortie | ✅ |
| Génération du bon PDF | ✅ |
| Démarrage d'un retour, retour partiel | ✅ |
| Calcul des quantités restantes, détection d'un écart | ✅ |
| Création des mouvements, mise à jour du stock et des indicateurs | ✅ |
| Export CSV | ✅ |
| Persistance après actualisation du navigateur | ✅ |
| Réinitialisation des données | ✅ |

---

## 4. Accessibilité (WCAG 2.2 AA, exigences PERF)

| Exigence | État | Note |
|---|---|---|
| PERF-001 — responsive sans défilement horizontal | ⏳ | Construit pour 1440×900, 1024×768 et 390×844. À vérifier visuellement au premier lancement. |
| PERF-002 — cibles tactiles de 44 points minimum | ✅ | Appliqué à tous les boutons, champs et compteurs. |
| PERF-003 — contraste AA, aucune information par la seule couleur | ✅ | Rouge foncé pour les textes ; chaque statut porte un marqueur de forme. |
| PERF-004 — messages nommant le champ et l'action corrective | ✅ | Aucun message générique dans l'application. |
| PERF-006 — bonnes pratiques WCAG pertinentes | ⚠️ | Lien d'évitement, focus visible, labels reliés, tableaux avec légende, `prefers-reduced-motion` respecté. Un audit complet reste à mener. |

---

## 5. Points à vérifier au premier lancement

Ces points n'ont pas pu être vérifiés dans l'environnement de développement, qui n'a pas accès
au registre npm et ne peut donc pas exécuter Vite.

1. ⏳ `npm install` puis `npm run dev` démarrent sans erreur.
2. ⏳ Rendu visuel sur les trois formats d'écran demandés.
3. ⏳ Génération du PDF dans un navigateur réel, y compris l'insertion du logo.
4. ⏳ Téléchargement CSV sur Safari mobile.
5. ⏳ Tracé de la signature au doigt sur un téléphone.
6. ⏳ `npm run build` et `npm run lint` sans erreur.
7. ⏳ Parcours Playwright.

**Une passe de corrections visuelles est à prévoir.** La logique métier, elle, a été
exécutée et vérifiée.

---

## 6. À valider avec Groupe Alfa

1. Le gabarit officiel du bon de livraison, pour remplacer la reconstitution.
2. Les codes articles réels et la séquence exacte de numérotation des bons.
3. La relecture des conditions Location / Achat, recopiées depuis une photo partiellement
   ombrée.
4. Les emplacements réels de la cour et de l'entrepôt de Sainte-Sophie.
5. Les quantités initiales, à établir par comptage physique par échantillonnage.
6. Les huit questions de la section 25 listées dans ASSUMPTIONS.md.
7. Le choix de la déclinaison de marque : le logo porte « Produits de coffrage et
   d'échafaudage », le PDF catalogue portait « Matériaux et ingénierie ».
