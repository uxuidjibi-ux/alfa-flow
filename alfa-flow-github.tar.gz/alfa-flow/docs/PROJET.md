# ALFA Flow — démonstrateur

Démonstrateur web fonctionnel de gestion des stocks, des locations, des livraisons et des
retours de matériel de coffrage et d'échafaudage, pour **Groupe Alfa**
(9184-9745 Québec inc., Sainte-Sophie).

Il illustre concrètement les parcours décrits dans le *Cahier des charges fonctionnel et
technique ALFA Flow, version 2.0 du 4 août 2026*.

> **Ce n'est pas le système de production.** Plusieurs fonctions sont simulées.
> Voir `MVP_VS_PRODUCTION.md` avant toute présentation externe.

---

## Installation et lancement

Prérequis : **Node.js 18 ou plus récent**.

```bash
npm install      # installe les dépendances
npm run dev      # démarre le serveur de développement
```

L'application s'ouvre sur `http://localhost:5173`.

### Autres commandes

| Commande | Effet |
|---|---|
| `npm run build` | Vérification TypeScript puis compilation de production dans `dist/` |
| `npm run preview` | Sert la version compilée |
| `npm run typecheck` | Vérification des types seule |
| `npm run lint` | Analyse ESLint |
| `npm test` | Tests unitaires (Vitest) |
| `npm run e2e` | Parcours fonctionnel (Playwright) |

### Démonstration depuis un téléphone

L'application est entièrement statique une fois compilée. `npm run build` produit un dossier
`dist/` déposable sur n'importe quel hébergement, ce qui rend la démonstration accessible
depuis un téléphone par une simple adresse. Aucune installation côté client.

---

## Rôles de démonstration

Le sélecteur en haut à droite change le rôle actif et les actions disponibles. **Aucun mot de
passe** : c'est une simulation, pas un contrôle d'accès.

| Rôle | Ce qu'il peut faire |
|---|---|
| Administrateur principal | Tous les modules, ajustement de stock, journal d'activité |
| Responsable de cour | Catalogue, stock, préparations, photos, sorties, retours, écarts |
| Secrétariat | Clients, chantiers, demandes, bons de livraison, rapports |
| Direction | Tableaux de bord, rapports, décisions sur les écarts, ajustements, journal |

Le client externe n'a pas de compte : il agit par le lien simulé `/bon/<jeton>`.

---

## Structure du projet

```
src/
  app/           routage
  assets/        logo encodé pour le PDF
  components/
    layout/      mise en page, navigation, guide de démonstration
    ui/          composants réutilisables et système de statuts
  data/          catalogue généré et données de démonstration
  features/      un dossier par module métier (16 écrans)
  models/        types TypeScript et référentiel (libellés, permissions, transitions)
  services/      règles métier, calcul du stock, alertes, PDF, CSV, persistance
  state/         magasin Zustand et sélecteurs dérivés
  styles/        Tailwind et identité visuelle
  tests/         tests unitaires et de parcours
```

**Séparation volontaire :** aucun composant d'interface ne calcule une quantité ni n'écrit
directement dans le stockage. Toute la logique vit dans `src/services/`, sans dépendance à
React — c'est ce qui rendra la migration vers une API serveur possible sans réécrire l'interface.

---

## Le principe central

> Le stock n'est pas un nombre modifiable.

Chaque quantité affichée — disponible, réservé, en préparation, chez les clients, endommagé —
est **recalculée à partir du registre des mouvements** (`src/services/stock.ts`). Aucun solde
n'est stocké. Une correction ne modifie jamais une écriture passée : elle ajoute une écriture
compensatoire portant son motif et son auteur.

Les quatre équations du cahier des charges sont implémentées littéralement :

```
Stock physique      = quantités présentes dans les emplacements internes
Stock disponible    = physique − réservé − en préparation − endommagé
Stock en circulation = sorties non encore rapprochées
Stock théorique     = physique + circulation
```

Toute opération qui rendrait un compartiment négatif est **refusée**, avec un message nommant
l'article et les deux quantités en cause.

---

## Location et achat

Un même bon peut mêler les deux, comme sur les bons papier de Groupe Alfa.

- Une ligne en **location** entre en circulation et sera attendue au retour.
- Une ligne en **achat** quitte définitivement le parc : elle n'apparaît dans aucune location
  et ne génère jamais d'alerte de retour.

---

## Parcours de démonstration

Le bouton **« Lancer la démonstration guidée »** sur le tableau de bord déroule le scénario
en huit étapes. Le détail parlé figure dans `DEMO_SCRIPT.md`.

En résumé : une demande arrive au secrétariat → vérification de la disponibilité réelle →
approbation et réservation → préparation en cour avec photos → contrôle final → sortie
confirmée → bon de livraison PDF et lien client → location active → retour partiel →
écart détecté → stocks et tableau de bord actualisés.

**« Réinitialiser les données de démonstration »**, dans Administration, remet tout dans
l'état initial après confirmation.

---

## Ce qui fonctionne réellement

Navigation, changement de rôle, recherche globale, filtres, tri, liste et galerie, création
d'une demande en sept étapes, brouillon, approbation avec réservation, refus motivé,
préparation partielle, photos, contrôle final bloquant, confirmation de sortie, génération
du bon PDF, page client avec vérification ligne à ligne et signature tactile, suivi des
locations, retours partiels successifs, calcul de l'écart, création des écarts, décisions
motivées, alertes, rapports, export CSV, journal d'activité, persistance après actualisation
et réinitialisation.

## Ce qui est simulé

Authentification, signature juridiquement qualifiée, conservation légale, journal
infalsifiable, sauvegarde serveur, séparation des organisations, envoi de courriels,
sécurité des liens externes, téléversement réel de photos.

Le détail est dans `MVP_VS_PRODUCTION.md`.

---

## Documents livrés

| Fichier | Contenu |
|---|---|
| `README.md` | Ce document |
| `ASSUMPTIONS.md` | Hypothèses prises, écarts assumés, questions à valider |
| `DEMO_SCRIPT.md` | Scénario parlé de 8 à 10 minutes |
| `MVP_VS_PRODUCTION.md` | Ce qui marche, ce qui est simulé, ce qui doit être reconstruit |
| `ACCEPTANCE_CHECKLIST.md` | Liste de contrôle et résultats de tests |
