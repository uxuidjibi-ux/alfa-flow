# DEMO_SCRIPT.md — scénario de démonstration

**Durée : 8 à 10 minutes. Public : direction, secrétariat, responsable de cour.**

Avant de commencer : ouvrir Administration → **Réinitialiser les données de démonstration**,
puis revenir au tableau de bord. Prévoir un téléphone ou une tablette à portée de main pour
l'étape 4 — c'est le moment qui frappe le plus.

> Phrase d'ouverture suggérée : *« Je ne vais pas vous montrer un logiciel. Je vais vous montrer
> une journée de travail chez vous, du téléphone qui sonne jusqu'au matériel qui revient. »*

---

## Étape 1 — Le tableau de bord (1 min)

**Rôle : Direction. Écran : Tableau de bord.**

Montrer les huit compteurs « à traiter aujourd'hui », puis la barre de répartition du parc.

> *« Tout ce que vous voyez ici est calculé, pas saisi. Le disponible, ce qui est chez vos
> clients, ce qui est en quarantaine : ce sont des additions faites à partir de chaque
> mouvement enregistré. Personne ne peut taper un chiffre à la main dans cet écran. »*

Pointer **Retours en retard** et **Écarts non résolus**.

> *« Ces deux nombres, aujourd'hui, personne chez vous ne les connaît avant qu'un client
> appelle. »*

---

## Étape 2 — Retrouver un article et connaître sa disponibilité (1 min)

**Rôle : Direction ou Secrétariat. Écran : Catalogue.**

Taper `barre horizontale` dans la recherche. Ouvrir une fiche article.

> *« 227 articles issus de votre liste. Je cherche par nom, par code, par dimension ou par
> couleur. »*

Sur la fiche, montrer les six compartiments.

> *« Vous avez 372 barres. Mais vous n'en avez pas 372 de disponibles : il y en a de réservées
> sur un dossier approuvé, en préparation dans la cour, chez des clients, et en quarantaine.
> C'est cette différence qui coûte cher aujourd'hui, parce que personne ne la voit. »*

Faire défiler jusqu'à l'historique des mouvements.

> *« Et chaque unité a une histoire : qui l'a bougée, quand, pour quel dossier. »*

---

## Étape 3 — La demande arrive (1 min 30)

**Rôle : Secrétariat. Écran : Demandes.**

Ouvrir la demande du chantier **Entrepôt Logipro**, statut *Approuvée*.

Ou, pour montrer la saisie : **Nouvelle demande** → client, chantier, date, deux ou trois
articles, quantités, soumettre. Sept étapes, moins d'une minute.

Sur une demande à vérifier, montrer la colonne **Disponible** à côté de **Demandée**.

> *« Le client en veut 400. Vous en avez 180. Le système ne dit pas oui à 400. Il vous laisse
> approuver 180 et garder le reliquat visible au dossier. Aucune quantité n'est promise avant
> que quelqu'un chez vous ait vérifié. »*

Cliquer **Approuver et réserver**.

> *« À cette seconde seulement, les quantités sont réservées. Elles n'apparaissent plus comme
> disponibles pour un autre chantier. »*

---

## Étape 4 — La cour prépare (2 min) — *le moment fort*

**Changer de rôle : Responsable de cour. Écran : Préparations.**
**Si possible, faire cette étape sur un téléphone ou une tablette.**

Ouvrir la préparation à faire.

> *« Voilà ce que votre responsable de cour a dans les mains, debout, avec des gants. »*

Sur une ligne : appuyer sur **+10**, puis **Ajouter une photo**, puis **Confirmer la ligne**.

> *« Trois gestes. Pas de feuille, pas de crayon, pas de retranscription le soir par le
> secrétariat. Ce qu'il saisit ici, c'est déjà le dossier. »*

**Laisser volontairement une ligne non traitée**, puis cliquer **Contrôle final**.

> *« Et voilà la vraie valeur. »*

Lire le message d'erreur à voix haute.

> *« Le système ne dit pas "une erreur est survenue". Il dit exactement quelle ligne n'est pas
> traitée, quelle photo manque, quelle quantité dépasse ce qui a été approuvé. Tant que ce
> n'est pas corrigé ou justifié, le camion ne part pas. »*

Corriger, puis **Déclarer prête** → **Confirmer la sortie**.

---

## Étape 5 — Le bon de livraison (1 min 30)

**Écran : Sorties et livraisons.**

Montrer le bon généré, puis **Aperçu**.

> *« Numéro L-18209 — la suite exacte de vos bons papier, pas une nouvelle numérotation qui
> créerait des doublons. Même structure que votre bon actuel : vendu à, expédié à, représentant,
> termes, et vos trois colonnes — commandée, expédiée, à venir. Le reliquat que le client
> attend encore est imprimé sur son bon. »*

Puis **Ouvrir la page client** (idéalement sur le téléphone).

> *« Et voilà ce que votre client reçoit par lien, sans rien installer. »*

Sur la page client, basculer une ligne sur **Quantité différente**, saisir un nombre, un motif,
signer au doigt, confirmer.

> *« Il ne signe plus à l'aveugle un papier sur un capot de camion. Il vérifie chaque ligne. Et
> s'il manque quelque chose, vous le savez à cette minute-là — pas trois semaines plus tard au
> retour, quand plus personne ne se souvient. »*

---

## Étape 6 — Le matériel chez le client (30 s)

**Écran : Locations.**

> *« Chaque dossier avec sa date de retour et son niveau d'alerte. Le rouge, c'est ce qui est
> en retard. Vous relancez avant que ça devienne une perte. »*

Ouvrir un dossier et montrer le tableau de rapprochement.

> *« Sorti, retourné, endommagé, manquant, reste chez le client. Cinq colonnes qui ne se
> mélangent jamais. »*

---

## Étape 7 — Le retour et l'écart (2 min)

**Écran : Locations → une location active → Démarrer un retour.**

Sur une ligne : saisir une quantité acceptée inférieure à l'attendu, quelques unités
endommagées, quelques manquantes, ajouter une photo.

Montrer le bloc **Écart calculé par le système**, qui se met à jour en direct.

> *« C'est le système qui compare l'attendu et le reçu. Plus personne ne met deux feuilles côte
> à côte sur un coin de bureau. Mais remarquez : il calcule, il ne décide pas. La décision reste
> à vous. »*

**Soumettre le comptage.**

> *« Le matériel accepté revient en stock. L'endommagé part en quarantaine — sorti du
> disponible, mais pas de votre patrimoine. Le manquant devient un écart qui attend une
> décision. Et tout ça avec les photos attachées. »*

**Changer de rôle : Direction. Écran : Écarts.**

Décider un écart : *À facturer*, avec un motif.

> *« Motif obligatoire. Auteur, date, heure. Le jour où un client conteste, vous avez le dossier
> complet avec les photos, pas une discussion de mémoire. »*

---

## Étape 8 — Retour au tableau de bord (30 s)

> *« Regardez les chiffres du début. »*

Les compteurs, le stock disponible et la répartition ont changé.

> *« Rien n'a été ressaisi nulle part. Un geste dans la cour a mis à jour le stock, le dossier
> client, les alertes et le tableau de bord de la direction. C'est ça, une seule source de
> vérité. »*

**Phrase de clôture suggérée :**

> *« Ce que vous venez de voir tourne dans un navigateur, sans serveur. C'est un démonstrateur :
> l'authentification, la signature légale et la sauvegarde restent à construire. Mais les règles
> de gestion — le calcul du stock, le rapprochement, les écarts — sont réelles et testées. C'est
> la partie difficile, et elle est faite. »*

---

## Questions probables et réponses honnêtes

**« Est-ce que c'est prêt à utiliser demain ? »**
Non. C'est un démonstrateur. Il manque l'authentification, un serveur, les sauvegardes. Les
règles métier, elles, sont réelles.

**« Est-ce que la signature est légale ? »**
Non, et le document le dit explicitement. La question doit être tranchée avec un conseiller
juridique. Votre bon papier signé reste le mode nominal.

**« Ce sont nos vrais chiffres ? »**
Non. Les articles viennent de votre liste, mais les quantités, les clients et les chantiers
sont fictifs et identifiés comme tels.

**« Combien de temps pour l'avoir en vrai ? »**
Le cahier des charges propose six lots, de la découverte au pilote. Le chiffrage se fait après
le lot 0, quand les vingt questions de validation ont des réponses.
